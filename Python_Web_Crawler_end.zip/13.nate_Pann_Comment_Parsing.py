from urllib.request import urlopen
from bs4 import BeautifulSoup

def parsing():
    url = 'https://pann.nate.com/talk/344403021'
    soup = BeautifulSoup(urlopen(url).read(), 'html.parser')

    # 베스트 댓글
    print('▶ 베스트 댓글 ◀')
    comment_best = soup.find('div', class_ = 'cmt_best')
    # print(comment_best.get_text())
    comment_best = comment_best.find_all('dd', class_ = 'usertxt')
    for comment in comment_best:
        print("=" * 80)
        print(comment.get_text().strip())
    print("=" * 80, '\n')

    # 일반 댓글
    print('▶ 일반 댓글 ◀')
    comment_list = soup.find('div', class_ = 'cmt_list')
    # print(comment_best.get_text())
    comment_list = comment_list.find_all(['dd', 'dt'], class_ = ['usertxt', 'del'])
    for comment in comment_list:
        print("=" * 80)
        print(comment.get_text().strip())
    print("=" * 80)
        
if __name__ == '__main__':
    parsing()








