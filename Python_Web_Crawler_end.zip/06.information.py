from bs4 import BeautifulSoup as bs
import requests

MEMBER_DATA = {
    "memberID": "mkvryu",
    "memberPassword": "1234"
}

with requests.Session() as s:
    request = s.post("http://dowellcomputer.com/member/memberLoginAction.jsp", data=MEMBER_DATA)
    # 회원 정보 수정 페이지로의 GET 요청(Request) 객체를 생성하고 아이디를 넘겨준다.
    request = s.get("http://dowellcomputer.com/member/memberUpdateForm.jsp?ID=mkvryu")
    soup = bs(request.text, 'html.parser')
    # name 속성이 memberEmail인 <input> 태그를 얻어온다.
    result = soup.findAll('input', {"name": "memberEmail"})
    print(result)
    print(result[0].get('value'))
    


