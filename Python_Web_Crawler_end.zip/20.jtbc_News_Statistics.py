from urllib.request import urlopen
from bs4 import BeautifulSoup
# pip install matplotlib를 실행해서 설치해야 한다.
import matplotlib.pyplot as plt

def main():
    # jtbc 뉴스 => 뉴스홈 => 스포츠
    url = "http://news.jtbc.joins.com/section/index.aspx?scode=70"
    sourcecode = urlopen(url).read()
    soup = BeautifulSoup(sourcecode, "html.parser")
    
    times = []
    section_title = soup.find("div", class_="section_main_list")
    for i in range(0, 22):
        # 뉴스 기사에서 날짜 및 시간 정보만 얻어온다.
        times.append(soup.find_all("span", class_="date")[i].get_text().strip())
        # print(times[i])

    day = []
    for i in range(0, len(times)):
        # 날짜 및 시간 정보에서 날짜만 얻어낸다.
        day.append(times[i][8:10])
        # print(day[i])

    news_count = [0 for i in range(7)]
    for i in range(0, len(day)):
        if day[i] == str(int(day[0])):
            news_count[0] += 1
        elif day[i] == str(int(day[0]) - 1):
            news_count[1] += 1
        elif day[i] == str(int(day[0]) - 2):
            news_count[2] += 1
        elif day[i] == str(int(day[0]) - 3):
            news_count[3] += 1
        elif day[i] == str(int(day[0]) - 4):
            news_count[4] += 1
        elif day[i] == str(int(day[0]) - 5):
            news_count[5] += 1
        else:
            news_count[6] += 1
    print(news_count)

    activities = []
    for i in range(7):
        activities.append(str(int(day[0]) - i))
    colors = ['red', 'blue', 'green', 'yellow', 'cyan', 'magenta', 'pink']
    plt.pie(news_count, labels=activities, colors=colors, startangle=90, autopct='%.2f%%')
    plt.show()
    
if __name__ == "__main__":
    main() 


