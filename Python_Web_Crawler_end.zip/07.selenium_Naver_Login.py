# 자동화 테스트를 위해 Selenium 모듈을 import 한다.
from selenium import webdriver

# Selenium에서 실행할 가상 chrome 웹 브라우저의 경로를 설정한다.
driver = webdriver.Chrome(".\chromedriver.exe")
# Selenium에서 chrome을 통해 네이버 로그인 화면에 접속한다.
driver.get("https://nid.naver.com/nidlogin.login")

import time # sleep() 함수를 사용하기 위해 time 모듈을 import 한다.

# 대형 포털 서비스는 너무 빠르게 다수의 로그인이 시도되면 트래픽 공격을 당하는 것으로 판단할
# 수 있으므로 time 패키지의 sleep() 함수를 사용해 일정 시간을 지연시키는 처리가 필요하다.
time.sleep(0.5) # 0.5초 만큼 프로그램을 멈춘다.
# 네이버 로그인 페이지에서 find_element_by_name() 메소드로 name 속성이 id인 input 태그에
# send_keys() 메소드로 아이디와 비밀번호를 입력한다.
driver.find_element_by_name("id").send_keys("본인아이디")
time.sleep(0.5)
driver.find_element_by_name("pw").send_keys("본인비밀번호")
time.sleep(0.5)

# find_element_by_xpath() 메소드로 로그인 버튼을 클릭한다.
driver.find_element_by_xpath('//*[@id="frmNIDLogin"]/fieldset/input').click()
