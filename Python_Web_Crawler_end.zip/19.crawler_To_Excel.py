from urllib.request import urlopen
from bs4 import BeautifulSoup
# pip install openpyxl==2.2.5를 실행해서 설치해야 한다.
from openpyxl import Workbook

def main():
    url = 'http://www.newsis.com/realnews/'
    soup = BeautifulSoup(urlopen(url).read(), 'html.parser')
    
    articles = []

    for news in soup.find_all('strong', class_='title'):
        # print(news.get_text())
        articles.append(news.get_text())
        wb = Workbook()
        sheet1 = wb.active
        file_name = 'output.xlsx'
        
        for i in range(0, len(articles)):
            sheet1.cell(row = i + 1, column = 1).value = i + 1
            sheet1.cell(row = i + 1, column = 2).value = articles[i]

        wb.save(filename=file_name)

if __name__ == "__main__":
    main() 

