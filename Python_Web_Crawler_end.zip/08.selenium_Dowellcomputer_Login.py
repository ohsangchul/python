from selenium import webdriver
from bs4 import BeautifulSoup as bs
import time

driver = webdriver.Chrome(".\chromedriver.exe")
driver.get("http://www.dowellcomputer.com/member/memberLoginForm.jsp")

time.sleep(0.5)
driver.find_element_by_name("memberID").send_keys("mkvryu")
time.sleep(0.5)
driver.find_element_by_name("memberPassword").send_keys("1234")
time.sleep(0.5)

driver.find_element_by_xpath("//*[@id='blackBox']/input[1]").click()

driver.get("http://www.dowellcomputer.com/study/study.jsp")
html = driver.page_source
soup = bs(html, 'html.parser')
title_list = soup.findAll('b')
for title in title_list:
    print(title.text)
