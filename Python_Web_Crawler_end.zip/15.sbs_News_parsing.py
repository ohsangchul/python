from urllib.request import urlopen
from bs4 import BeautifulSoup

'''
<div> 태그의 w_news_list 클래스로 모든 뉴스 항목이 묶여있다.
w_news_list 클래스의 순서에 따라서 아래와 같다.
 1. 주요 뉴스
 2. 헤드라인
 3. 헤드라인 하단
 4. 동영상 기사
 5. 연예 스포츠
 6. 주목 이 기사 - 좌측
 7. 주목 이 기사 - 우측
 8. 취재 파일
 9. 마작 부침
10. 더 저널리스트
11. 비디오 머그
12. 스브스 뉴스
13. 친절한 경제 - 메인
14. 친절한 경제 - 우측
15. 멀티미디어 - Pick
16. 멀티미디어 - 뉴스영상
17. 멀티미디어 - 리포트 +
18. 멀티미디어 - 김성준의 시사 전망대
19. 분야별 뉴스
20. 분야별 뉴스 - 우측 1
'''

def parsing():
    url = 'https://news.sbs.co.kr/news/newsMain.do?plink=GNB&cooper=SBSNEWS'
    soup = BeautifulSoup(urlopen(url), 'html.parser')
    # print(soup)

    # <div> 태그의 w_news_list 클래스 그룹 20개를 얻어온다.
    # w_news_list 클래스 그룹의 1번째인 주요 뉴스를 대상으로 파싱한다.
    news_list = soup.find_all('div', class_ = 'w_news_list')
    
    # 뉴스 제목
    news_title = []
    hot_news = news_list[0].find_all('strong')
    for hot in hot_news:
        str = hot.get_text()
        # print(' '.join(str.split()))
        news_title.append(' '.join(str.split()))
    print(news_title)
    print('=' * 80)
    
    # 뉴스 링크
    news_link = []
    hot_news = news_list[0].find_all('a')
    for hot in hot_news:
        # print('https://news.sbs.co.kr' + hot['href'])
        news_link.append('https://news.sbs.co.kr' + hot['href'])
    print(news_link)
    print('=' * 80)

    # 뉴스 내용
    news_content = []
    for link in news_link:
        soup = BeautifulSoup(urlopen(link), 'html.parser')
        content = soup.find('div', class_ = 'text_area').get_text()
        # print(content.replace('\n', ''))
        news_content.append(content.replace('\n', ''))
    print(news_content)
    print('=' * 80)
    
if __name__ == '__main__':
    parsing()













