#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import requests
from bs4 import BeautifulSoup


# In[ ]:


def getSubject(url):
    subjects = []
    
    request = requests.get(url)
    #print(request)
    
    html = request.text
    #print(html)
    
    soup = BeautifulSoup(html, 'html.parser')
    #print(soup)
    
    divs = soup.findAll('div', {'class':'su-column-inner su-clearfix'})
    
    for div in divs:
        subjects.append(div.text)

    return subjects


# In[ ]:


if __name__ == '__main__':
    url = 'https://basicenglishspeaking.com/daily-english-conversation-topics/'
    subjects = getSubject(url)
    
    for subjectList in range(len(subjects)):
        print('{}'.format(subjects[subjectList]))

