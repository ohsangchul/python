### 모듈의 특정 함수만 import 할 수 있다.
### 2개 이상의 함수를 한번에 import 할 수도 있다.
# from selectSort_19 import ascending
# from selectSort_19 import descending
# from selectSort_19 import *
from selectSort_19 import ascending, descending

if __name__ == '__main__':
     print('[Call] 19_3_selectSortModuleImport.py')
     numbers = []
     for index in map(int, input('정렬 할 숫자를 입력하세요 : ').split(' ')):
          numbers.append(index)
             
     choice = input('asc or des ? ')
     if 'asc' == choice.lower():
          print('오름차순 정렬 결과 : {}'.format(ascending(numbers)))
     elif 'des' == choice.lower():
          print('내림차순 정렬 결과 : {}'.format(descending(numbers)))
     else:
          print('잘못된 선택 입니다.')
