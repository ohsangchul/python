### set은 집합과 비슷한 형태로 순서가 없기 때문에 어떤 값이 먼저 출력될지 알 수 없고, 중복되는 데이터를 허용하지 않는다.
### 딕셔너리와 동일하게 {}로 선언하지만, key가 존재하지 않고 value만 존재한다.

#list = []
#tuple = ()
#dict = {}
#set()

s1 = set() # 빈 set. 반드시 빈 set은 생성자로 만들어야 한다.
print(set())
print(type(set()))
#==================== RESTART: D:/osc/workspace/09_set.py ====================
#set()
#<class 'set'>

s2 = set([1, 2, 3, 4]) # set 생성자의 인수로 list를 사용한다.
print(s2)
print(type(s2))
#==================== RESTART: D:/osc/workspace/09_set.py ====================
#{1, 2, 3, 4}
#<class 'set'>

s3 = {11, 5, 3, 3, 7, 3, 5, 7, 1} # 중복되는 값은 자동으로 제거된다.
print(s3)
print(type(s3))
#==================== RESTART: D:/osc/workspace/09_set.py ====================
#{1, 3, 5, 7}
#<class 'set'>

s4 = {'f', 'a', 'b', 'b', 'b', 'c', 'd', 'e', 'd', 'd', 'd'}
print(s4)
#==================== RESTART: D:/osc/workspace/09_set.py ====================
#{'f', 'a', 'd', 'e', 'b', 'c'}

# in 연산자 사용
print('a' in s4)
print('h' in s4)
print('h' not in s4) # 데이터가 존재하지 않을때 True를 리턴받기 위해 사용한다.
#==================== RESTART: D:/osc/workspace/09_set.py ====================
#True
#False
#True

### add() : set에 단일 데이터를 추가한다.
s4.add('가')
print(s4)
#==================== RESTART: D:/osc/workspace/09_set.py ====================
#{'a', '가', 'f', 'b', 'c', 'e', 'd'}

### update() : set에 리스트를 이용해서 여러개의 데이터를 추가한다.
s4.update([1, 2, 3])
print(s4)
#==================== RESTART: D:/osc/workspace/09_set.py ====================
#{1, 2, 'd', 3, '가', 'c', 'b', 'e', 'f', 'a'}

### remove() : set에 저장된 데이터를 제거한다. 제거할 데이터가 없을 경우 오류가 발생한다.
s4.remove('b')
print(s4)
#==================== RESTART: D:/osc/workspace/09_set.py ====================
#{1, 2, 3, 'a', '가', 'd', 'f', 'e', 'c'}

### discard() : set에 저장된 데이터를 제거한다. 제거할 데이터가 없어도 오류가 발생하지 않는다.
s4.discard('d')
print(s4)
#==================== RESTART: D:/osc/workspace/09_set.py ====================
#{'e', 1, 2, 3, 'f', '가', 'a', 'c'}

### copy() : set을 복사한다.
s5 = s4.copy()
print(s4)
print(s5)
#==================== RESTART: D:/osc/workspace/09_set.py ====================
#{1, 2, 3, 'a', 'f', 'e', '가', 'c'}
#{1, 2, 3, 'a', 'f', 'e', '가', 'c'}

# 생성자를 사용해서 set을 복사하기
s6 = set(s4)
print(s4)
print(s6)
#==================== RESTART: D:/osc/workspace/09_set.py ====================
#{1, 2, 3, 'c', 'f', '가', 'e', 'a'}
#{1, 2, 3, 'c', 'f', '가', 'e', 'a'}

a = {1, 2, 3, 4, 5}
b = {3, 4, 5, 6, 7}

### 합집합 : |, union()
print(a | b)
print(a.union(b))
#==================== RESTART: D:/osc/workspace/09_set.py ====================
#{1, 2, 3, 4, 5, 6, 7}
#{1, 2, 3, 4, 5, 6, 7}

### 교집합 : &, intersection()
print(a & b)
print(a.intersection(b))
#==================== RESTART: D:/osc/workspace/09_set.py ====================
#{3, 4, 5}
#{3, 4, 5}

### 차집합 : -, difference() (모수에 따라 결과가 달라진다.)
print(a - b)
print(a.difference(b))
print(b - a)
print(b.difference(a))
#==================== RESTART: D:/osc/workspace/09_set.py ====================
#{1, 2}
#{1, 2}
#{6, 7}
#{6, 7}

### 대칭 차집합(합집한- 교집합) : ^, symmetric_difference()
print(a ^ b)
print(a.symmetric_difference(b))
#==================== RESTART: D:/osc/workspace/09_set.py ====================
#{1, 2, 6, 7}
#{1, 2, 6, 7}
