#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import requests
from bs4 import BeautifulSoup


# In[ ]:


header = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.3; Trident/7.0; rv:11.0) like Geoko'}
request = requests.get('https://datalab.naver.com/keyword/realtimeList.naver?where=main', headers = header)
html = request.text
# print(html)
soup = BeautifulSoup(html, 'html.parser')
# print(soup)


# In[ ]:


age = input('연령대를 선택하세요(0:전체, 1:10대, 2:20대, 3:30대, 4:40대, 5:50대이상) : ')
ageList = {'0':'all', '1':'10s', '2':'20s', '3':'30s', '4':'40s', '5':'50s'}


# In[ ]:


words = soup.findAll('div', {'data-age' : ageList.get(age)})
ranks = words[0].findAll('span', {'class' : 'title'})

print('{} 검색어 순위'.format(ageList.get(age)))
for rank in range(len(ranks)):
    print('{0:2d}위 : {1}'.format(rank+1, ranks[rank].text))

