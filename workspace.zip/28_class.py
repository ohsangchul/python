#!/usr/bin/env python
# coding: utf-8

# In[ ]:


'''
class 클래스이름:
    # 생성자(constructor) : 클래스의 객체가 생성될때 자동으로 실행되는 메소드로 class의 멤버 변수를 초기화 한다.
    # 생성자는 __init__() 함수를 사용한다.
    def __init__(self, 인수, ...): # self는 필수. 인수가 사용되지 않으면 생략 가능하다.
        # 멤버 변수 : 변수 이름 앞에 self가 붙은 변수. 클래스 전체에서 사용 할 수 있다.
        # 지역 변수 : 변수 이름 앞에 self가 붙지 않는 변수. 선언된 멘소드 내부에서만 사용 할 수 있다.
        # 변수를 전역 변수로 지정해서 사용하기 위한 키워드를 정의하는 것으로 반드시 통일 되어야 한다.
        # 키워드는 시스템에서 정의된 함수 첫번째 인자로 설정한다.
        self.멤버변수 = 인수
    # 클랙스 객체에 저장된 데이터 출력에 사용되는 함수
    def __str__(self):
        return 출력할 내용(문자열)
'''


# In[ ]:


class firstClass: # firstClass start
    # self는 클래스 자신을 의미한다.
    def __init__(self):
        print('firstClass : 생성자는 클래스의 객체가 생성되는 순간 자동으로 실행 됩니다.')
        
    def __str__(self):
        return 'firstClass : 리턴되는 데이터는 __str__()에 정의 합니다.'
# firstClass end

class secondClass: # secondClass start
    # 인수를 받는 class에 객체 선언시 인수가 전달되지 않으면 오류가 발생한다.
    # 이럴때는 default 인수로 설정해서 값이 전달되지 않더라도 초기 값으로 동작하도록 한다.
    def __init__(self, data1=0, data2=0):
        self.data1 = data1; self.data2 = data2
        print('secondClass : 생성자는 클래스의 객체가 생성되는 순간 자동으로 실행 됩니다.')
        
    def __str__(self):
        return str(self.data1 + self.data2)
# secondClass end
        
class thirdClass: # thirdClass start
    def __init__(self, *num):
        self.data1 = 0; self.data2 = 0; self.data3 = 0
        if (len(num)) == 0:
            self.data1 = 0;
        elif (len(num)) == 1:
            self.data1 = num[0]
        elif (len(num)) == 2:
            self.data1 = num[0]; self.data2 = num[1]
        else:
            self.data1 = num[0]; self.data2 = num[1]; self.data3 = num[2]
        print('thirdClass : 생성자는 클래스의 객체가 생성되는 순간 자동으로 실행 됩니다.')
        
    def __str__(self):
        return str(self.data1 + self.data2 + self.data3)
# thirdClass end


# In[ ]:


# 객체이름 = 클래스이름([인수, ...])
'''
# __str__ 없을때
test1 = firstClass()
test2 = secondClass()
test2 = secondClass(1, 3)
test3 = thirdClass()
test3 = thirdClass(2)
test3 = thirdClass(2, 4)
test3 = thirdClass(2, 4, 6)
'''

# __str__() 있을때
print(firstClass())
print(secondClass())
print(secondClass(1, 3))
print(thirdClass())
print(thirdClass(2))
print(thirdClass(2, 4))
print(thirdClass(2, 4, 6))

