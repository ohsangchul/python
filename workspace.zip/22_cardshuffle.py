# 카드 섞어서 출력하기
import random as r

# 카드 출력에 필요한 숫자와 무늬를 기억하는 각각의 리스트를 만든다.
cardNum = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K']
pattern = ['♠', '◆', '♥', '♣']

# 빈 리스트를 만들어 52장의 카드를 세팅한다
'''
cards = []
for setting in range(52):
     cards.append(setting)
'''
cards = [setting for setting in range(52)]

# cards 리스트에 저장된 숫자를 한줄에 13개씩 출력한다
print('=' * 27, ' [asis] ', '=' * 27)
for view in range(52):
     #print('%2d ' % cards[view], end='') # 52장 카드 확인 (0~51)
     #print('%2s ' % cardNum[cards[view]%13], end='') # 각 라인별 숫자 세팅 (A~K)
     #print('%2s ' % pattern[cards[view]//13], end='') # 각 라인별 무늬 세팅 (♠, ◆, ♥, ♣)
     print('%2s%2s ' % (pattern[cards[view]//13], cardNum[cards[view]%13]), end='') # 숫자와 무늬 결합
     if (view+1)%13 == 0:
          print()

# 카드를 섞는다
for loop in range(1000):
     ran = r.randrange(0,52)
     cards[0], cards[ran] = cards[ran], cards[0]

# 섞은 카드를 출력한다
print('=' * 27, ' [tobe] ', '=' * 27)
for view in range(52):
     print('%2s%2s ' % (pattern[cards[view]//13], cardNum[cards[view]%13]), end='')
     if (view+1)%13 == 0:
          print()
