'''
# 1. 정렬할 숫자의 개수와 정렬할 숫자를 입력 받아서 정렬하기
import bubbleSort_19 as sort

if __name__ == '__main__':

    count = input('정렬할 숫자의 개수를 입력하세요 : ')

    numbers = []
    while True: # while start
        num = input('정렬할 숫자를 입력하세요 : ')
        numbers.append(int(num))

        if int(count) == len(numbers): # if start
            break
        # if end
    # while end

    choice = input('asc(오름차순) 또는 des(내림차순) 정렬을 선택하세요 : ')
    if 'asc' == choice.lower() or '오름차순' == choice or '오름' == choice:
        print('오름차순 정렬 결과 : {}'.format(sort.ascFunc(numbers)))
    elif 'des' == choice.lower() or '내림차순' == choice or '내림' == choice:
        print('내림차순 정렬 결과 : {}'.format(sort.desFunc(numbers)))
    else:
        print('정렬 방법을 잘못 선택 하셨습니다.')
'''

from bubbleSort_19 import ascFunc, desFunc

if __name__ == '__main__':
     num = int(input('정렬할 데이터의 개수 : '))

     data = [0 for count in range(num)]

     for index in range(num): # for1 start
          insert = int(input('{}번째 데이터 : '.format(index+1)))
          data[index] = insert
     # for1 end

     selectSort = int(input('정렬 방법 (오름:1/내림:2)'))

     if selectSort == 1:
          data = ascFunc(data)
     elif selectSort == 2:
          data = desFunc(data)
     else:
          print('정렬 방법을 잘못 선택 하셨습니다.')

     print('결과 : {}'.format(data))
