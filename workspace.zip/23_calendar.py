import calendarModule_23 as calendar

if __name__ == '__main__':
     year, month = map(int, input('보고싶은 달을 적어주세요(yyyy-mm) : ').split('-'))

     print('=' * 22)
     print('%9d년 %2d월' % (year, month))
     print('=' * 22)
     print('%2s%2s%2s%2s%2s%2s%2s' % ('일', '월', '화', '수', '목', '금', '토'))
     print('=' * 22)

     # 출력할 달의 1일부터 마지막 날짜까지 반복하면서 날짜를 출력한다.
     # 매달 1일이 시작하는 위치를 맞추기 위해 1일의 요일만큼 빈칸을 출력한다
     for space in range(calendar.weekDay(year, month, 1)):
          print('%3s' % '', end='')

     for day in range(1, calendar.lastDay(year, month)+1):
          # 출력할 날짜가 토요일이면 줄을 바꾼다.
          print(' %2d' % day, end='')
          if calendar.weekDay(year, month, day) == 6 and day != calendar.lastDay(year, month):
               print()

     print()
     print('=' * 22)

'''
import calendar as c

print(c.calendar(2019))
print(c.prcal(2019))
print(c.prmonth(2019, 7))
'''
