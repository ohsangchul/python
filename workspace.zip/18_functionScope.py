### 함수 내부와 외부의 변수 이름이 같더라도 다른 변수로 취급된다.
### global을 사용하면 함수 내부에서 함수 외부 변수의 값을 변경 할 수 있다. (call by reference)

def func1(num1):
     num1 += 1
     print('func1 내부 변수 값 : {}'.format(num1))

def func2():
     global num2
     num2 += 1
     print('func2 내부 변수 값 : {}'.format(num2))

if __name__ == '__main__':
     num1 = 1     
     func1(num1)
     print('func1 외부 변수 값 : {}'.format(num1))
     
     num2 = 999
     func2()
     print('func2 외부 변수 값 : {}'.format(num2))
#=============== RESTART: D:/osc/workspace/18_functionScope.py ===============
#func1 내부 변수 값 : 2
#func1 외부 변수 값 : 1
#func2 내부 변수 값 : 1000
#func2 외부 변수 값 : 1000
