def ascFunc(numbers): # def ascending start
     loop_count = len(numbers)
     for diff_num in range(loop_count): # for1 start
          # 한번 정렬을 수행하면 마지막 자리는 정렬이 완료된 숫자가 들어가기 때문에 다음 정렬시에는 비교할 필요가 없다.
          for index_num in range(loop_count-diff_num-1): # for2 start
               if numbers[index_num] < numbers[index_num+1]: # if1 start                    
                    numbers[index_num], numbers[index_num+1] = numbers[index_num+1], numbers[index_num]
               # if1 end
          # for2 end
          print('{}번째 정렬 결과 : {}'.format(diff_num+1, numbers))
     # for1 end
     return numbers
# def ascending end

def desFunc(numbers): # def descending start
     loop_count = len(numbers)
     for diff_num in range(loop_count): # for1 start
          for index_num in range(loop_count-diffx_num-1): # for2 start
               if numbers[index_num] > numbers[index_num+1]: # if1 start                    
                    numbers[index_num], numbers[index_num+1] = numbers[index_num+1], numbers[index_num]
               # if1 end
          # for2 end
     # for1 end
     return numbers
# def descending end
