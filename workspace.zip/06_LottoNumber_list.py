# random -> randrange() 함수를 사용하기 위해 모듈을 추가
import random as r # 이후 코드에서는 random을 r로 표기 하겠다.
# time -> sleep() 함수를 사용하기 위해 모듈을 추가
import time as t # 이후 코드에서는 time을 t로 표기 하겠다.

# 로또 추첨기를 준비한다.
# 로또 추첨기로 사용할 빈 리스트를 선언한다.
lotto = []

# 추첨기에 1~45의 공을 넣는다
for i in range(1, 46): # range(start:end) : "시작위치 ~ 끝위치-1"까지 증가한다. 기본 증가량은 '+1'이다.
     lotto.append(i) # i의 값을 리스트에 삽입

# 공이 잘 들어 갔는지 확인한다.
print('##### insert ball #####')
for i in range(0, 45):
     print('%02d ' % lotto[i], end = '') # 리스트의 인덱스 안에 있는 값을 출력
     if (i+1) % 15 == 0:
          print()
     
# 섞는다
# randrange(start, end) : "시작위치 ~ 끝위치-1" 사이의 무작위 수를 리턴한다. 반복 호출시 중복되는 값이 리턴 될수도 있다.
# lotto[0]와 lotto[1]~lotto[44] 사이의 값 중에서 핸덤한 위치의 값과 교환한다.
for i in range(0, 1000): # 많이 섞기 위해 횟수를 크게 한다.
     num = r.randrange(1, 45)
     lotto[0], lotto[num] = lotto[num], lotto[0]

# 공이 잘 섞였는지 확인한다.
print('##### mix ball #####')
for i in range(0, 45):
     print('%02d ' % lotto[i], end = '') # 리스트의 인덱스 안에 있는 값을 출력
     if (i+1) % 15 == 0:
          print()

# 6자리 번호를 출력한다.
print('##### pop-up ball #####')
print('추첨 번호 : ', end = '')
for i in range(0, 6):
     t.sleep(1) # sleep() : 인수로 지정된 시간만큼 프로그램을 잠깐 멈춘다. 단위는 '초'이다.
     print('%02d ' % lotto[i], end ='')
t.sleep(1)
print('보너스 : ', end = '')
t.sleep(1)
print('%02d' % lotto[6])