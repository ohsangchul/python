#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import requests
from bs4 import BeautifulSoup


# In[ ]:


# 사이트의 공지사항 데이터 가져오기
siteHtml = requests.get('http://dowellcomputer.com/main.jsp')
#print(siteHtml) # <Response [200]> : 정상접속 응답 코드 확인

htmlText = siteHtml.text
#print(htmlText)

soup = BeautifulSoup(htmlText, 'html.parser')
#print(soup)

# findAll('태그이름', ['속성이름':'속성값'])
# html 태그와 html 태그에 지정된 속성을 이용하는 크롤링
#notice = soup.findAll('td', {'class':'tail'})
#notice = soup.findAll('b') # 해당 태그값 모두 가져오기
#notice = soup.findAll('a')

# html 테그와 자식 선택자('>')를 이용한 크롤링
notice = soup.select('td > a')


# In[ ]:


for view in notice:    
    # has_attr('속성이름') : 인수로 지정된 속성값을 유무를 얻어온다. 지정된 속성이 없으면 False를 리턴한다.
    if view.has_attr('href'):
        # get('속성이름') : 인수로 지정된 속성값을 얻어온다
        if view.get('href').find('notice') > 0:
            print(view.text) # 태그 안에 입력된 문자열을 얻어온다.

