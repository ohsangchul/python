#!/usr/bin/env python
# coding: utf-8

# In[ ]:


class score:
    # score 클래스의 객체가 생성될때 이름과 3과목의 점수를 넘겨 받아 멤버 변수를 초기화 시킨다
    def __init__(self, name, data1, data2, data3):
        self.name = name
        self.data1 = data1
        self.data2 = data2
        self.data3 = data3
        self.total = data1 + data2 + data3
        self.avg = self.total / 3
    
    def __str__(self):
        return '이름:{}, 국어:{}, 영어:{}, 수학:{}, 총점:{}, 평균:{}'.format(self.name, self.data1, self.data2, self.data3, self.total, self.avg)


# In[ ]:


data = score('테스트', 100, 80, 90)
print(data)

