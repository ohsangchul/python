#!/usr/bin/env python
# coding: utf-8

# In[ ]:


# 부모 class 생성
class Parent:
    def __init__(self, name='임꺽정', gender=False):
        self.name = name; self.gender = gender
        print('부모 클래스의 생성자가 호출 되었습니다.')
    
    def __str__(self):
        return '{}({})'.format(self.name, '남' if self.gender else '여')


# In[ ]:


# 부모 class 테스트
parent1 = Parent()
print(parent1)

parent2 = Parent('홍길동', True)
print(parent2)


# In[ ]:


# 상속 : 부모 클래스에서 정의한 멤버 변수와 메소드를 자식 클래스에서 별도로 선언하지 않고도 선언한 것처럼 사용 할 수 있도록 해주는 기능을 말한다.


# In[ ]:


# 자식 class 생성
class Child(Parent):
    # 부모 클래스로부터 __init__(), __str__(), self.name, self.gender를 물려 받았다.
    
    def __init__(self, name='임꺽정', gender=False, age=0, nicname='의적'):
        # 부모 클래스로부터 상속받은 멤버 변수는 부모 클래스의 생성자를 호출해서 초기화한다.
        super().__init__(name, gender) # self.name = name; self.gender = gender
        self.age = age; self.nicname = nicname
        print('자식 클래스의 생성자가 호출 되었습니다.')        
    
    # 부모 클래스로부터 상속받은 __str__()함수는 이름과 성별만 출력이 가능하다.
    # 자식 클래스는 나이와 별명을 출력해야 한다.
    # 그렇기 때문에 다시 만들어서 사용해야 한다. => 메소드 재정의 (mathod override)
    def __str__(self):
        #return '{}({}) - {}, {}'.format(self.name, '여' if self.gender else '남', self.age, self.nicname)
        return super().__str__() + '- {}, {}'.format(self.age, self.nicname)


# In[ ]:


# 자식 class 테스트
child1 = Child()
print(child1)

child2 = Child('홍길동', True)
print(child2)

child3 = Child('로빈훗', True, 50, '도둑')
print(child3)

