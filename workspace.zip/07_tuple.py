### tuple은 list와 유사하나 ()로 둘러싸며, 수정 및 삭제가 불가능하다. 인덱싱과 슬라이싱 및 덧셈(이어 붙이기), 곱셈(반복)은 가능한다.

t1 = () # 빈 튜플
print(type(t1))
t2 = (1)
print(t2)
print(type(t2))
t3 = (1,) # 최소 2개 이상의 데이터가 있을 경우 사용하며, 1개의 데이터만 가지는 경우 반드시 ,를 찍어야 한다.
print(t3)
print(type(t3))
t4 = (1, 2, 3)
print(t4)
print(type(t4))
t5 = 1, 2, 3, 4, 5 # ()를 생략해도 변수 하나에 여러개의 데이터를 넣으면 튜플이 된다.
print(t5)
print(type(t5))
t6 = ('a', 'b', ('cd', 'ef')) # 튜플 내부에 다른 튜플을 포함 시킬수 있다.
print(t6)
print(type(t6))
#=================== RESTART: D:/osc/workspace/07_tuple.py ===================
#<class 'tuple'>
#1
#<class 'int'>
#(1,)
#<class 'tuple'>
#(1, 2, 3)
#<class 'tuple'>
#(1, 2, 3, 4, 5)
#<class 'tuple'>
#('a', 'b', ('cd', 'ef'))
#<class 'tuple'>

t7 = (1, 2, 'a', 'b')
print(t7)
print(t7[0])
print(t7[1:3])
#t7[0] = '가' # 에러 발생.
#del t7[0] # 에러 발생
#=================== RESTART: D:/osc/workspace/07_tuple.py ===================
#(1, 2, 'a', 'b')
#1
#(2, 'a')

print(t5 + t7)
print(t7 * 3)
print(len(t7))
#=================== RESTART: D:/osc/workspace/07_tuple.py ===================
#(1, 2, 3, 4, 5, 1, 2, 'a', 'b')
#(1, 2, 'a', 'b', 1, 2, 'a', 'b', 1, 2, 'a', 'b')
#4
