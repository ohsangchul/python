#!/usr/bin/env python
# coding: utf-8

# In[ ]:


# 코드를 줄이기 위해 as를 사용해서 단축 키워드를 만들거나 from Module import * 로 정의된 함수명을 바로 사용 할 수 있다
#import datetime
#import datetime as dt
#from datetime import *
from datetime import datetime as dt


# In[ ]:


#코드가 블록 단위로 실행되기 때문에 이전 블록에 있는 코드를 실행 하려면 이전 블록을 실행해야 한다.
#now = datetime.datetime.now()
#now = dt.datetime.now()
#now = datetime.now()
now = dt.now()     # 컴퓨터 시스템의 날짜와 시간을 얻어온다.
print(type(now))   # <class 'datetime.datetime'>
print(now)
print(now.year)    # 년
print(now.month)   # 월
print(now.day)     # 일
print(now.minute)  # 분
print(now.second)  # 초
print(now.microsecond)  # 밀리초
print(now.weekday())    # 요일 (월:0 ~ 일:6)


# In[ ]:


# strftime('출력서식')
# %Y : 년도 4자리
# %y : 년도 2자리
# %m : 월(숫자)
# %h : 월(영어, 단축)
# %B : 월(영어, 전체)
# %d : 일
# %a : 요일(단축)
# %A : 요일(전체)
print(now.strftime('%Y-%m-%d'))  # 2019-07-11
print(now.strftime('%y-%m-%d'))  # 19-07-11
print(now.strftime('%y-%h-%d'))  # 19-Jul-11
print(now.strftime('%y-%B-%d'))  # 19-July-11
print(now.strftime('%y-%B-%d %a'))  # 19-July-11 Thu
print(now.strftime('%y-%B-%d %A'))  # 19-July-11 Thursday

# %H : 시(24시)
# %I : 시(12시)
# %M : 분
# %S : 초
# %p : AM/PM
print(now.strftime('%H:%M:%S'))     # 20:15:46
print(now.strftime('%p %I:%M:%S'))  # PM 08:15:46

