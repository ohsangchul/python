### 함수의 구조
### def 함수명(인수, ...): # 인수 생략 가능
###      함수가 실행할 구문
###      ...
###      return 함수의 실행 결과 값 # return 생략 가능

# 두 값을 입력 받아 합계를 리턴하는 함수
def add1(n1, n2):
     return n1 + n2

num1, num2 = map(int, input('두 수를 입력 하세요 : ').split(' '))
total = add1(num1, num2)
print('합계 : %d' % total)

# 함수 정의가 먼저 선언 되어야 한다. 변수를 공통으로 사용 할 수 있기 때문에 인수 생략이 가능하다.
def add2():
     return n1 + n2

n1, n2 = map(int, input('두 수를 입력 하세요 : ').split(' '))
total = add2()
print('합계 : %d' % total)
#================== RESTART: D:/osc/workspace/17_function.py ==================
#두 수를 입력 하세요 : 1 2
#합계 : 3

def func1():
     # print('인자가 없는 함수 호출')
     # 함수가 끝나거나 return을 만나면 함수가 호출된 곳으로 되돌아간다.
     return '인자가 없는 함수 호출'

def func2(num1, num2):
     print('func2 : {} + {} = {}'.format(num1, num2, num1 + num2))

def func3(num1, num2, num3):
     print('func3 : {} + {} + {} = {}'.format(num1, num2, num3, num1 + num2 + num3))

def func4(num1 = 1, num2 = 2):
     print('func4 : {} + {} = {}'.format(num1, num2, num1 + num2))

def func5(num3):
     num1 = 1; num2 = 2
     print('func5 : {} + {} + {} = {}'.format(num1, num2, num3, num1 + num2, num3))

### 인수의 개수가 가변적일 경우 가인수를 '*변수명'으로 지정한다.
### '*변수명'으로 가인수를 지정하면 함수로 전달된 실인수 데이터를 tuple로 받아온다.
def func6(*args):
     print('func6 : {}'.format(type(args)))
     print('func6 : {}'.format(args))
     total = 0
     for data in args:
          total += data
     print('func6 data sum : {}'.format(total))

### 인수를 딕셔너리로 변한하기 위해서는 가인수를 '**변수명'으로 지정하면 된다.
### '**변수명'으로 가인수를 지정하면 함수로 전달된 실인수 데이터를 dictionary로 받아온다.
### 실인수를 '변수명=값'으로 전달하면 'key:value'로 처리한다.
def func7(**args):
     print('func7 : {}'.format(type(args)))
     print('func7 : {}'.format(args))

### 2개 이상의 데이터를 tuple로 리턴 할 수 있다.
def func8(num1, num2):
     # return (num1+num2, num1*num2)
     return num1+num2, num1*num2
     
### 파이썬은 오버로딩된 함수를 가질 수 없다.
### 인자 개수는 다르지만 동일한 이름을 가진 함수가 존재 할 경우 가장 마지막에 정의된 함수가 호출된다.
### 가변 인자를 사용하는 함수를 이용해서 오버로딩과 비슷한 효과를 낼 수는 있다.

if __name__ == '__main__': # main() 함수 역활. 프로그램의 시작점을 나타낸다.
     result = func1()
     print('func1 : {}'.format(result))

     data1 = 3; data2 = 5
     func2(data1, data2) # 전달하는 인수의 자료형은 무관하지만 데이터의 개수는 맞아야 한다.

     # 인수를 지정해서 함수를 호출 할 경우 반드시 실인수와 가인수의 이름이 같아야 한다.
     # 인수명이 같기 때문에 실인수를 전달할때 가인수의 정의 순서와 달라도 상관 없다. 해당 인수에 맞는 값이 적용된다.
     func3(num2 = 1, num3 = 2, num1 = 3)
     
     # 함수의 가인수가 값을 가지는 경우 실인수 값을 넘기지 않으면 가인수가 가진 값을 사용한다.
     func4(data1, data2)
     func4()

     func5(3)

     func6()
     func6(1)
     func6(1,2)
     func6(1,2,3)

     func7()
     func7(값1=1, 값2=2, 값3=3)

     ret = func8(2,3)
     ret1, ret2 = func8(2,3)
     print('func8 : {}'.format(type(ret)))
     print('func8 : {}, {} (index)'.format(ret[0], ret[1]))
     print('func8 : {}, {} (var)'.format(ret1, ret2))
#================== RESTART: D:\osc\workspace\17_function.py ==================
#func1 : 인자가 없는 함수 호출
#func2 : 3 + 5 = 8
#func3 : 3 + 1 + 2 = 6
#func4 : 3 + 5 = 8
#func4 : 1 + 2 = 3
#func5 : 1 + 2 + 3 = 3
#func6 : <class 'tuple'>
#func6 : () # 빈 튜플
#func6 data sum : 0
#func6 : (1,)
#func6 data sum : 1
#func6 : (1, 2)
#func6 data sum : 3
#func6 : (1, 2, 3)
#func6 data sum : 6
#func7 : <class 'dict'>
#func7 : {} # 빈 딕셔너리
#func7 : {'값1': 1, '값2': 2, '값3': 3}
#func8 : <class 'tuple'>
#func8 : 5, 6 (index)
#func8 : 5, 6 (var)
