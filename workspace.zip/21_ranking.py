if __name__ == '__main__':
     score = [70, 100, 84, 90, 85]
     rank = [1, 1, 1, 1, 1]

     for diff_num in range(len(score)-1): # for1 start
          for index_num in range(diff_num, len(score)): # for2 start
               if score[diff_num] > score[index_num]:
                    rank[index_num] += 1
               elif score[diff_num] < score[index_num]:
                    rank[diff_num] += 1
          # for2 end
     # for1 end

for view in range(len(score)):
     print('{0:3d}점은 {1}등 입니다.'.format(score[view], rank[view]))
     # 10점당 검은별 1개씩 출력하기
     # 5점 이상이면 흰색별 1개 출력하기
     for loop in range(score[view]//10):
             print('★', end='')
     # print('★' * (score[view]//10), end ='')
     if score[view]%10 >= 5:
          print('☆', end='')
     print()
