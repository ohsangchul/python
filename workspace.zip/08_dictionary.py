### dictionary : 대응 관계를 나타내는 자료형으로 key와 key에 할당되는 데이터(value)가 한쌍이 된다.
### {key : value, ...}와 같은 형태를 가지는 자료형이다.
### key : 일반적으로 string 타입의 데이터를 사용한다. 중복되는 key 사용시 마지막에 사용된 key의 value가 적용된다.
### value : key에 저장할 데이터를 입력한다

dic = {} # 빈 딕셔너리
print(dic)
dic = {'이름' : '홍길동', '전화번호' : '010-111-2222', '나이' : 50}
print(dic)
print(type(dic))
#================= RESTART: D:/osc/workspace/08_dictionary.py =================
#{}
#{'이름': '홍길동', '전화번호': '010-111-2222', '나이': 50}
#<class 'dict'>

# 딕셔너리에 데이터 추가 및 수정하기 (나열 순서와 상관없이 key를 기준으로 하기 때문에 가장 마지막에 추가된다.)
dic['거주지'] = '서울' # '딕셔너리이름[key] = value' 로 사용하며, 딕셔너리에 존재하지 않는 key에 데이터를 넣어주면 추가되고, 존재하는 key에 데이터를 넣어주면 데이터가 수정된다.
print(dic)
#================= RESTART: D:/osc/workspace/08_dictionary.py =================
#{'이름': '홍길동', '전화번호': '010-111-2222', '나이': 50, '거주지': '서울'}

# 딕셔너리 데이터 삭제하기
del dic['전화번호'] # 'del 딕셔너리이름[key]' 로 사용한다.
print(dic)
#================= RESTART: D:/osc/workspace/08_dictionary.py =================
#{'이름': '홍길동', '나이': 50, '거주지': '서울'}

# 딕셔너리에 저장된 value 얻어오기 : '딕셔너리이름[key]' 또는 '딕셔너리이름.get(key)' 를 사용하며, key가 없는 경우 오류가 발생한다.
print(dic['나이'])
print(dic.get('나이'))
#================= RESTART: D:/osc/workspace/08_dictionary.py =================
#50
#50

### keys() : 딕셔너리에서 key 목록만 얻어온다.
print(dic.keys())
print(type(dic.keys()))
#================= RESTART: D:/osc/workspace/08_dictionary.py =================
#dict_keys(['이름', '나이', '거주지'])
#<class 'dict_keys'>

### values() : 딕셔너리에서 value 목록만 얻어온다.
print(dic.values())
print(type(dic.values()))
#================= RESTART: D:/osc/workspace/08_dictionary.py =================
#dict_values(['홍길동', 50, '서울'])
#<class 'dict_values'>

### items() : 딕셔너리에서 key와 value를 쌍으로 묶은 듀플을 얻어온다.
print(dic.items())
print(type(dic.items()))
#================= RESTART: D:/osc/workspace/08_dictionary.py =================
#dict_items([('이름', '홍길동'), ('나이', 50), ('거주지', '서울')])
#<class 'dict_items'>

### in 연산자 : 'key in 딕셔너리이름' 로 사용하며, in의 앞에 위치한 key가 딕셔너리에 존재하면 True, 존재하지 않으면 Flase를 리턴한다. 존재하지 않을때 'not in'을 사용하면 True를 리턴한다.
print('이름' in dic)
print('전화번호' in dic)
print('전화번호' not in dic)
#================= RESTART: D:/osc/workspace/08_dictionary.py =================
#True
#False
#True

### clear() : 딕셔너리의 모든 데이터를 삭제한다.
dic.clear()
print(dic) # clear한 딕셔너리를 출력
print(dic.clear()) # clear한 딕셔너리 값을 출력
#================= RESTART: D:/osc/workspace/08_dictionary.py =================
#{}
#None
