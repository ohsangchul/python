### import 하는 Module 이름은 문자로 시작해야 한다.
### 사용자가 만든 파이썬선 파일도 import 시켜서 사용할 수 있다.
### import 하는 Module 이름이 긴 경우 as를 이용해서 별명을 지정할 수 있다.
### 별명이 지정되면 원래의 Module 이름은 사용하지 못한다.
import selectSort_19 as sort

if __name__ == '__main__':
     print('[Call] 19_1_selectSortModuleImport.py')
     numbers = []
     for index in map(int, input('정렬 할 숫자를 입력하세요 : ').split(' ')):
          numbers.append(index)
             
     choice = input('asc or des ? ')
     if 'asc' == choice.lower():
          print('오름차순 정렬 결과 : {}'.format(sort.ascending(numbers)))
     elif 'des' == choice.lower():
          print('내림차순 정렬 결과 : {}'.format(sort.descending(numbers)))
     else:
          print('잘못된 선택 입니다.')
