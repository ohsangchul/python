### 파일 열기
### 파일변수 = open('텍스트파일명', '파일열기모드')
### 파일 모드
### r : read (읽기 전용)
### w : write (쓰기 전용)
### a : append (쓰기, 추가)
### 파일 쓰기 모드는 파일이 없으면 파일을 만든 후 저장하고, 파일이 있으면 파일에 저장된 내용을 지우고 다시 저장한다. (덮어쓰기)
### 디스크에 저장된 파일을 열어서 작업을 한 후 반드시 파일을 닫아야 한다.

file = open('16_testData.txt', 'w') # 파일 열기
for i in range(1, 11):
    # 파일 변수에 write() 함수를 이용해서 출력한다.
    # \n : new line, 줄을 바꾼다.
    # \r : carriage return, 커서를 줄의 맨 처음으로 옮긴다.
    # file.write(str(i) + '\r\n')
    file.write('{0:02d}번째 줄 입니다.\r\n'.format(i))
file.close() # 파일 닫기
print('파일로 쓰기 완료')
#=============== RESTART: D:\osc\workspace\16_fileReadWrite.py ===============
#파일로 쓰기 완료

# 파일의 위치를 지정하는 방법은 절대 경로 지정 방식과 상대 경로 지정 방식이 있다.
# 절대 경로 : 파일이 저장된 디스크 드라이브의 최상위(root) 디렉토리(폴더)부터 텍스트 파일이 저장된 디렉토리 까지의 경로를 의미한다.
# 상대 경로 : 실행되는 파이썬 프로그램 파일이 위치한 디렉토리 부터 텍스트 파일이 저장된 디렉토리 까지의 경로를 의미한다.
#             .은 실행되는 파이썬 프로그램이 저장된 경로를 의미한다.
#             ..은 실행되는 파이썬 프로그램이 저장된 경로의 한단계 상위 경로를 의미한다.
# 파일의 위치를 지정할때 파일의 이름만 적으면 실행되는 파이썬 프로그램 파일이 위치한 디렉토리를 의미한다.
# 경로 지정시 디렉토리와 디렉토리, 디렉토리와 파일을 구분하기 위해 \\를 사용해야 한다.

# 키보드로 입력하는 문자열을 텍스트 파일로 저장하는 프로그램
# quit가 입력되면 저장을 종료한다. quit는 소대문자를 구분하지 않는다.
# filePath = 'D:\\osc\\workspace\\Data\\16_testData2.txt' # 절대경로
#filePath = '..\\workspace\\Data\\16_testData2.txt' # 상대경로 case1
filePath = '.\\Data\\16_testData2.txt' # 상대경로 case2
file = open(filePath, 'w')
while True:
    string = input('입력 >>> ')
    if string.upper() == 'QUIT': # string.lower() == 'quit'
        break    
    file.write(string + '\r\n')
file.close()
print('입력 데이터 파일로 쓰기 완료')
#=============== RESTART: D:\osc\workspace\16_fileReadWrite.py ===============
#입력 >>> 111
#입력 >>> 222
#입력 >>> 333
#입력 >>> 444
#입력 >>> 555
#입력 >>> quit
#입력 데이터 파일로 쓰기 완료

### 파일에서 읽기
### readline() : 파일의 데이터를 한줄씩 읽어들인다.
###              읽어들인 데이터를 출력하고 자동으로 줄을 바꾼다.
###              데이터가 없으면 None(False) 리턴한다.
filePath = '.\\Data\\16_testData3.txt'
file = open(filePath, 'r')
# 텍스트 파일에 데이터가 얼마나 있는지 알 수 없으므로 무한루프로 읽어 드린다.
while True:
    line = file.readline()
    #텍스트 파일에서 읽어들인 데이터가 없으면 무한 루프를 종료한다.
    if not line: # if len(line.strip()) == 0:
        break
    print(line, end ='')
file.close()
#=============== RESTART: D:\osc\workspace\16_fileReadWrite.py ===============
#111
#222
#333
#444
#555

### readlines() : 파일의 전체 데이터를를 한번에 읽어서 리스트로 얻어온다.
filePath = '.\\Data\\16_testData4.txt'
file = open(filePath, 'r')
lines = file.readlines()
print(lines)
print(type(lines))
for line in lines:
    if len(line.strip()) != 0:
        print(line, end='')
file.close()
#=============== RESTART: D:\osc\workspace\16_fileReadWrite.py ===============
#['111\n', '222\n', '333\n', '444\n', '555']
#<class 'list'>
#111
#222
#333
#444
#555

### Windows 환경에서 파이썬으로 파일을 처리 하는 경우 필수 체크 사항
### [폴더 및 검색 옵션] - [보기 탭] - [고급 설정] - [알려진 파일 형식의 확장명 숨기기] 체크 해제 여부

### read() : 파일의 전체 데이터를 한번에 읽어서 문자열로 얻어온다.
filePath = '.\\Data\\16_testData4.txt'
file = open(filePath, 'r')
string = file.read()
print(string)
print(type(string))
file.close()
#=============== RESTART: D:\osc\workspace\16_fileReadWrite.py ===============
#111
#222
#333
#444
#555
#<class 'str'>

###  파일에 데이터 추가하기
filePath = '.\\Data\\16_testData5.txt'
file = open(filePath, 'a')
for i in range(1, 11):
    file.write('{0:02d}번째 줄 입니다.\r\n'.format(i))
print('파일에 데이터 추가 완료')
file.close()
#=============== RESTART: D:\osc\workspace\16_fileReadWrite.py ===============
#파일에 데이터 추가 완료
