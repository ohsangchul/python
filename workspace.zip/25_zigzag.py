#!/usr/bin/env python
# coding: utf-8

# In[ ]:


data1 = [1*5 for loop in range(5)]     # [5, 5, 5, 5, 5]
print(data1)
data2 = [[1]*5 for loop in range(3)]   # [[1, 1, 1, 1, 1], [1, 1, 1, 1, 1], [1, 1, 1, 1, 1]]
print(data2)


# In[ ]:


# 2차원 배열을 이용해서 만들 결과물
#   1  2  3  4  5
#  10  9  8  7  6 
#  11 12 13 14 15 
#  20 19 18 17 16


# In[1]:


# 4행 5열 2차원 리스트 만들기
data = [[0]*5 for loop in range(4)]
#print(data)
count  = 0  # 1씩 증가하며 2차원 배열을 채울 값
start  = 0  # list의 행에 숫자가 채워지기 시작할 열
end    = 4  # list의 행에 숫자가 채워지는 마지말 열
switch = 1  # start 부터 end 까지 증가치


# In[ ]:


for loop1 in range(4):
    #print(data[loop1])
    for loop2 in range(start, end+switch, switch):
        count += 1
        data[loop1][loop2] = count
    start, end = end, start
    switch *= -1

for view1 in range(4):
    for view2 in range(5):
        print('%3d' % data[view1][view2], end='')
    print()

