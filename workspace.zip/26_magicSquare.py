#!/usr/bin/env python
# coding: utf-8

# In[ ]:


while True:
    squareNum = int(input('마방진을 만들 숫자(홀수)를 입력하세요 : '))
    if squareNum % 2 == 0:
        print('홀수만 입력하세요')
    else:
        break
        
magicSquare = [[0]*squareNum for loop in range(squareNum)]

# 처음 숫자가 채워질 위치를 정한다. (첫 줄 가운데 열)
row = 0
column = squareNum//2

#마방진 생성
for num in range(1, squareNum*squareNum+1):
    magicSquare[row][column] = num
    # 방금 채운 숫자가 squareNum의 배수이면 다음 숫자는 아랫줄에 채우고 배수가 아니면 오른쪽 위 방향으로 채운다.
    if num % squareNum == 0:
        row += 1
    else:
        row -= 1
        # 행이 list의 범위를 벗어나면(-1이 되면) 마지막행(squareNum-1) 위치로 변경한다.
        if row < 0:
            row = squareNum-1
        column += 1
        # 열이 list의 범위를 벗어나면 첫번째열(0열)로 위치를 변경한다.
        if column > squareNum-1:
            column = 0

# 마방진 출력
for view1 in range(squareNum):
    for view2 in range(squareNum):
        print('%3d' % magicSquare[view1][view2], end='')
    print()

