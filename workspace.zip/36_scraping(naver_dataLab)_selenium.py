#!/usr/bin/env python
# coding: utf-8

# In[ ]:


from selenium import webdriver
from bs4 import BeautifulSoup


# In[ ]:


# selenium에서 실행할 가상 크롬 웹 브라우저의 경로를 설정한다.
driver = webdriver.Chrome('D:\\osc\\tools\\chromedriver.exe')
# selenium에서 크롬을 통해서 지정된 url의 사이트에 접속한다.
driver.get("https://datalab.naver.com/keyword/realtimeList.naver?where=main")
# selenium으로 실행한 크롬 브라우저의 페이지 소스를 얻어온다.
html = driver.page_source
# print(html)
soup = BeautifulSoup(html, 'html.parser')
# print(soup)


# In[ ]:


age = input('연령대를 선택하세요(0 : 전체, 1 : 10대, 2 : 20대, 3 : 30대, 4 : 40대, 5 : 50대이상) : ')
ageList = {'0' : 'all', '1' : '10s', '2' : '20s', '3' : '30s', '4' : '40s', '5' : '50s'}


# In[ ]:


words = soup.findAll('div', {'data-age' : ageList.get(age)})
ranks = words[0].findAll('span', {'class' : 'title'})


# In[ ]:


print('{} 검색어 순위'.format(ageList.get(age)))
for rank in range(len(ranks)):
    print('{0:2d}위 : {1}'.format(rank+1, ranks[rank].text))

