
'''
오름차순 ascending
내림차순 descending

선택 정렬을 이용한 함수 구현
'''
 
def ascending(numbers): # def ascending start
     loof_count = len(numbers)     
     for index_num in range(loof_count): # for1 start          
          for diff_num in range(index_num+1, loof_count): # for2 start               
               if index_num == diff_num: # if1 start
                    break
               # if1 end                                                  
               if numbers[index_num] > numbers[diff_num]: # if2 start
                    # temp = numbers[index_num]
                    # numbers[index_num] = numbers[diff_num]
                    # numbers[diff_num] = temp
                    # 파이썬에는 tuple이 있기 때문에 다음과 같이 값 교환이 가능하다.
                    numbers[index_num], numbers[diff_num] = numbers[diff_num], numbers[index_num]
               # if2 end               
          # for2 end          
     # for1 end
     return numbers
# def ascending end

def descending(numbers): # def descending start
     loof_count = len(numbers)     
     for index_num in range(loof_count): # for1 start          
          for diff_num in range(index_num+1, loof_count): # for2 start               
               if index_num == diff_num: # if1 start
                    break
               # if1 end                                                  
               if numbers[index_num] < numbers[diff_num]: # if2 start
                    # temp = numbers[index_num]
                    # numbers[index_num] = numbers[diff_num]
                    # numbers[diff_num] = temp
                    # 파이썬에는 tuple이 있기 때문에 다음과 같이 값 교환이 가능하다.
                    numbers[index_num], numbers[diff_num] = numbers[diff_num], numbers[index_num]
               # if2 end               
          # for2 end          
     # for1 end
     return numbers
# def descending end

### if __name__ == '__main__' 사용 이유는 현재 파일이 다른 프로그램 파일에 import 되어 실행될때 호출되는 함수만 실행 되도록 하기 위해서이다.
### if __name__ == '__main__' 아래 코딩된 내용은 다른 프로그램에서는 실행되지 않는다.
if __name__ == '__main__':
     print('[Call] selectSort_19.py')
     numbers = []
     for index in map(int, input('정렬 할 숫자를 입력하세요 : ').split(' ')):
          numbers.append(index)
               
     choice = input('asc or des ? ')
     if 'asc' == choice.lower():
          print('오름차순 정렬 결과 : {}'.format(ascending(numbers)))
     elif 'des' == choice.lower():
          print('내림차순 정렬 결과 : {}'.format(descending(numbers)))
     else:
          print('잘못된 선택 입니다.')
