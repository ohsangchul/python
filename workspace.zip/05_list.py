### list : 데이터를 []로 감싸주고 각각의 데이터는 ,로 구분한다.
odd = [1, 3, 5, 7, 9]
print(odd)
print(type(odd))
#==================== RESTART: D:/osc/workspace/05_list.py ====================
#[1, 3, 5, 7, 9]
#<class 'list'>

# 여러가지 list 표현
array = [] # 빈 리스트. 사용할때마다 필요한 만큼 자동으로 확장된다.
print(array)
print(type(array))
# 생성자를 사용해서 빈 리스트를 만들수 있지만 사용 하지 않는다.
array = list()
print(array)
print(type(array))
#==================== RESTART: D:/osc/workspace/05_list.py ====================
#[]
#<class 'list'>
#[]
#<class 'list'>

num = [1, 2, 3] # 숫자 list
string = ['one', 'two', 'three'] # 문자 list
mix = [1, 2, 3, 'one', 'two', 'three'] # 숫자와 문자가 혼용된 list
multi = [1, 2, 3, ['one', 'two', 'three']] # 데이터 요소로 list를 가지는 list

# 리스트 인덱싱
print(num)
print(num[0])
print(num[0] + num[2])
print(num[-1])
#==================== RESTART: D:/osc/workspace/05_list.py ====================
#[1, 2, 3]
#1
#4
#3

print(multi[0])
print(multi[3])
print(multi[-1])
print(multi[3][0])
print(multi[-1][-1])
#==================== RESTART: D:/osc/workspace/05_list.py ====================
#1
#['one', 'two', 'three']
#['one', 'two', 'three']
#one
#three

multi2 = [1, 2, ['a', 'b', ['가', '나']]]
print(multi2[2])
print(multi2[2][2])
print(multi2[2][2][0])
print(multi2[-1][-1][-1])
#==================== RESTART: D:/osc/workspace/05_list.py ====================
#['a', 'b', ['가', '나']]
#['가', '나']
#가
#나

# 리스트 슬라이싱
num = [1, 2, 3, 4, 5]
print(num[0:2])
print(num[:2])
print(num[2:])
#==================== RESTART: D:/osc/workspace/05_list.py ====================
#[1, 2]
#[1, 2]
#[3, 4, 5]

print(multi[2:4])
print(multi[3][1:3])
#==================== RESTART: D:/osc/workspace/05_list.py ====================
#[3, ['one', 'two', 'three']]
#['two', 'three']

# 리스트 연산자 : +와 *만 사용 가능하다.
# +는 두개의 리스트를 이어주고, *는 리스트를 반복한다.
num = [1, 2, 3]
num2 = [4, 5, 6]
print(num + num2)
print(num * 3)
print(str(num[0]) + 'str')
#==================== RESTART: D:/osc/workspace/05_list.py ====================
#[1, 2, 3, 4, 5, 6]
#[1, 2, 3, 1, 2, 3, 1, 2, 3]
#1str

# 리스트의 수정
num = [1, 2, 3, 4, 5]
print(num[2])
print(type(num[2])) # 인덱싱으로 뽑아내면 상수가 리턴된다.
print(num[2:3])
print(type(num[2:3])) # 슬라이싱으로 뽑아내면 리스트가 리턴된다.
num[4] = 6
print(num)
num[2] = ['a', 'b', 'c'] # 인덱싱으로 수정하면 데이터가 type를 유지하며 치환된다.
print(num)
print(len(num))
print(num[1:4])
num[2:3] = ['a', 'b', 'c'] # 슬라이싱으로 수정하면 데이터 value만 치환된다.
print(num)
print(len(num))
#==================== RESTART: D:/osc/workspace/05_list.py ====================
#3
#<class 'int'>
#[3]
#<class 'list'>
#[1, 2, 3, 4, 6]
#[1, 2, ['a', 'b', 'c'], 4, 6]
#5
#[2, ['a', 'b', 'c'], 4]
#[1, 2, 'a', 'b', 'c', 4, 6]
#7

# 리스트의 삭제
num = [1, 2, 3, 4, 5]
num2 = [1, 2, 3, 4, 5]
num[1:4] = [] # 슬라이싱으로 삭제 할때는 []를 이용한다.
print(num)
del num2[2] # 인덱싱으로 삭제 할때는 del을 사용한다.
print(num2)
#==================== RESTART: D:/osc/workspace/05_list.py ====================
#[1, 5]
#[1, 2, 4, 5]

### 리스트 함수
### append() : 리스트의 가장 마지막에 데이터를 추가한다.
num = [1, 2, 3]
num.append(5)
print(num)
#==================== RESTART: D:/osc/workspace/05_list.py ====================
#[1, 2, 3, 5]

### insert() : 리스트의 특정 위치에 데이터를 삽입한다.
num.insert(3, 4)
num.insert(0, 'Start')
num.insert(-1, 'End') # -로 지정된 인덱스 앞에 삽입된다.
print(num)
#==================== RESTART: D:/osc/workspace/05_list.py ====================
#['Start', 1, 2, 3, 4, 'End', 5]

### sort() : 리스트에 저장된 데이터를 오름차순으로 정렬한다.
num = [1, 3, 5, 7, 9, 2, 4, 6, 8]
num.sort()
print(num)
num.sort(reverse = True) # 함수의 괄호안에 reverse = True 옵션을 지정하면 내림차순으로 정렬된다. 기본값은 False이다.
print(num)
#==================== RESTART: D:/osc/workspace/05_list.py ====================
#[1, 2, 3, 4, 5, 6, 7, 8, 9]
#[9, 8, 7, 6, 5, 4, 3, 2, 1]

### index() : 리스트에 저장된 데이터가 있을 경우 데이터의 위치를 리턴한다.
num = [1, 2, 3]
print(num.index(3))
print(num.index(1))
#print(num.index(0)) # 에러 발생. 데이터가 없으면 에러가 발생한다.
#==================== RESTART: D:/osc/workspace/05_list.py ====================
#2
#0

### remove() : 리스트에 저장된 데이터에서 가장 먼저 나오는 데이터를 제거한다.
num = [1, 1, 2, 2, 3, 3]
num.remove(2)
print(num)
num.remove(2)
print(num)
#num.remove(2) # 에러 발생. 데이터가 없으면 에러가 발생한다.
#==================== RESTART: D:/osc/workspace/05_list.py ====================
#[1, 1, 2, 3, 3]
#[1, 1, 3, 3]

### pop() : 리스트에 저장된 데이터를 리턴하고 그 데이터를 삭제한다.
num = [1, 2, 3, 4, 5]
ret = num.pop() # 데이터 위치를 지정하지 않으면 리스트의 가장 마지막 데이터를 리턴한다.
print(ret, num)
ret = num.pop(2) # 데이터 위치가 지정되면 지정된 위치의 데이터를 의미한다.
print(ret, num)
#==================== RESTART: D:/osc/workspace/05_list.py ====================
#5 [1, 2, 3, 4]
#3 [1, 2, 4]

### count() : 리스트에 포함된 특정 데이터의 개수를 얻어온다. 일치하는 데이터가 없으면 0을 리턴한다.
num = [1, 2, 2, 3, 3, 3, 4, 4, 4, 4, 5]
print(num.count(4))
#==================== RESTART: D:/osc/workspace/05_list.py ====================
#4

### extend() : 리스트를 확장한다. 리스트에 리스트를 더한다.
num = [1, 2, 3]
num.extend([4,5])
print(num)
num += [6, 7]
print(num)
string = ['a', 'b', 'c']
string = string + ['d', 'e']
print(string)
#==================== RESTART: D:/osc/workspace/05_list.py ====================
#[1, 2, 3, 4, 5]
#[1, 2, 3, 4, 5, 6, 7]
#['a', 'b', 'c', 'd', 'e']

### reverse() : 리스트에 저장된 데이터를 역순으로 전환한다.
num = [1, 2, 3, 4, 5]
num.reverse()
print(num)
#==================== RESTART: D:/osc/workspace/05_list.py ====================
#[5, 4, 3, 2, 1]

### 연산자의 우선순위
### () -> 단항연산자 -> 이항연산자 -> 삼항연산자 -> 대입연산자
