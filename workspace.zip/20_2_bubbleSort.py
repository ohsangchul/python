# 정렬중 정렬이 완료될 경우 정렬을 종료하기
def ascFunc(numbers): # def ascending start
     loop_count = len(numbers)
     for diff_num in range(loop_count): # for1 start
          flag = True
          for index_num in range(loop_count-diff_num-1): # for2 start
               if numbers[index_num] < numbers[index_num+1]: # if1 start                    
                    numbers[index_num], numbers[index_num+1] = numbers[index_num+1], numbers[index_num]
                    flag = False
               # if1 end
          # for2 end
          if flag:
               break
          print('{}번째 정렬 결과 : {}'.format(diff_num+1, numbers))
     # for1 end
     return numbers
# def ascending end

def desFunc(numbers): # def descending start
     loop_count = len(numbers)
     for diff_num in range(loop_count): # for1 start
          flag = True
          for index_num in range(loop_count-diff_num-1): # for2 start
               if numbers[index_num] > numbers[index_num+1]: # if1 start                    
                    numbers[index_num], numbers[index_num+1] = numbers[index_num+1], numbers[index_num]
                    flag = False
               # if1 end
          # for2 end
          if flag:
               break
          print('{}번째 정렬 결과 : {}'.format(diff_num+1, numbers))
     # for1 end
     return numbers
# def descending end
