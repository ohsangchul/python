### 변수명 작성 방법
### 영문 대소문자, 숫자, 특수문자(_) 사용 가능
### 반드시 문자로 시작해야 하며, Python 예약어는 사용할 수 없다.
### 변수의 자료형을 지정하지 않는다.
### 변수를 삭제 하려면 del 명령을 사용한다.

name = '홍길동'
print(type(name))
age = 35
print(type(age))
hight = 180.1
print(type(hight))
gender = True # True, False 첫 글자는 대문자로 쓴다.
print(type(gender))
none = None
print(type(none))
del name # 메모리 해제
age = '활빈당'
print(type(age))
#=================== RESTART: D:/osc/workspace/02_input.py ===================
#<class 'str'>
#<class 'int'>
#<class 'float'>
#<class 'bool'>
#<class 'NoneType'>
#<class 'str'>

print('이름을 입력하세요 : ', end = '')
name = input()
print('%s님 안녕하세요.' % name)
#=================== RESTART: D:/osc/workspace/02_input.py ===================
#이름을 입력하세요 : 홍길동
#홍길동님 안녕하세요.

name = input('이름을 입력하세요 : ')
print('%s님 안녕하세요.' % name)
#=================== RESTART: D:/osc/workspace/02_input.py ===================
#이름을 입력하세요 : 홍길동
#홍길동님 안녕하세요.

### input() 함수는 데이터를 무조건 문자열로 입력받는다.
### 문자열로 입력받은 데이러틑 숫자로 변환 할 때는 int() 또는 float()를 사용한다.
name = input('이름을 입력하세요 : ')
age = int(input('나이를 입력하세요 : '))
print('%s님은 %d입니다.' % (name, age))
print('{}님은 {}입니다.'.format(name, age)) # 출력 형식을 지정할 수 없을 경우 출력 인덱스를 사용한다.
print('{}님은 내년에 {}살입니다.'.format(name, age+1))
#=================== RESTART: D:/osc/workspace/02_input.py ===================
#이름을 입력하세요 : 홍길동
#나이를 입력하세요 : 35
#홍길동님은 35입니다.
#홍길동님은 35입니다.
#홍길동님은 내년에 36살입니다.

### 여러줄 주석시 '''  '''를 사용한다

### split(구분자) : 문자열을 구분자를 경계로 나눈다.
name, age = input('이름과 나이를 입력하세요 : ').split(' ')
name, age = input('이름과 나이를 입력하세요 : ').split(',')
print('{}님은 올해 {}살입니다.'.format(name, age))
print('{}님은 내년에 {}살입니다.'.format(name, int(age)+1))
print('{}님은 올해 {}살입니다.'.format(name, float(age)))
#=================== RESTART: D:/osc/workspace/02_input.py ===================
#이름과 나이를 입력하세요 : 홍길동 35
#이름과 나이를 입력하세요 : 홍길동,35
#홍길동님은 올해 35살입니다.
#홍길동님은 내년에 36살입니다.
#홍길동님은 올해 35.0살입니다.

### map() 함수를 사용해서 입력받은 데이터를 일괄적으로 숫자로 변환시킬수 있다.
### 변수+상수 : 오류
a, b, c = input('3과목 점수를 입력하세요 : ').split(' ')
print('총점 : {}'.format(a+b+c))
a, b, c = map(int, input('3과목 점수를 입력하세요 : ').split(' '))
print('총점 : {}'.format(a+b+c))
#=================== RESTART: D:/osc/workspace/02_input.py ===================
#3과목 점수를 입력하세요 : 10 20 30
#총점 : 102030
#3과목 점수를 입력하세요 : 10 20 30
#총점 : 60
