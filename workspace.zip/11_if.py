### if 조건식:
###    조건식이 참일 경우 실행할 구문
###    ...
### elif 조건식:
###    조건식이 참일 경우 실행할 구문
###    ...
### else:
###    조건식이 거짓일 경우 실행할 구문
###    ...

### 관계연산자 (연산 결과는 무조건 True 또는 False 이다.)
### >  : 크다, 초과
### >= : 크거나 같다, 이상
### <  : 작다, 미만
### <= : 작거나 같다, 이하
### == : 같다
### != : 같지 않다.

### 논리연산자 (연산 결과는 무조건 True 또는 False 이다.)
### and : 논리곱, 두 조건이 모두 참일 경우에만 참, ~이고, ~이면서, ~중에서
### or  : 논리합, 두 조선중 한 개 이상 참일 경우에 참, ~또는, ~이거나
### not : 논리부정, True는 False로 False는 True로 처리한다.

age = int(input('나이를 입력하세요 : '))
if age >= 19:
     # print('성인 입니다.')
     pass # 조건처리 또는 예외처리 진입시 아무런 내용이 없으면 오류가 발생한다. 이럴 경우 pass를 사용해서 아무런 처리 없이 진행 시킬수있다.
else:
     print('미성년자 입니다.')
#===================== RESTART: D:/osc/workspace/11_if.py =====================
#나이를 입력하세요 : 20

p1, p2, p3 = map(int, input('점수를 3개 입력하시오 : ').split())
total = p1 + p2 + p3
avg = total / 3
if avg >= 90:
     print('평균 점수 : %.1f, 등급 : A' % avg)
elif avg >= 80 and avg < 90:
     print('평균 점수 : %.1f, 등급 : B' % avg)
elif 70 <= avg < 80: # 파이썬에서는 해당 문법을 허용한다.
     print('평균 점수 : %.1f, 등급 : C' % avg)
elif avg >= 60:
     print('평균 점수 : %.1f, 등급 : D' % avg)
else:
     print('평균 점수 : %.1f, 등급 : E' % avg)
#===================== RESTART: D:/osc/workspace/11_if.py =====================
#점수를 3개 입력하시오 : 99 98 99
#평균 점수 : 98.7, 등급 : A

idn = input('주민등록번호 13자리를 "-" 없이 입력하세요 : ')
if idn[6] == '1' or idn[6] == '3': # 문자열로 비교
     print('남자 입니다.')
else:
     print('여자 입니다.')
     
if int(idn[6]) == 1 or int(idn[6]) == 3: # 숫자로 변환해서 비교
     print('남자 입니다.')
else:
     print('여자 입니다.')
     
if int(idn[6]) % 2 == 1: # 숫자로 변환 후 규칙성으로 비교
     print('남자 입니다.')
else:
     print('여자 입니다.')
#===================== RESTART: D:/osc/workspace/11_if.py =====================
#주민등록번호 13자리를 "-" 없이 입력하세요 : 8111111111111
#남자 입니다.
#남자 입니다.
#남자 입니다.

idn = input('주민등록번호 13자리를 "-" 없이 입력하세요 : ')
year = int(idn[0:2])
sex = int(idn[6])
if sex <= 2:
     year += 1900
else:
     year += 2000
print('당신의 출생년도 : {}년, 당신의 나이는 : {}살'.format(year, 2019-year))
#===================== RESTART: D:/osc/workspace/11_if.py =====================
#주민등록번호 13자리를 "-" 없이 입력하세요 : 8111111111111
#당신의 출생년도 : 1981년, 당신의 나이는 : 38살

### if문 조건을 비교해서 참이거나 거짓일때 실행할 구문이 각각 하나씩일 경우 3항 연산자를 사용해서 처리할 수 있다.
### '조건이 참일 경우 실행할 구문' if '조건식' else '조건식이 거짓일 경우 실행할 구문'
# year += 1900 if sex <= 2 else 2000

# 윤년/평년 판별식
# 년도가 4로 나누어 떨어지고, 100으로 나누어 떨어지지 않거나, 400으로 나누어 떨어지면 윤년이다.
year = int(input('년도를 입력하세요 : '))
print('윤년 입니다.') if year % 4 == 0 and year % 100 != 0 or year % 400 == 0 else print('평년 입니다.')

# 가위/바위/보 대결
import random as r
# 가위 : 1
# 바위 : 2
# 보   : 3
cpu = r.randrange(1, 4)
user = input('"가위/바위/보"를 입력하세요 : ')

if cpu == 1:
     cpu = '가위'
elif cpu == 2:
     cpu ='바위'
else:
     cpu = '보'

print('CPU({}) vs USER({})'.format(cpu, user))

if (cpu == '보' and user == '가위') or (cpu == '가위' and user == '바위') or (cpu == '바위' and user == '보'):
     print('결과 : USER가 이겼습니다.')
elif (cpu == '가위' and user == '보') or (cpu == '바위' and user == '가위') or (cpu == '보' and user == '바위'):
     print('결과 : CPU가 이겼습니다.')
else:
     print('결과 : 비겼습니다.')
