#!/usr/bin/env python
# coding: utf-8

# In[ ]:


# 프로그램이 동작할때 잘못 실행되는 것을 방지하기 위해 오류가 발생된다.
# try ~ except를 사용하면 오류가 발생 되었을때 별도의 처리를 하거나 무시하고 실행 할 수 있다.
# 오류가 발생될 것으로 예상되는 문장을 try 블록에 쓰고 해당 블록에 있는 코드가 실행중 오류가 발생하면 except 블록에 있는 코드가 실행된다.
'''
try:
    오류가 발생될 것으로 예상되는 문장
    ...
except [오류이름 [as 오류 변수]]:
    # except에 오류 이름을 쓰지 않으면 모든 오류에 대해서 except가 실행된다.
    # except에 오류 이름을 지정하면 해당 오류 발생시에만 except가 실행된다.
    # 오류가 발생하면 실행 할 문장
    # 오류 발생시 아무런 동작을 하지 않으려면 pass를 사용한다.    
    ...
finally:
    # 오류 발생 여부와 관계없이 무조건 실행되는 문장
    ...
'''


# In[12]:


#print(4/0) # ZeroDivisionError: division by zero

try:
    print(4/0)
except ZeroDivisionError as e:
    print('나눗셈 모수로 0을 사용 할 수 없습니다.')
except:
    pass


# In[11]:


data =[1,2,3]
#print(data[3]) # IndexError: list index out of range

try:
    print(data[3])
except IndexError:
    print('리스트의 인덱스가 맞지 않습니다.')
except:
    pass
finally:
    print('오류가 발생 여부와 상관없이 출력된 메시지 입니다.')


# In[ ]:





# In[ ]:




