### import 하려는 모듈이 현재 프로그램과 같은 위치에 있지 않을 경우 해당 경로를 포함해서 적어준다.
### 하위 폴더에 존재하는 경우 \가 아닌 .으로 depth를 표시한다.
### 다른 드라이브나 상위 경로에 위치한 경우 전체 경로를 system에 등록해준다.
### 여러 경로에서 가져오는 경우 append를 통해 계속 추가 할 수 있다.
# import sys
# sys.path.append('D:\osc\workspace\lib_19')
# import selectSort_19 as sort
### 사용 예) pip를 사용해서 설치한 외부 라이브러리는 파이썬이 설치된 폴더 아래 libs 폴더에 설치된다. 이 경우 해당 경로를 등록해준다.

import lib_19.selectSort_19 as sort

if __name__ == '__main__':
     print('[Call] 19_2_selectSortModuleImport.py')
     numbers = []
     for index in map(int, input('정렬 할 숫자를 입력하세요 : ').split(' ')):
          numbers.append(index)
             
     choice = input('asc or des ? ')
     if 'asc' == choice.lower():
          print('오름차순 정렬 결과 : {}'.format(sort.ascending(numbers)))
     elif 'des' == choice.lower():
          print('내림차순 정렬 결과 : {}'.format(sort.descending(numbers)))
     else:
          print('잘못된 선택 입니다.')
