#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import requests
from bs4 import BeautifulSoup


# In[ ]:


header = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36'}
request = requests.get('https://music.bugs.co.kr/chart/', headers = header)
#print(request)
    
html = request.text
#print(html)
    
soup = BeautifulSoup(html, 'html.parser')
#print(soup)


# In[ ]:


ranks = soup.findAll('p', {'class' : 'title'})
artists = soup.findAll('p', {'class' : 'artist'})

fileSave = open('busgMusicTop100.txt', 'w', encoding="utf-8")
for musicList in range(len(ranks)):
    ranks[musicList] = ranks[musicList].text.strip().split('\n')[0]
    artists[musicList] = artists[musicList].text.strip().split('\n')[0]
    data = '[{0:3d}] {1} - {2}'.format(musicList+1, ranks[musicList], artists[musicList])
    fileSave.write(data + '\n')
fileSave.close()


# In[ ]:


fileRead = open('busgMusicTop100.txt', 'r', encoding="utf-8")
for musicList in range(len(ranks)):
    print(fileRead.readline(), end='')
fileRead.close()

