'''
# 2. end가 입력되기 전까지 무제한으로 숫자를 입력 받은 후 정렬하기
import bubbleSort_19 as sort

if __name__ == '__main__':

    numbers = []
    while True: # while start
        num = input('정렬할 숫자를 입력하세요. 입력을 마치시려면 end(끝)를 입력하세요 : ')
        if num.lower() == 'end' or num == '끝': # if start
            break
        else:
            numbers.append(int(num))
        # if end        
    # while end

    choice = input('asc(오름차순) 또는 des(내림차순) 정렬을 선택하세요 : ')
    if 'asc' == choice.lower() or '오름차순' == choice or '오름' == choice:
        print('오름차순 정렬 결과 : {}'.format(sort.ascFunc(numbers)))
    elif 'des' == choice.lower() or '내림차순' == choice or '내림' == choice:
        print('내림차순 정렬 결과 : {}'.format(sort.desFunc(numbers)))
    else:
        print('정렬 방법을 잘못 선택 하셨습니다.')
'''

from bubbleSort_19 import ascFunc, desFunc

if __name__ == '__main__':
     data = []
     count = 0
     while True: # while1 start
          count += 1
          insert = int(input('{}번째 데이터 : '.format(count)))
          if insert == 999:
               break
          data.append(insert)          
     # while1 end

     selectSort = int(input('정렬 방법 (오름:1/내림:2)'))

     if selectSort == 1:
          data = ascFunc(data)
     elif selectSort == 2:
          data = desFunc(data)
     else:
          print('정렬 방법을 잘못 선택 하셨습니다.')

     print('결과 : {}'.format(data))
