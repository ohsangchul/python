# 버블 정렬을 이용한 오름차순(ascending), 내림차순(descending) 함수
def ascFunc(numbers): # def ascending start
     loop_count = len(numbers)
     for index_num in range(loop_count): # for1 start
          for diff_num in range(loop_count-1): # for2 start               
               if numbers[diff_num] < numbers[diff_num+1]: # if1 start                    
                    numbers[diff_num], numbers[diff_num+1] = numbers[diff_num+1], numbers[diff_num]
               # if1 end
          # for2 end
     # for1 end
     return numbers
# def ascending end

def desFunc(numbers): # def descending start
     loop_count = len(numbers)
     for index_num in range(loop_count): # for1 start
          for diff_num in range(loop_count-1): # for2 start               
               if numbers[diff_num] > numbers[diff_num+1]: # if1 start                    
                    numbers[diff_num], numbers[diff_num+1] = numbers[diff_num+1], numbers[diff_num]
               # if1 end
          # for2 end
     # for1 end
     return numbers
# def descending end

