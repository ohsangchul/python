### ''나 ""로 묶어주면 문자열 데이터로 취급한다.
memo = '첫번째 메시지'
memo2 = '두번째\n메모'
print(memo)
print(memo2)
#=================== RESTART: D:/osc/workspace/03_string.py ===================
#첫번째 메시지
#두번째
#메모

### ''나 ""를 3개 사용하면 여러줄을 하나의 문자열로 표현할 수 있다.
### '''는 여러줄 주석과 혼동이 있을 수 있으므로 """를 사용한다.
memo = """첫째줄
둘째줄
셋째줄"""
print(memo)
#=================== RESTART: D:/osc/workspace/03_string.py ===================
#첫째줄
#둘째줄
#셋째줄

string = '동해물과 백두산이 마르고 닳도록 하느님이 보우하사 우리나라 만세~'
### 인덱싱 : 문자열내 특정 위치의 문자를 얻어온다.
print('인덱싱 : ' + string[0])
print('인덱싱(-) : ' + string[-1])
### 슬라이싱 : 문자열을 잘라낸다.
### [시작위치:끝위치]로 구간을 지정하면 "시작위치 ~ 끝위치-1" 사이의 문자를 얻어온다.
print('슬라이싱 : ' + string[0:9])
print('슬라이싱 : ' + string[:9]) # 시작위치를 생략하면 처음부터
print('슬라이싱 : ' + string[10:]) # 끝위치를 생략하면 마지막까지

# 문자열 인덱싱을 이용한 문자열 수정
string = 'Pithon'
print(string)
print(string[1])
# 문자열은 부분 수정을 할 수 없다.
#string[1] = 'y' # 에러 발생.
#=================== RESTART: D:/osc/workspace/03_string.py ===================
#pithon
#i
print(string[:1])
print(string[2:])
string = string[:1] + 'y' + string[2:]
print(string)
#=================== RESTART: D:/osc/workspace/03_string.py ===================
#P
#thon
#Python

