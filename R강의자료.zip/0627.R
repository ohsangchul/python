# for를 이용한 반복처리

# for(변수 in 반복횟수) {
#    반복할 문장
#    ...
# }

for(i in 1:5) { # i가 1부터 5까지 1씩 증가하면서 반복한다.
    print(i)
}
for(i in 5:1) { # i가 5부터 1까지 1씩 감소하면서 반복한다.
    print(i)
}
for(i in c(1, 3, 5, 7, 9)) { # i가 1, 3, 5, 7, 9로 변경되며 반복한다.
    print(i)
}
# seq(초기치, 최종치, by = 증가치)
# by 옵션이가 생략되면 증가치는 1이 기본값이고 by를 생략하고 증가치만 쓸 수 있다.
for(i in seq(1, 10, by = 2)) { # i가 1부터 10까지 2씩 증가하면서 반복한다.
    print(i)
}
for(i in seq(10, 1, -2)) { # i가 10부터 1까지 2씩 감소하면서 반복한다.
    print(i)
}

##################################################################################

# 반복문을 사용해서 여러 페이지 읽어오기

library(rvest)
# 웹 스크레이핑 할 때 변경되지 않는 주소 부분을 저장해둔다.
site <- 'https://movie.naver.com/movie/point/af/list.nhn?&page='
# 여러 페이지에서 읽어온 리뷰를 합칠 기억장소를 선언하고 초기화한다.
movie_review <- NULL
# 읽어올 페이지 분량만큼 반복하며 리뷰를 읽는다.
for(i in 1:100) {
    # paste() 함수를 이용해 변경되지 않는 주소와 변경되는 주소를 이어 붙여서
    # 웹 스크레이핑할 주소를 완성한다.
    url <- paste(site, i, sep = '')
    # print(url)
    content <- read_html(url, encoding = 'CP949')
    
    # 한 페이지 스크레이핑이 완료된 후 다음 페이지가 로드되는 시간동안 잠깐
    # 스크레이핑을 멈춰주는 동작이 필요하다. => 페이지가 전환된 후에 넣어준다.
    Sys.sleep(0.5) # 시간은 초 단위로 지정한다.

    nodes <- html_nodes(content, '.movie')
    movie <- html_text(nodes, trim = T)
    nodes <- html_nodes(content, '.point')
    point <- html_text(nodes, trim = T)
    nodes <- html_nodes(content, '.title')
    title <- html_text(nodes, trim = T)
    title <- gsub('[[:punct:][:cntrl:]]', '', title)
    title <- gsub('신고', '', title)
    
    # 리뷰 작성일을 얻어온다.
    # 글번호에 지정된 클래스가 ac와 num이고 작성일에 지정된 클래스가 num이기 때문
    # 에 작성일만 얻어오는 것이 아니고 글번호까지 얻어온다.
    # nodes에 저장된 데이터를 출력해서 구조를 보면 홀수행이 ac와 num 클래스가 지정
    # 된 글번호이고 짝수행 num 클래스만 지정된 작성일이라는 것을 알 수 있다.
    nodes <- html_nodes(content, '.num')
    # 글번호와 작성일 중에서 작성일만 얻어오기 위해 아래와 같이 반복하며 작성일만
    # 뽑아낸다.
    date <- NULL
    for(i in seq(2, 20, 2)) {
        temp <- html_text(nodes[i])
        # print(temp)
        # temp에는 'bbgs****19.06.27'와 같은 형태의 데이터가 저장되고 작성일만
        # 뽑아내야 하기 때문에 substr() 함수를 사용해 작성일만 뽑아낸다.
        # substr(문자열, 시작위치, 종료위치) 
        # print(substr(temp, 9, 16))
        date <- c(date, substr(temp, 9, 16))
    }
    
    # 함수를 사용해서 제목, 평점, 리뷰, 작성일을 합친다.
    page <- cbind(movie, point)
    page <- cbind(page, title)
    page <- cbind(page, date)
    # print(page)
    
    # movie_review에 rbind() 함수로 한 페이지씩 스크레이핑 한 데이터를 합쳐준다.
    movie_review <- rbind(movie_review, page)
}

movie_review

# 최종 스크레이핑 된 데이터는 matrix 타입이기 때문에 데이터 처리를 위해서 데이터
# 프레임 형태로 변환시킨다.
movie_review <- as.data.frame(movie_review)
class(movie_review)
# 웹 스크레이핑 된 내용을 csv 파일로 저장시킨다.
write.csv(movie_review, 'movie_review.csv')

##################################################################################

# csv 파일을 read.csv() 함수로 읽으면 데이터 프레임 타입으로 읽어오므로 별도로
# 데이터 타입을 변환시킬 필요없다.
movie_review <- read.csv('movie_review.csv')
class(movie_review)
class(movie_review$movie) # factor
# csv 파일의 데이터를 read.csv() 함수로 읽어오면 문자 데이터는 벡터 타입이 아니라
# 펙터 타입으로 읽어오기 때문에 read.csv() 함수에 stringsAsFactors = F 옵션을
# 지정해서 읽거나 as.character() 함수를 사용해서 펙터 타입의 데이터를 벡터 타입
# 으로 변환한 후 작업한다.
movie_review$movie <- as.character(movie_review$movie)
movie_review$point <- as.character(movie_review$point)
movie_review$title <- as.character(movie_review$title)
movie_review$date <- as.character(movie_review$date)
class(movie_review$movie) # character

movie_review <- read.csv('movie_review.csv', stringsAsFactors = F)
class(movie_review)
class(movie_review$movie) # character

# 1 페이지 부터 100 페이지 까지 읽어들인 네이버 영화 리뷰 데이터를 이용해 영화별
# 평점 그래프를 출력한다.

library(dplyr)
movie_review_mean <- movie_review %>% 
    group_by(movie) %>% 
    summarise(count = n(), mean = round(mean(point), 2)) %>% 
    filter(count >= 5) %>% 
    arrange(desc(count)) %>% 
    head(10)

library(ggplot2)
ggplot(movie_review_mean, aes(reorder(movie, count), mean)) +
    geom_col() +
    coord_flip() +
    ylim(0, 10) +
    ggtitle('네이버 영화 평점') +
    xlab('영화제목') +
    ylab('평점') +
    geom_text(aes(label = count), hjust = -0.3) + 
    geom_text(aes(label = mean), hjust = 2, color = 'red', size = 8)
    
##################################################################################

# XML 패키지를 이용해 웹 스크레이핑 하기
install.packages('XML')
library(XML)
install.packages('httr')
library(httr)

# 한국일보 최신 뉴스 제목 스크레이핑

# httr 패키지의 GET() 함수를 사용해 스크레이핑 할 페이지의 전체 소스를 얻어온다.
hankook <- GET('https://www.hankookilbo.com/')
# XML 패키지의 htmlParse() 함수를 사용해 GET() 함수로 얻어온 소스 코드를 스크레이핑
# 할 수 있는 상태로 변환한다.
hankook <- htmlParse(hankook)

# xpathSApply() 함수로 특정 태그의 특정 class 속성을 가지는 텍스트를 얻어온다.
# //태그이름[@class='클래스이름']/태그이름...
# xmlValue은 태그 내부의 텍스트를 얻어온다.
content <- xpathSApply(hankook, 
           '//div[@class="news-list-container"]/ul/li/p/a', xmlValue)
content <- xpathSApply(hankook, 
           '//div[@class="news-list-container"]/ul/li/p[@class="title "]/a',
           xmlValue)
content <- gsub('[[:punct:][:cntrl:]]', '', content)

# xpath를 사용해서 크롤링을 할 경우 크롬에서 xpath를 복사해 오는 경우 아래와 같이
# 요소가 한 개 밖에 업는 부분에서 정상적으로 처리가 되지 않는다.
# //*[@id="content"]/div[1]/div[1]/section[2]/div[1]/div/div/ul/li[1]/p[1]/a
# div[1] 아래의 div 부터 정상적으로 작동되지 않는다.
# 해결 방법은 아래와 같이 정상적으로 작동되지 않는 부분을 제거하고 '//'를 입력한
# 후 읽어들일 데이터가 포함된 태그를 적어주면 된다.
xpath <- '//*[@id="content"]/div[1]/div[1]/section[2]/div[1]//a'
content <- xpathSApply(hankook, xpath, xmlValue)
content <- gsub('[[:punct:][:cntrl:]]', '', content)

##################################################################################

# 한국일보 최신 뉴스 제목
# xmlValue은 태그 내부의 텍스트를 얻어온다.
content <- xpathSApply(hankook, 
           '//div[@class="news-list-container"]/ul/li/p[@class="title "]/a',
           xmlValue)
content <- gsub('[[:punct:][:cntrl:]]', '', content)

# 한국일보 최신 뉴스의 url
# xmlGetAttr는 4번째 인수로 지정된 속성값을 얻어온다.
link <- xpathSApply(hankook, 
        '//div[@class="news-list-container"]/ul/li/p[@class="title "]/a',
        xmlGetAttr, 'href')

domain <- 'https://www.hankookilbo.com/'
for(i in 1:length(content)) {
    print(content[i])
    news_link <- paste(domain, link[i], sep='')
    print(news_link)
    news_content <- GET(news_link)
    news_content <- htmlParse(news_content)
    news_content <- xpathSApply(news_content, '//div[@class="article-story"]',
                    xmlValue)
    news_content <- gsub('[[:punct:][:cntrl:]]', '', news_content)
    print(news_content)
    line <- paste('================= ', i, ' =================', sep = '')
    print(line)
}















