a = 100
b <- 200
300 -> c
print(c)
d <- 3.4; d
e <- 999

a + b
a + b + c

# 산술 연산자
5 + 3 # 덧셈
5 - 3 # 뺄셈
5 * 3 # 곱셈
5 / 3 # 나눗셈
5 %% 3 # 나머지
5 %/% 3 # 몫

# c() 함수를 이용해서 변수에 여러개의 값을 저장할 수 있다.
var1 <- c(1, 3, 5, 7, 9) # 변수에 저장할 값을 ","로 구분해서 나열한다.
# 연속되는 값을 넣어야 할 경우 ":"을 사용해서 시작값:종료값 형식으로 입력하면
# 시작값 부터 종료값 까지 1씩 증가하는 연속되는 값이 저장된다.
var2 <- c(1:10)
var3 <- c("짜장면", "짬뽕", "탕수육")

# seq() 함수를 이용해서 변수에 여러개의 값을 저장할 수 있다.
# seq(시작값, 종료값, [by = 증가치]) # 증가치를 생략하면 1로 취급한다.
var4 <- seq(1, 10)
var5 <- seq(1, 10, by = 2)

# 여러개의 값을 기억하는 변수에 숫자를 연산하면 모든 값에 연산된다.
var1 + 2
# 여러개의 값을 기억한 변수끼리 연산하면 같은 위치의 값끼리 연산된다.
var2 <- c(1:5)
var1 + var2

# 여려개의 값을 기억한 변수에 저장된 값을 연산할 경우 변수에 저장된 데이터의
# 개수가 같아야 한다.
# 변수에 저장된 값의 개수가 다를 경우 값의 개수가 적은쪽의데이터가 처음부터
# 반복되며 연산된다.
var6 <- c(100, 200, 300, 400)
var1 + var6
var7 <- c(100, 200, 300, 400, 500, 600)
var1 + var7

# 변수에 문자를 넣을 때는 문자 앞뒤에 따옴표를 붙인다.
# 큰따옴표, 작은따옴표를 구분하지 않는다. => 짝만 맞춰주면 된다.
str1 <- "a"
str2 <- 'b'
str3 <- "test"
str4 <- 'sample'
str5 <- c("a", "b", "c")
str6 <- c('Hello', 'World', 'is', 'GOOD')
# 문자 데이터와 숫자 데이터를 연산할 수 없다.
str1 + 2 # 에러 발생

var1
max(var1) # 최대값
min(var1) # 최소값
sum(var1) # 합계
mean(var1) # 평균
length(var1) # 개수

# 문자열 연결 함수
# paste(연결할 문자열 목록..., collapse = '구분자')
# 문자열 또는 문자열이 저장된 변수의 내용을 구분자를 사용해 하나의 문자열로
# 만든다. 구분자가 생략되면 공백을 기본 구분자로 사용한다.
paste('a', 'b', 'c')
paste(str6, collapse = '^^;')

# 외부 패키지 사용하기
# 특정 함수를 사용하기 위해서는 그 함수가 포함된 패키지가 설치되야 한다.
# install.packages('패키지 이름') => 패키지 이름에 따옴표를 찍는다.
install.packages('ggplot2')
# 패키지를 설치만 하면 패키지에 포함된 함수를 사용할 수 없다.
# 패키지에 포함된 함수를 사용하려면 패키지를 설치한 후 반드시 library() 함수
# 를 실행해서 설치된 패키지를 메모리에 로드 시켜야 사용할 수 있다.
# library(패키지 이름) => 패키지 이름에 따옴표를 찍지 않는다.
# 패키지 설치는 한 번만 하면 되고 패키지를 사용하려면 R 또는 R Studio를
# 실행할 때 마다 library() 함수로 로드 시켜 사용해야 한다.
library(ggplot2)
x <- c('a', 'b', 'c', 'a', 'c', 'a')
qplot(x)

mpg
# head() 함수로 데이터의 앞부분의 데이터를 개수를 지정해서 볼 수 있다.
head(mpg) # 데이터의 개수를 생략하면 기본값으로 6개의 데이터를 보여준다.
head(mpg, 3)
# tail() 함수로 데이터의 뒷부분의 데이터를 개수를 지정해서 볼 수 있다.
tail(mpg) # 데이터의 개수를 생략하면 기본값으로 6개의 데이터를 보여준다.
tail(mpg, 3)

qplot(data = mpg, x = hwy)
qplot(data = mpg, x = cty)
qplot(data = mpg, x = drv, y = hwy)
qplot(data = mpg, x = drv, y = hwy, geom = 'line')
qplot(data = mpg, x = drv, y = hwy, geom = 'boxplot')
qplot(data = mpg, x = drv, y = hwy, geom = 'boxplot', color = drv)
qplot(data = mpg, x = hwy, y = cty, color = drv)
qplot(data = mpg, x = hwy, y = cty, color = class)
qplot(data = mpg, x = hwy, y = cty, color = manufacturer)

# 변수의 종류
# R의 변수는 크게 연속(양적) 변수와 범주(명목) 변수로 구분할 수 있고 변수에
# 저장된 값이 똑같이 숫자로 되어 있더라도 변수의 종류가 무엇인가에 따라
# 사용할 수 있는 분석 방법이 달라진다.

# 연속(양적) 변수 - numeric
# 연속 변수는 키, 몸무게, 소득 같은 연속적이고 크기를 의미하는 값들로 구성된
# 변수를 의미하고 값이 크기를 가지기 때문에 덧셈, 뺄섬 등의 산술연산이 
# 가능하다.
var8 <- c(1, 2, 3, 1, 2)
class(var8) # var8은 양적 변수이므로 numeric이 출력된다.
var8 + 2 # 연속 변수는 산술 연산이 가능하다.

# 범주(명목) 변수 - factor
# 범주 변수는 값이 크기를 가지지 않고 특정한 대상을 분류하는 의미를 가지는
# 변수로 성별과 같이 남자는 1, 여자는 2로 각 범주를 분류한다.
# 숫자가 크기를 의미하지 않기 때문에 합계나 평균을 계산하는 산술연산이
# 불가능하다.

# factor() 함수로 범주 변수를 만든다.
var9 <- factor(c(1, 2, 3, 1, 2))
class(var9) # var9은 범주 변수이므로 factor가 출력된다.
var9 + 2 # 범주 변수는 산술 연산이 불가능하다.
# levels()를 이용해 범주 변수의 범주 종류만 출력할 수 있다.
levels(var9)

# 범주 변수는 크기를 의미하는 것이 아니기 때문에 문자로 구성된 변수도 가능
# 하다.
str7 <- c('짜장', '짬뽕', '만두', '짜장', '짬뽕', '기스면')
class(str7) # 문자 변수이므로 character가 출력된다.
str8 <- factor(str7)
class(str8) # 범주 변수이므로 factor가 출력된다.
levels(str8) # 범주 변수의 level은 오름차순(가나다순)으로 정렬되 출력된다.

mean(var8)
mean(var9)
# as.numeric() 함수로 factor를 numeric 타입으로 변환시킬 수 있다.
var10 <- as.numeric(var9)
mean(var10)
class(var10)
levels(var9)
# var10은 연속 변수이므로 Levels가 없다. => NULL이 출력된다.
levels(var10)

# 데이터 형 변환 함수
# as.factor() : factor로 변경한다.
# as.character() : character로 변경한다.
# as.Date() : Date로 변경한다.
# as.data.frame() : data frame으로 변경한다.