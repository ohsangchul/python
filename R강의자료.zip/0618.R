# 데이터 구조
# vector : 1차원, 한 가지 데이터 타입으로 구성된다.
# matrix : 2차원, 한 가지 데이터 타입으로 구성된다.
# data frame : 2차원, 다양한 데이터 타입으로 구성된다.
# array : 다차원, matrix로 구성된다. matrix가 여러개 있는 구조이다.
# list : 다차원, data frame으로 구성된다. data frame가 여러개 있는 구조이다.

# matrix : matrix() 함수를 이용해 만든다.
var10 <- c(1:12) # vector
# 행과 열을 지정하지 않아서 12행 1열인 matrix가 만들어진다.
mat1 <- matrix(c(1:12))
# ncol 옵션으로 열의 개수를 지정하고 nrow 옵션으로 행의 개수를 지정한다.
# matrix에 데이터가 채워지는 방향을 지정하는 byrow 옵션을 생략하면 데이터는
# 열 방향을 우선해서 채워진다.
mat2 <- matrix(c(1:12), ncol = 4)
mat3 <- matrix(c(1:12), nrow = 4)
# byrow = TRUE 옵션을 사용하면 행 방향으로 데이터가 채워진다.
mat4 <- matrix(c(1:12), nrow = 4, byrow = TRUE)

# matrix 인덱싱 또는 슬라이싱 => 데이터의 일부를 얻어온다.
mat4[7] # matrix에서 지정된 위치의 데이터 한 개를 얻어온다. => 열 우선 방식
mat4[1,] # matrix에서 지정된 행 전체를 얻어온다.
mat4[,1] # matrix에서 지정된 열 전체를 얻어온다.
mat4[3,2] # matrix에서 지정된 위치의 데이터 한 개를 얻어온다.
mat4[1:2,] # matrix에서 지정된 범위의 행 데이터를 얻어온다. => 붙어 있을 때
# matrix에서 지정된 행 데이터를 얻어온다. => 떨어져 있을 때
mat4[c(1, 3),]
mat4[,1:2]
mat4[,c(1, 3)]
# matrix에서 데이터의 위치를 지정할 때 앞에 '-'를 붙여주면 '-'가 붙어있는
# 데이터를 제외하고 나머지 데이터만 얻어온다.
mat4[-1,] # matrix에서 1행을 제외한 데이터를 얻어온다.
mat4[,-2] # matrix에서 2열을 제외한 데이터를 얻어온다.
mat4[-c(1:2),] # matrix에서 1행 부터 2행을 제외한 데이터를 얻어온다.
mat4[-c(1, 3),] # matrix에서 1열과 3열을 제외한 데이터를 얻어온다.

# array : array() 함수를 이용해 만든다.
# dim 속성을 이용해서 행, 열, 면의 순서로 array 구조를 지정한다.
# dim = c(2, 3, 4) => 2행 3열짜리 matrix가 4개 있다는 의미이다.
arr1 <- array(c(1:24), dim = c(2, 3, 4))

# array 인덱싱 또는 슬라이싱 => 데이터의 일부를 얻어온다.
arr1[,,1] # array에서 1번째 면(1번째 matrix)의 데이터를 얻어온다.
arr1[1,,1] # array에서 1번째 면의 1번째 행 데이터를 얻어온다.
arr1[,2,2] # array에서 2번째 면의 2번째 열 데이터를 얻어온다.
arr1[1,,] # array에서 모든 면의 1번째 행 데이터를 얻어온다.
arr1[1,2,] # array에서 모든 면의 1행 2열 데이터를 얻어온다.

# data frame : data.frame() 함수를 이용해 만든다.
data1 <- c(1, 2, 3, 4, 1, 2)
class(data1)
data2 <- c('a', 'b', 'c', 'd', 'a', 'b')
class(data2)
# vector를 만들 때 문자와 숫자가 섞여있으면 모두 문자로 취급된다.
data3 <- c(1, 'a', 'b', 'a', 1, 'c')
class(data3)

# data.frame(데이터 프레임으로 만들 벡터들....)
# 데이터 프레임을 만들 때 사용한 벡터의 이름이 데이터 프레임의 열 이름으로
# 사용된다.
df <- data.frame(data1, data2, data3)
class(df)

# 데이터 프레임의 특정 열의 값을 얻어오는 방법은 2가지가 있다.
# 1. 데이터프레임이름[열번호] => 데이터 프레임 형태로 값을 얻어온다.
# matrix나 array에서 사용했던 슬라이싱 방법을 똑같이 사용할 수 있다.
df_field1 <- df[1]
class(df_field1)
df_field2 <- df[1:2]
df_field3 <- df[c(1, 3)]
# 2. 데이터프레임$열이름 => 숫자는 벡터 형태로 값을 얻어오고 문자는 펙터
# 형태로 값을 얻어온다.
df_field4 <- df$data1
class(df_field4) # numeric => 벡터
df_field5 <- df$data2
class(df_field5) # factor
df_field6 <- df$data3
class(df_field6) # factor

# 데이터 프레임에 저장되서 factor로 변환된 데이터를 다시 문자 데이터로 사용
# 하려면 as.character() 함수를 사용해서 문자로 변환시킨 후 사용하면 된다.
data4 <- as.character(df_field5)
class(data4) # character => 벡터

# list : list() 함수를 이용해 만든다.
v <- 1 # vector
m <- matrix(c(1:12), ncol = 6) # matrix
a <- array(c(1:20), dim = c(2, 5, 2)) # array
d <- data.frame(x1 = c(1, 2, 3), x2 = c('a', 'b', 'c')) # data.frame
data5 <- list(list1 = v, list2 = m, list3 = a, list4 = d)
class(data5)

###########################################################################

# 외부 데이터 읽어오기
# read.csv() 함수는 csv 파일(데이터가 ','로 구분된 파일)을 데이터 프레임
# 형태로 읽어온다.
csv_exam <- read.csv('csv_exam.csv')

csv_exam # 데이터 프레임 전체를 출력한다.
csv_exam[] # []만 적으면 csv_exam를 실행한 결과와 같은 결과가 출력된다.
csv_exam[1,] # 데이터 프레임의 1행만 얻어온다.
csv_exam[1:2,] # 데이터 프레임의 1행 부터 2행까지 얻어온다.
csv_exam[c(1, 3),] # 데이터 프레임의 1행과 3행만 얻어온다.
csv_exam[3] # 데이터 프레임의 3번째 열만 얻어온다. => 데이터 프레임
class(csv_exam[3])
csv_exam[,4] # 데이터 프레임의 4번째 열만 얻어온다. => 벡터 또는 펙터
class(csv_exam[,4])
# 데이터 프레임의 english 열만 얻어온다. => 벡터 또는 펙터
csv_exam$english
csv_exam[,'english']
# c() 함수를 사용하면 데이터 프레임의 여러 열 이름을 이용해 데이터를 얻어올
# 수 있다. => 2개 이상의 열을 얻어오면 데이터 프레임 형태로 얻어온다.
csv_exam[,c('english', 'science')]
csv_exam[20, 5] # 데이터 프레임의 20행 5열의 값만 얻어온다.

# 조건에 만족하는 데이터 프레임의 데이터 얻어오기
# 데이터 프레임의 class 열에 저장된 값이 1인 행만 얻어온다.
csv_exam[csv_exam$class == 1,] # ★ 끝에 반드시 ','를 찍어야 한다. ★
# 데이터 프레임의 math 열에 저장된 데이터가 80 이상인 행만 얻어온다.
csv_exam[csv_exam$math >= 80,]
# 데이터 프레임의 class열에 저장된 데이터가 1이고 english 열에 저장된 데이터
# 가 90 이상인 행만 출력한다.
csv_exam[csv_exam$class == 1 & csv_exam$english >= 90,] # & => and 연산자
# 데이터 프레임의 math 열에 저장된 데이터가 30 이하이거나 science 열에 저장
# 된 데이터가 30 이하인 행만 출력한다.
csv_exam[csv_exam$math <= 30 | csv_exam$science <= 30,] # | => or 연산자

# 읽어들일 csv 파일의 첫 번째 줄이 열 이름이 아닐 경우 header = FALSE 옵션을
# 지정해서 읽어들이면 된다. => 읽어들인 후 열 이름을 별도로 지정해야 한다.
# TRUE와 FALSE는 각각 T와 F로 줄여서 사용할 수 있다.
# 문자가 들어있는 csv 파일을 읽어들일 때 stringsAsFactors = F 옵션을 지정해
# 서 읽어들이는 것이 좋다. stringsAsFactors = F 옵션을 지정하지 않으면 데이
# 터를 문자가ㅏ아닌 factor 타입으로 읽어들여 처리시 오류가 발생될 수 있다.
csv_exam_noheader <- read.csv('csv_exam_noheader.csv', header = F, 
                              stringsAsFactors = F)
# 원본 데이터를 읽었으면 망칠것에 대비해서 사본을 만들어서 작업한다.
csv_exam_copy <- csv_exam_noheader

# 데이터 프레임의 열 이름을 변경하려면 rename() 함수를 사용한다.
# rename() 함수를 사용하려면 dplyr 패키지를 설치하고 로드한 후 사용한다.
install.packages('dplyr')
library(dplyr)
# rename(데이터 프레임 이름, 새변수명 = 기존변수명, ...)
csv_exam_copy <- rename(csv_exam_copy, id = V1)












