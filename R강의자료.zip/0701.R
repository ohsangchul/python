# Selenium 서버 기동 과정
# 1. 임의의 폴더에 selenium-server-standalone-master.zip와 chromedriver.exe를
# 복사한 후 selenium-server-standalone-master.zip의 압축을 푼다.
# 2. selenium-server-standalone-master.zip의 압축을 푼 다음에 bin 폴더로
# chromedriver.exe를 복사해 넣는다.
# 3. cmd 창을 띄워서 chromedriver.exe을 복사해 넣은 bin 폴더로 이동한다.
# 윈도우 탐색기에서 bin 폴더로 이동하고 아무것도 선택하지 않은 상태에서 shift 키와
# 마우스 오른쪽 버튼을 동시에 누르고 여기서 명령 창 열기 메뉴를 클릭하면 편하게
# 띄울수 있다. => 내가 windows 10을 안써봐서 10은 모르겠음.....
# 윈도우 10은 아래와 같이 한다.
# cmd 실행하고 압축을 풀은 폴더가 c드라이브면 cd\를 입력하고 엔터키를 누르고 d드라이
# 브면 d: 엔터를 누른다.
# 탐색기에서 chromedriver.exe를 복사해 넣은 bin 폴더로 이동하고 경로를 복사한다.
# cmd에서 cd 입력후 복사한 경로를 붙여넣고 엔터키를 누른다.
# 4. cmd창의 프롬프트에서 java -jar selenium-server-standalone.jar -port 4445를 
# 입력해 Selenium 서버를 기동시킨다. => 서버 기동 후 cmd 창을 닫으면 서버가 종료
# 되기 때문에 작업이 완전히 완도되기 전 까지는 cmd 창을 닫으면 안된다.
# Selenium Server is up and running 메시지가 보이면 Selenium 서버가 실행된 상태다.

# R에서 Selenium을 사용하기 위한 패키지를 설치하고 로드한다.
install.packages('RSelenium')
library(RSelenium)

# 만약에 install.packages('RSelenium')가 실행되지 않으면 아래와 같이 설치한다.
# devtools 패키지의 install_version() 함수를 사용해 직접 RSelenium을 설치한다.
# install.packages("devtools")
# library(devtools)
# install_version("binman", version = "0.1.0", 
#                 repos = "https://cran.uni-muenster.de/")
# install_version("wdman", version = "0.2.2", 
#                 repos = "https://cran.uni-muenster.de/")
# install_version("RSelenium", version = "1.7.1", 
#                 repos = "https://cran.uni-muenster.de/")
# library(RSelenium)

# Selenium 서버를 실행 후 크롬을 실행하고 읽어올 댓글 페이지로 이동한다.
remDr <- remoteDriver(remoteServerAddr = 'localhost', port = 4445,
                      browserName = 'chrome')
remDr$open()
remDr$navigate('https://comic.naver.com/comment/comment.nhn?titleId=723714&no=64')

# 전체 댓글을 얻어오기 위해서 전체 댓글 링크를 얻어온다.
reviewBtn <- remDr$findElements(using = 'css selector', '#cbox_module > div > div.u_cbox_sort > div.u_cbox_sort_option > div > ul > li:nth-child(2) > a > span.u_cbox_sort_label')
# 얻어온 전체 댓글 링크를 클릭한다.
sapply(reviewBtn, function(x) { x$clickElement() })
# clickElememt() 함수를 사용해 얻어온 링크를 클릭하면 브라우저에서 페이지가 변경
# 되는데 페이지가 변경되기까지 Sys.sleep() 함수로 프로그램을 잠깐 멈춘다.
# 대형 포털 사이트는 너무 빠르게 요청이 들어오면 자기네 사이트가 공격당하는 것으로
# 판단할 수 있기 때문에 일정 시간만큼 프로그램을 멈춰주는 것이 좋다.
Sys.sleep(0.5) # 시간은 초단위로 지정한다.

review <- NULL # 전체 댓글을 기억할 변수를 만들고 초기화시킨다.
# 전체 댓글의 1페이지만 읽어온다.
doms <- remDr$findElements(using = 'css selector', '#cbox_module span.u_cbox_contents')
review <- sapply(doms, function(x) { x$getElementText()})
review <- unlist(review)

# 전체 댓글 페이지가 몇 페이지인지 모르기때문에 repeat 명령을 이용해 무한 루프를
# 돌리고 끝까지 다 읽으면 무한 루프를 탈출시킨다.
repeat {
    # 1페이지의 댓글은 읽어왔으므로 9번 반복하면서 나머지 댓글을 읽어온다.
    for(i in 4:12) {
        # 다음 페이지 댓글을 읽어오기 위해 다음 페이지로 넘겨주는 링크를 얻어온다.
        # nth-child(n) => n번째 자식 노드(태그)를 의미한다.
        nextLink <- paste('#cbox_module > div > div.u_cbox_paginate > div > a:nth-child(', i, ') > span', sep = '')
        # print(nextLink)
        # 다음 댓글 페이지로 넘겨준다.
        nextPage <- remDr$findElements(using = 'css selector', nextLink)
        # 다음 댓글 페이지가 없으면 for를 탈출한다.
        if(length(nextPage) == 0) {
            break
        }
        # 위 if의 조건이 만족하지 않았다면 다음에 읽을 댓글 페이지의 링크가 있는
        # 것이므로 다음 댓글 링크를 클릭한다.
        sapply(nextPage, function(x) { x$clickElement() })
        Sys.sleep(0.5) # sleep() 함수로 페이지가 로드되는 시간 만큼 대기시킨다.
        # 다음 댓글 페이지의 내용을 읽어들인다.
        doms <- remDr$findElements(using = 'css selector', '#cbox_module span.u_cbox_contents')
        result <- sapply(doms, function(x) { x$getElementText()})
        # 기존에 읽어두었던 댓글 목록에 지금 읽은 페이지의 댓글을 붙여준다.
        review <- c(review, unlist(result))
    }
    # review <- unlist(review)
    # 다음 10페이지의 댓글을 읽기위해 다음 10페이지 링크를 얻어온다.
    nextLink <- '#cbox_module > div > div.u_cbox_paginate > div > a:nth-child(13) > span.u_cbox_cnt_page'
    nextPage <- remDr$findElements(using = 'css selector', nextLink)
    
    # 더 이상 읽을 다음 10페이지가 없다면 repeat(무한루프)를 탈출시킨다.
    if(length(nextPage) == 0) {
        break
    }
    
    # 다음 10페이지로 넘겨준다.
    sapply(nextPage, function(x) { x$clickElement() })
    Sys.sleep(0.5)
    
    # 새로운 10페이지로 넘어왔으므로 첫 페이지를 읽는다.
    doms <- remDr$findElements(using = 'css selector', '#cbox_module span.u_cbox_contents')
    result <- sapply(doms, function(x) { x$getElementText()})
    # 기존에 읽어두었던 댓글 목록에 지금 읽은 페이지의 댓글을 붙여준다.
    review <- c(review, unlist(result))
}
review <- unlist(review)

##################################################################################

install.packages('dplyr')
install.packages('rJava')
install.packages('memoise')
install.packages('KoNLP')
library(dplyr)
library(KoNLP)
useNIADic()

# 특수 문자만 제거한 후 명사를 추출한 후 벡터로 변환시킨다.
txt <- gsub('[[:punct:][:cntrl:]]', '', review)
nouns <- extractNoun(txt)
nouns <- unlist(nouns)

# 단어별 빈도표를 만들고 데이터 프레임으로 변환한다.
wordCount <- table(nouns)
df_wordCount <- as.data.frame(wordCount)
df_wordCount <- rename(df_wordCount, word = nouns, freq = Freq)

# 불필요한 단어를 제거하고 워드 클라우드로 구현할 단의 출현 빈도수를 내림차순으로
# 정렬한다.
df_wordCount$word <- gsub('^[0-9]*$', '', df_wordCount$word)
df_wordCount$word <- gsub('\\W', '', df_wordCount$word)
df_wordCount$word <- gsub('ㅋ', '', df_wordCount$word)
df_wordCount$word <- gsub('ㅎ', '', df_wordCount$word)
df_wordCount$word <- gsub('ㄱ', '', df_wordCount$word)
df_wordCount$word <- gsub('ㄲ', '', df_wordCount$word)
df_wordCount$word <- gsub('ㄴ', '', df_wordCount$word)
df_wordCount$word <- gsub('ㄷ', '', df_wordCount$word)
df_wordCount$word <- gsub('ㅅ', '', df_wordCount$word)
df_wordCount$word <- gsub('ㅇ', '', df_wordCount$word)
df_wordCount$word <- gsub('ㅜ', '', df_wordCount$word)
df_wordCount$word <- gsub('ㅠ', '', df_wordCount$word)

# 출현 빈도수 상위 단어 200개의 워드 클라우드를 만든다.
install.packages('wordcloud')
library(wordcloud)
library(RColorBrewer)

df_wordCount <- df_wordCount %>% 
    filter(nchar(word) >= 2 & nchar(word) <= 5)
top200 <- df_wordCount %>% 
    arrange(desc(freq)) %>% 
    head(200)

set.seed(1)
pal <- brewer.pal(8, 'Dark2')
wordcloud(words = df_wordCount$word,
          freq = df_wordCount$freq,
          min.freq = 2,
          max.words = 200,
          random.order = F,
          rot.per = 0.1,
          scale = c(7, 0.2),
          colors = pal)

# 출현 빈도수 상위 단어 200개의 그래프를 만든다.
install.packages('ggplot2')
library(ggplot2)

top20 <- df_wordCount %>% 
    arrange(desc(freq)) %>% 
    head(20)

order_asc <- arrange(top20, freq)$word
order_desc <- arrange(top20, desc(freq))$word
ggplot(data = top20, aes(x = word, y = freq)) +
    geom_col() + 
    coord_flip() +
    ylim(0, 100) + 
    geom_text(aes(label = freq), hjust = -0.5) +
    scale_x_discrete(limits = order_asc)





