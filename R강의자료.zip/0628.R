# 웹 브라우저 원격 조작에 사용하는 Selenium 사용하기
# javascript 컨텐츠를 사용하는 웹 사이트의 경우 url만 안다고 해서 스크레이핑을 할
# 수 없다. => 동적 웹 사이트
# Selenium을 사용하여 url을 자동으로 랜더링해 놓고 랜더링된 결과에서 컨텐츠를 읽어
# 와야 한다. 그 뿐만 아니라 컨텐츠 내에서 클릭 이벤트를 발생 시킬 수 있으며 데이터
# 를 입력하는 것도 가능하다.

# Selenium 서버 기동 과정
# 1. 임의의 폴더에 selenium-server-standalone-master.zip와 chromedriver.exe를
# 복사한 후 selenium-server-standalone-master.zip의 압축을 푼다.
# 2. selenium-server-standalone-master.zip의 압축을 푼 다음에 bin 폴더로
# chromedriver.exe를 복사해 넣는다.
# 3. cmd 창을 띄워서 chromedriver.exe을 복사해 넣은 bin 폴더로 이동한다.
# 윈도우 탐색기에서 bin 폴더로 이동하고 아무것도 선택하지 않은 상태에서 shift 키와
# 마우스 오른쪽 버튼을 동시에 누르고 여기서 명령 창 열기 메뉴를 클릭하면 편하게
# 띄울수 있다. => 내가 windows 10을 안써봐서 10은 모르겠음.....
# 4. cmd창의 프롬프트에서 java -jar selenium-server-standalone.jar -port 4445를 
# 입력해 Selenium 서버를 기동시킨다. => 서버 기동 후 cmd 창을 닫으면 서버가 종료
# 되기 때문에 작업이 완전히 완도되기 전 까지는 cmd 창을 닫으면 안된다.
# Selenium Server is up and running 메시지가 보이면 Selenium 서버가 실행된 상태다.

# R에서 Selenium을 사용하기 위한 패키지를 설치하고 로드한다.
install.packages('RSelenium')
library(RSelenium)
# 만약에 install.packages('RSelenium')가 실행되지 않으면 아래와 같이 설치한다.
# devtools 패키지의 install_version() 함수를 사용해 직접 RSelenium을 설치한다.
# install.packages("devtools")
# library(devtools)
# install_version("binman", version = "0.1.0", 
#                 repos = "https://cran.uni-muenster.de/")
# install_version("wdman", version = "0.2.2", 
#                 repos = "https://cran.uni-muenster.de/")
# install_version("RSelenium", version = "1.7.1", 
#                 repos = "https://cran.uni-muenster.de/")
# library(RSelenium)

# R에서 Selenium을 실행한 후 크롬을 실행한다.
# R에서 Selenium 서버에 연결하고 사용할 웹 브라우저를 지정한다.
remDr <- remoteDriver(remoteServerAddr = 'localhost', port = 4445,
                      browserName = 'chrome')
# 지정한 웹 브라우저를 실행한다.
remDr$open()
# 실행된 웹 브라우저에 표시할 웹 페이지 주소를 지정한다.
remDr$navigate('https://www.google.com')
# 웹 페이지에 데이터를 입력하고 키 입력하기
# webElem <- remDr$findElement(using = 'css', '[name = "q"]')
# webElem$sendKeysToElement(list("JAVA", key = 'enter'))

##################################################################################

# 호텔스컴바인에서 이태원 호텔 리뷰 동적 스크레이핑
# Selenium을 실행한 후 크롬을 실행하고 스크레이핑 할 웹 사이트를 연다.
remDr <- remoteDriver(remoteServerAddr = 'localhost', port = 4445,
                      browserName = 'chrome')
remDr$open()
remDr$navigate('https://www.hotelscombined.co.kr/Hotel/Search?checkin=2019-07-07&checkout=2019-07-08&Rooms=1&adults_1=2&languageCode=KO&currencyCode=KRW&fileName=I_T_W_Hotel_Itaewon')

# 리뷰
# findElements() 함수에 using 속성으로 css 선택자를 사용해서 웹 스크레이핑을
# 하겠다고 지정하고 2번째 인수로 읽어올 데이터가 포함된 css 선택자를 지정한다.
# div.hc-customerreviews__comments => div 태그의 hc-customerreviews__comments 
# 클래스를 의미한다.
# 다른 곳에도 div 태그에 div.hc-customerreviews__comments 클래스가 존재한다면 다른
# 곳의 데이터도 읽어오는 문제가 발생되기 때문에 읽어올 css 선택자가 포함된 상위
# 태그의 id를 선택자 앞에 붙여주면 제대로된 스크레이핑을 할 수 있다.
doms <- remDr$findElements(using = 'css selector', 
                           '#hc_r_3b div.hc-customerreviews__comments')
# sapply() 함수로 스크레이핑 한 데이터에서 getElementText() 함수를 실행해서 문자열
# 만 얻어온다.
review <- sapply(doms, function(x) { x$getElementText() })
# getElementText() 함수로 읽어들은 문자열의 데이터 타입이 list 타입이므로 unlist()
# 함수를 실행해서 벡터로 변환한다.
review <- unlist(review)

# 평점
doms <- remDr$findElements(using = 'css selector', 
                           '#hc_r_3b div.hc-customerreviews__headerrate')
point <- sapply(doms, function(x) { x$getElementText() })
point <- unlist(point)

# 제목
doms <- remDr$findElements(using = 'css selector', 
                           '#hc_r_3b div.hc-customerreviews__headertext')
title <- sapply(doms, function(x) { x$getElementText() })
title <- unlist(title)

Hotel_Itaewon <- cbind(title, review)
Hotel_Itaewon <- cbind(Hotel_Itaewon, point)
Hotel_Itaewon <- as.data.frame(Hotel_Itaewon)
class(Hotel_Itaewon)

##################################################################################

# 호텔스컴바인에서 나트랑 쉐라톤 리뷰 스크레이핑
remDr <- remoteDriver(remoteServerAddr = 'localhost', port = 4445,
                      browserName = 'chrome')
remDr$open()
remDr$navigate('https://www.hotelscombined.co.kr/Hotel/Search?checkin=2019-07-07&checkout=2019-07-08&Rooms=1&adults_1=2&languageCode=KO&currencyCode=KRW&fileName=Sheraton_Nha_Trang')
doms <- remDr$findElements(using = 'css selector', 
                           '#hc_r_3b div.hc-customerreviews__comments')
review <- sapply(doms, function(x) { x$getElementText() })
review <- unlist(review)

doms <- remDr$findElements(using = 'css selector', 
                           '#hc_r_3b div.hc-customerreviews__headerrate')
point <- sapply(doms, function(x) { x$getElementText() })
point <- unlist(point)

doms <- remDr$findElements(using = 'css selector', 
                           '#hc_r_3b div.hc-customerreviews__headertext')
title <- sapply(doms, function(x) { x$getElementText() })
title <- unlist(title)

Sheraton_Nha_Trang <- cbind(title, review)
Sheraton_Nha_Trang <- cbind(Sheraton_Nha_Trang, point)
Sheraton_Nha_Trang <- as.data.frame(Sheraton_Nha_Trang)

# 아고다에서 나트랑 빈펄 베이 리조트 리뷰 스크레이핑
remDr <- remoteDriver(remoteServerAddr = 'localhost', port = 4445,
                      browserName = 'chrome')
remDr$open()
remDr$navigate('https://www.agoda.com/ko-kr/vinpearl-resort-spa-nha-trang-bay/hotel/nha-trang-vn.html?checkin=2019-07-07&los=2&adults=2&rooms=1&cid=1430285&tag=911ebde7-5036-685e-58fa-9c8b7e2e4bdb,911ebde7-5036-685e-58fa-9c8b7e2e4bdb&searchrequestid=778969d3-76c9-4920-ba09-273b320ee3b2&travellerType=-1&tspTypes=8&tabbed=true')
doms <- remDr$findElements(using = 'css selector', 
                           '#reviewSectionComments p.Review-comment-bodyText')
review <- sapply(doms, function(x) { x$getElementText() })
review <- unlist(review)

##################################################################################

# 네이버 웹툰 베댓 스크레이핑
# 네이버 웹툰의 갯글은 링크 방식으로 처리되지 않고 ajax로 처리된다.
# ajax로 처리되는 사이트는 type이 xhr이고 하이퍼 링크를 클릭했을 때 url이 변경되지
# 않는 특징이 있다.

# https://comic.naver.com/webtoon/detail.nhn => 웹툰을 보여주는 페이지
# https://comic.naver.com/comment/comment.nhn => 댓글을 보여주는 페이지

# 댓글은 https://comic.naver.com/comment/comment.nhn 페이지의 내용을 ajax로 읽어서
# id 속성이 commentIframe인 iframe에 넣어준다.
# iframe src 속성에 /comment/comment.nhn?titleId=723714&no=63와 같이 댓글을 표시
# 하는 페이지의 주소가 지정된다.

# Selenium 서버를 실행 후 크롬을 실행하고 읽어올 댓글 페이지로 이동한다.
remDr <- remoteDriver(remoteServerAddr = 'localhost', port = 4445,
                      browserName = 'chrome')
remDr$open()
remDr$navigate('https://comic.naver.com/comment/comment.nhn?titleId=723714&no=63')

# 베댓 전체를 읽는다.
doms <- remDr$findElements(using = 'css selector', 
                           '#cbox_module span.u_cbox_contents')
review <- sapply(doms, function(x) { x$getElementText() })
review <- unlist(review)

# 특정 베댓만 읽는다.
doms <- remDr$findElements(using = 'css selector', 
                           '#cbox_module > div > div.u_cbox_content_wrap > ul > li.u_cbox_comment.cbox_module__comment_372773206._user_id_no_9GUJb > div.u_cbox_comment_box > div > div.u_cbox_text_wrap > span.u_cbox_contents')
review <- sapply(doms, function(x) { x$getElementText() })
review <- unlist(review)







