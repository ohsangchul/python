# 이상한 데이터 : 극단치, 이상점, outlier
# 이상한 데이터는 존재할 수 없는 값이 데이터에 포함되어 있음을 의미한다.
# 발견된 이상한 데이터는 결측치로 변환한 후 제거하거나 다른 값으로 대체한다.

# gender는 1과 2만 데이터로 가질 수 있고 score는` 1, 2, 3, 4, 5만 데이터로 가질
# 수 있다.
outlier <- data.frame(gender = c(1, 2, 1, 3, 1, 2), 
                      score = c(5, 4, 3, 2, 4, 6))

# table() 함수를 사용해서 이상치가 존재하는가 확인한다.
table(outlier$gender)
table(outlier$score)

# 이상치가 존재할 경우 ifelse() 함수로 이상치를 결측치로 변환한다.
outlier$gender <- ifelse(outlier$gender > 2, NA, outlier$gender)
outlier$score <- ifelse(outlier$score > 5, NA, outlier$score)

library(ggplot2)
# 패키지에 내장된 데이터를 사용하다 손상시킨 경우 패키지에서 다시 꺼내오면
# 된다.
mpg <- ggplot2::mpg # ggplot2 패키지의 mpg 데이터를 다시 꺼내온다.

# boxplot() 함수를 참고해서 ggplot2 패키지의 mpg의 hwy 변수의 데이터중에서
# 극단치를 결측치로 변환한다.
boxplot(mpg$hwy)
boxplot(mpg$hwy)$stats
#      [,1]
# [1,]   12 # 최소값
# [2,]   18 # 1사분위수
# [3,]   24 # 평균
# [4,]   27 # 3사분위수
# [5,]   37 # 최대값
# boxplot(mpg$hwy)$stats 실행 결과에서 12 미만이거나 37을 초과하는 경우는
# 이상한 데이터일 확률이 매우 높다.
mpg$hwy <- ifelse(mpg$hwy < 12 | mpg$hwy > 37, NA, mpg$hwy)

#############################################################################

# ggplot2 패키지를 이용해 그래프 만들기
# ggplot2의 그래프를 작성하는 문법은 레이어 구조로 되어있다.
# 배경을 먼저 만들고 그 위에 그래프를 그린 다음에 그 위에 축, 색, 표식 등을
# 추가해서 그래프를 완성한다.

# 산점도 : 연속된 값으로 되어있는 두 변수간의 관계를 표시한다.

# 그래프가 출력될 배경을 만든다.
# ggplot(data = 데이터 프레임, aes = (x = x(가로)축, y = y(세로)축))
ggplot(data = mpg, aes(x = displ, y = hwy))
# 배경에 geom_그래프이름() 함수를 배경에 '+'로 연결해서 그래프를 그린다.
ggplot(data = mpg, aes(x = displ, y = hwy)) + geom_point()
ggplot(data = mpg, aes(x = displ, y = cty)) + geom_point()
ggplot(data = mpg, aes(x = hwy, y = cty)) + geom_point()
# 완성된 그래프에 축, 색, 표식을 추가한다.
ggplot(data = mpg, aes(x = displ, y = hwy)) + 
    geom_point() +
    xlim(3, 6) + # x축의 표시 범위를 지정한다.
    ylim(15, 30) # y축의 표시 범위를 지정한다.

library(dplyr)

# 막대 그래프 : 데이터의 크기를 막대로 표시한다.
# 구동 방식별 고속도로 연비 평균
ggplot(data = mpg, aes(x = drv, y = hwy)) + geom_col() # 합계 그래프
mpg_drv <- mpg %>% 
    group_by(drv) %>% 
    summarise(mean_hwy = mean(hwy))
ggplot(data = mpg_drv, aes(x = drv, y = mean_hwy)) + geom_col()

# 차종별 도시 연비 평균
ggplot(data = mpg, aes(x = class, y = cty)) + geom_col() # 합계 그래프
mpg_class <- mpg %>% 
    group_by(class) %>% 
    summarise(mean_cty = mean(cty))
ggplot(data = mpg_class, aes(x = class, y = mean_cty)) + geom_col()

# reorder() 함수를 이용해 x축 항목의 정렬 순서를 변경할 수 있다.
# reorder(정렬할 데이터가 저장된 변수명, 정렬 기준으로 사용할 변수명)
# reorder(class, mean_cty) : class를 mean_cty의 오름차순으로 정렬한다.
ggplot(data = mpg_class, aes(x = reorder(class, mean_cty), y = mean_cty)) +
    geom_col()
# 정렬 기준으로 사용할 변수명만 써주면 오름차순으로 정렬되고 정렬되고 정렬
# 기준으로 사용할 변수명 앞에 '-'를 붙여주면 내림차순으로 정렬된다.
ggplot(data = mpg_class, aes(x = reorder(class, -mean_cty), y = mean_cty)) +
    geom_col()

# 어떤 회사에서 생산한 suv 자동차가 연비가 높은지 알아보기 위해 suv 차종을
# 대상으로 도시 연비 평균이 가장 높은 다섯곳을 나타내는 막대 그래프를
# 연비가 높은 순서로 정렬해서 만든다.
mpg_suv <- mpg %>% 
    filter(class == 'suv') %>% 
    group_by(manufacturer) %>% 
    summarise(mean_cty = mean(cty)) %>% 
    arrange(desc(mean_cty)) %>% 
    head(5)
# 그래프 작성에 사용할 데이터를 정렬시켜 추출했다 하더라도 reorder() 함수를
# 사용하지 않고 그래프를 작성하면 x축의 오름차순으로 정렬되서 출력된다.
ggplot(data = mpg_suv, aes(x = manufacturer, 
                           y = mean_cty)) + geom_col()
ggplot(data = mpg_suv, aes(x = reorder(manufacturer, mean_cty), 
                           y = mean_cty)) + geom_col()
ggplot(data = mpg_suv, aes(x = reorder(manufacturer, -mean_cty), 
                           y = mean_cty)) + geom_col()

# 빈도(개수) 막대 그래프 : x축만 지정하고 y축은 지정하지 않는다.
mpg_drv <- mpg %>% 
    group_by(drv) %>% 
    summarise(n = n())
ggplot(data = mpg, aes(x = drv)) + geom_bar()
mpg_class <- mpg %>% 
    group_by(class) %>% 
    summarise(n = n())
ggplot(data = mpg, aes(x = class)) + geom_bar()
# geom_col() : 합계 그래프, 원자료를 가공해서 요약한 평균 데이터를 이용해서
# 그래프를 만들어야 한다.
# geom_bar() : 개수 그래프, 원자료의 데이터 개수만 가지고 그래프를 만든다.

# 선 그래프
economics
# pce : 개인 소비 지출, pop : 총 인구, psavert : 개인 저축률
# uempmed : 실업기간, unemploy : 실업자수
ggplot(data = economics, aes(x = date, y = uempmed)) + geom_line()
ggplot(data = economics, aes(x = date, y = psavert)) + geom_line()
ggplot(data = economics, aes(x = date, y = unemploy)) + geom_line()
ggplot(data = economics, aes(x = date, y = pce)) + geom_line()

economics_date <- subset(economics, date >= as.Date('2010-01-01') &
                             date <= as.Date('2015-12-31'))
ggplot(data = economics_date, aes(x = date, y = unemploy)) + geom_line()

ggplot(data = economics, aes(x = date, y = unemploy)) + 
    geom_line(color = '#FF0000', lwd = 1) +
    geom_hline(yintercept=mean(economics$unemploy), linetype = 'dashed')

ggplot(data = economics, aes(x = date, y = unemploy)) + 
    geom_bar(stat = 'identity', color = '#FF0000', lwd = 1) +
    geom_hline(yintercept=mean(economics$unemploy), linetype = 'dashed')

# 상자 그래프
ggplot(data = mpg, aes(x = drv, y = hwy)) + geom_boxplot()

# 한국 복지 패널 데이터 분석하기
# 데이터가 통계 전용 소프트웨어인 SPSS, SAS, STATA 프로그램의 데이터 형태로
# 제공되기 때문에 foreign 패키지를 이용해서 R에서 사용할 수 있는 형태의 데이
# 터로 변환시킨 후 사용해야 한다.
install.packages('foreign')
library(foreign)

# foreign 패키지의 read.spss() 함수를 이용해 SPSS 타입의 데이터를 데이터 프레
# 임 형태로 R로 불러온다.
# 그냥 읽어오면 list 타입으로 읽어오기 때문에 데이터 프레임 형태로 불러오기
# 위해 to.data.frame = T 옵션을 지정한다.
raw_walfare <- read.spss('Koweps_hpc10_2015_beta1.sav', to.data.frame = T)

walfare <- raw_walfare # 사본을 만들어 작업한다.
head(walfare)
tail(walfare)
View(walfare) # 데이터를 excel sheet 형태로 출력한다.
dim(walfare) # 데이터 프레임이 몇행 몇열인가 출력한다.
str(walfare)
summary(walfare)
class(walfare)

# dplyr 패키지의 rename() 함수를 사용해서 작업에 적절하고 코드북을 참조해서
# 변수의 이름을 변경한다.
library(dplyr)
walfare <- rename(walfare, gender = h10_g3) # 성별
walfare <- rename(walfare, birth = h10_g4) # 출생년도
walfare <- rename(walfare, marriage = h10_g10) # 혼인상태
walfare <- rename(walfare, religion = h10_g11) # 종교
walfare <- rename(walfare, code_job = h10_eco9) # 직종코드
walfare <- rename(walfare, income = p1002_8aq1) # 급여
walfare <- rename(walfare, code_region = h10_reg7) # 지역코드

#############################################################################

# 성별에 따른 급여 차이는 존재하는가?

# 성별 데이터 전처리
class(walfare$gender)
table(walfare$gender) # 1 => 남, 2 => 여, 9 => 모름/무응답
walfare$gender <- ifelse(walfare$gender == 9, NA, walfare$gender)
table(is.na(walfare$gender))
walfare$gender <- ifelse(walfare$gender == 1, 'male', 'female')

# 급여 데이터 전 처리
class(walfare$income)
table(walfare$income)
hist(walfare$income)
qplot(walfare$income)
boxplot(walfare$income)
# 급여는 1~9998 사이의 값을 가지므로 급여의 볌위를 벗아나는 경우 결측치로
# 처리한다.
walfare$income <- ifelse(walfare$income < 1 | walfare$income > 9998, NA,
                         walfare$income)
walfare$income <- ifelse(walfare$income >= 1 & walfare$income <= 9998, 
                         walfare$income, NA)
table(is.na(walfare$income))

# 성별에 따른 평균 급여 표를 만든다.
gender_income <- walfare %>% 
    filter(!is.na(income)) %>% # 급여가 NA가 아닌 데이터만 추출한다.
    group_by(gender)
table(is.na(gender_income$income))

gender_income <- walfare %>% 
    filter(!is.na(income)) %>%
    group_by(gender) %>% 
    summarise(mean_income = mean(income))
ggplot(data = gender_income, aes(x = gender, y = mean_income)) +
    geom_col()

#############################################################################

# 몇 살때 급여를 가장 많이 받을까?

# 출생년도 전처리
class(walfare$birth)
table(walfare$birth)
qplot(walfare$birth)
walfare$birth <- ifelse(walfare$birth == 9999, NA, walfare$birth)
walfare$birth <- ifelse(walfare$birth < 1900 | walfare$birth > 2014, NA,
                        walfare$birth)

# 나이를 기억할 파생 변수를 만들어 나이를 저장한다.
walfare$age <- 2015 - walfare$birth
table(walfare$age)
qplot(walfare$age)

# 나이에 따른 급여 평균 표를 만든다.
age_income <- walfare %>% 
    filter(!is.na(walfare$income)) %>% 
    group_by(age) %>% 
    summarise(mean_income = mean(income))

ggplot(data = age_income, aes(x = age, y = mean_income)) + geom_col()
ggplot(data = age_income, aes(x = age, y = mean_income)) + geom_line()








