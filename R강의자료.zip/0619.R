# excel 파일을 csv 파일로 변환하지 않고 바로 읽어들이려면 readxl 패키지를 설치
# 하고 로드한 후 사용한다.
install.packages('readxl')
library(readxl)

excel_exam <- read_excel('excel_exam.xlsx')
class(excel_exam)

# 읽어들일 excel 파일의 첫 번째 줄이 열 이름이 아닐 경우 col_names = F 옵션을
# 지정해서 읽어들이면 된다. => 읽어들인 후 열 이름을 별도로 지정해야 한다.
excel_exam_noheader <- read_excel('excel_exam_noheader.xlsx', col_names = F)
class(excel_exam_noheader)

library(dplyr)
# col_names = F 옵션을 지정해서 읽어들인 excel 파일의 열 이름은 R이 자동으로
# ...1  ...2와 같이 열 이름을 붙여준다.
# 만약에 자동으로 붙여준 열 이름을 변경하는데 에러가 발생되면 따옴표로 묶어서
# 사용한다.
excel_exam_noheader_copy <- excel_exam_noheader
excel_exam_noheader_copy <- rename(excel_exam_noheader_copy, id = ...1)
# 위의 식이 에러가 발생되며 동작하지 않으면 아래와 같이 하면 된다.
excel_exam_noheader_copy <- rename(excel_exam_noheader_copy, id = '...1')
excel_exam_noheader_copy <- rename(excel_exam_noheader_copy, class = ...2, 
                            math = ...3, english = ...4, science = ...5)

# tibble 타입의 데이터는 사용하는 패키지에 따라서 정상적으로 처리되지 않을
# 수 있으므로 데이터 프레임 타입으로 변환시킨 후 사용하는 것이 좋다.
df_excel_exam_noheader <- as.data.frame(excel_exam_noheader_copy)
class(df_excel_exam_noheader)

# 읽어들일 excel 파일에 여러개의 sheet가 있을 때 특정 시트의 데이터를 읽으
# 려면 sheet = n(n은 읽을 sheet의 위치) 옵션을 지정해서 읽어들인다.
excel_exam <- read_excel('excel_exam.xlsx', sheet = 3)

############################################################################

# write.csv() 함수로 데이터 프레임을 csv 파일로 저장한다.
df_excel_exam <- as.data.frame(excel_exam)
class(df_excel_exam)
# write.csv(데이터 프레임, file = 'csv 파일명')
write.csv(df_excel_exam, file = 'df_excel_exam.csv')
# 데이터 프레임을 csv 파일로 저장하면 행 번호도 같이 csv 파일로 저장된다.
# 행 번호를 csv 파일에 저장할 필요가 없으면 row.names = F 옵션을 지정하면
# 된다.
write.csv(df_excel_exam, file = 'df_excel_exam.csv', row.names = F)

############################################################################

# RData 파일은 R 전용 데이터 파일료 다른 파일에 비해서 R에서 읽고 쓰는 속도가
# 빠르고 용량이 작다는 장점이 있다.
# 일반적으로 R에서 작업할 때는 RData 파일을 사용하고 R을 사용하지 않는 사람과
# 데이터를 주고 받을 경우 csv 파일이나 excel 파일을 사용한다.
# 작업중인 데이터를 R 전용 데이터 파일로 저장하고 필요할 때 불러와서 사용하면
# 된다.

# save() 함수로 데이터 프레임을 RData 파일로 저장한다.
# save(데이터 프레임, file = 'RData 파일명')
save(df_excel_exam, file = 'excel_exam_rda.rda')

# rm() 함수로 사용중인 기억장소를 메모리에서 제거할 수 있다.
rm(df_excel_exam)

# load() 함수로 RData 파일에 저장된 데이터를 메모리로 가져온다.
# load(file = 'RData 파일명')
load(file = 'excel_exam_rda.rda')
# load() 함수로 불러온 RData 파일은 변수에 할당하면 안된다. 변수에 할당하면
# 문자 데이터로 취급된다. => 데이터 프레임 이름이 변수에 저장된다.
df_excel_exam_load <- load(file = 'excel_exam_rda.rda')
class(df_excel_exam_load)

############################################################################

# summary() 함수를 이용해서 데이터의 요약 통계량을 출력한다.
summary(df_excel_exam)
# str() 함수를 이용해서 데이터 프레임에 저장된 데이터의 개수, 변수(열)의 
# 개수, 변수 이름, 변수의 자료형, 변수에 저장된 데이터의 일부를 보여준다.
str(df_excel_exam)

############################################################################

# 파생 변수 만들기 => 계산에 의한 변수를 만든다.

df_raw <- data.frame(var1 = c(1, 2, 1), var2 = c(2, 3, 4))
df_var <- df_raw

# 1. 데이터프레임$파생변수 <- 파생 변수에 대입할 데이터
df_var$var_sum <- df_var$var1 + df_var$var2
df_var$var_mean <- (df_var$var1 + df_var$var2) / 2
df_var$var_mean <- df_var$var_sum / 2

df_excel_exam_copy <- df_excel_exam
df_excel_exam_copy$var_sum = df_excel_exam_copy$math2 + 
    df_excel_exam_copy$english2 + df_excel_exam_copy$science2
df_excel_exam_copy$var_mean <- df_excel_exam_copy$var_sum / 3

# subset() 함수로 데이터 프레임에서 특정 변수의 데이터만 뽑아낼 수 있다.
df_excel_exam_copy[,c('math2', 'english2', 'science2')]
# subset(데이터 프레임, select = 시작변수명:끝변수명)
subset(df_excel_exam_copy, select = math2:science2)

df_excel_exam_copy[,c('math2', 'science2')]
# subset(데이터 프레임, select = c(변수명, ...))
subset(df_excel_exam_copy, select = c(math2, science2))

# rowSums() 함수로 행의 합계를 계산할 수 있고 rowMeans() 함수로 행의 평균을
# 계산할 수 있다.
df_excel_exam_copy$var_sum2 <- 
    rowSums(subset(df_excel_exam_copy, select = math2:science2))
df_excel_exam_copy$var_mean2 <- 
    rowMeans(subset(df_excel_exam_copy, select = math2:science2))

# 2. transform() 함수를 사용해서 파생 변수를 추가할 수 있다.
# transform(데이터 프레임, 파생 변수 이름 = 파생 변수에 대입할 데이터)
df_excel_exam_copy <- transform(df_excel_exam_copy, 
                      var_sum3 = rowSums(subset(df_excel_exam_copy, 
                                         select = math2:science2)))
df_excel_exam_copy <- transform(df_excel_exam_copy, 
                      var_mean3 = rowMeans(subset(df_excel_exam_copy, 
                                          select = math2:science2)))

df_excel_exam_copy <- df_excel_exam
# 3. dplyr 패키지의 mutate() 함수를 사용해서 한 번에 여러개의 파생 변수를 
# 추가할 수 있다.
# %>% => dplyr 패키지에 있는 일종의 대입문으로 %>% 왼쪽의 데이터가 %>% 오른
# 쪽의 함수로 입력된다. ctrl + shift + M을 동시에 누르면 자동으로 입력된다.
# %>% 왼쪽의 데이터 프레임이 %>% 오른쪽의 함수로 전달되기 때문에 데이터프레
# 임의 열을 사용해야 할 때 [데이터프레임이름$변수이름]과 같이 사용하지 않고
# 데이터 프레임 이름 없이 변수명만 사용하면 된다.
# 함수에서 만든 변수를 함수가 종료되기 전에 사용할 수 있다.
df_excel_exam_copy <- df_excel_exam_copy %>% 
    mutate(
        var_sum = rowSums(subset(df_excel_exam_copy, 
                                 select = math2:science2)),
        var_mean = rowMeans(subset(df_excel_exam_copy, 
                                 select = math2:science2)),
        var_mean2 = var_sum / 3
    )
    
# 4. ifelse() 함수로 조건을 사용해서 파생 변수 만들기
# ifelse(조건식, 조건이 참일때 실행할 내용, 조건이 거짓일때 실행할 내용)

# 평균 점수(var_mean)가 60 이상이면 'pass', 그렇치 않으면 'fail'을 가지는
# result 파생 변수를 추가한다.
df_excel_exam_copy$result <- ifelse(df_excel_exam_copy$var_mean >= 60,
                                    'pass', 'fail')
fail <- df_excel_exam_copy[df_excel_exam_copy$result == 'fail',]
pass <- df_excel_exam_copy[df_excel_exam_copy$result == 'pass',]

# 평균 점수(var_mean)가 80 이상이면 'A', 80 미만이고 60 이상이면 'B', 그렇치 # 않으면 'C'를 가지는 grade 파생 변수를 추가한다.
df_excel_exam_copy$grade <- 
    ifelse(df_excel_exam_copy$var_mean >= 80, 
           'A', ifelse(df_excel_exam_copy$var_mean >= 60, 'B', 'C'))

############################################################################

hist(df_excel_exam_copy$var_sum) # 히스토그램
hist(df_excel_exam_copy$grade) # 에러, 히스토그램은 숫자만 가능하다.

# table() 함수를 사용해서 변수에 저장된 데이터의 빈도수를 출력한다.
table(df_excel_exam_copy$var_sum)
table(df_excel_exam_copy$grade)

library(ggplot2)
qplot(df_excel_exam_copy$result)
qplot(df_excel_exam_copy$grade)

############################################################################

# 데이터 전처리
# 데이터 전처리는 데이터 분석 작업에 적합하게 데이터를 가공하는 작업이다.
# dplyr 패키지의 함수를 이용해서 데이터의 일부를 추출하거나 종류별로 나누
# 거나 여러 데이터를 합치는 등의 작업을 한다.
library(dplyr)

# dplyr 패키지의 주요 함수
# filter() : 행 단위 데이터 추출
# select() : 열 단위 데이터 추출
# arrange() : 정렬
# mutate() : 파생 변수 추가
# summarise() : 통계치 산출
# group_by() : 그룹화
# left_join() : 열 단위 데이터 합치기
# bind_rows() : 행 단위 데이터 합치기

df_excel_exam_dplyr <- df_excel_exam
# filter() 함수로 조건에 맞는 행 단위 데이터 추출하기
# %>%는 dplyr 패키지에서 사용한는 파이프 연산자로 함수의 실행 결과를 다른
# 함수의 입력 데이터로 넘겨주는 연산자이다.
df_excel_exam_dplyr %>% 
    filter(df_excel_exam_dplyr$class2 == 1)
# 데이터 프레임이 %>% 연산자를 통해서 함수로 넘어오기 때문에 특정 변수를 선
# 택 할 때 데이터 프레임 이름을 적지 않아도 된다.
df_excel_exam_dplyr %>% filter(class2 == 1)
df_excel_exam_dplyr %>% filter(class2 == 1 | class2 == 2)
df_excel_exam_dplyr %>% filter(class2 == 1 | class2 == 2 | class2 == 5)
# 매칭 연산자(%in%)와 c() 함수를 사용하면 or 연산을 보다 쉽게 할 수 있다.
df_excel_exam_dplyr %>% filter(class2 %in% c(1, 2, 5))
# 함수의 실행 결과를 변수에 저장할 수 있다.
class1 <- df_excel_exam_dplyr %>% filter(class2 == 1)
class2 <- df_excel_exam_dplyr %>% filter(class2 == 2)

# 제조사(manufacturer)가 audi와 toyota 중 어떤 제조사의 도시 주행 연비(cty)
# 평균이 더 높은가?
mpg_audi <- mpg %>% filter(manufacturer == 'audi')
mean(mpg_audi$cty) # 17.61111
mpg_toyota <- mpg %>% filter(manufacturer == 'toyota')
mean(mpg_toyota$cty) # 18.52941

# 제조사가 chevrolet, ford, honda인 자동차의 고속도로 주행 연비(hwy) 전체
# 평균은?
mpg_manufacturer <- mpg %>% 
    filter(manufacturer %in% c('chevrolet', 'ford', 'honda'))
table(mpg_manufacturer$manufacturer)
mean(mpg_manufacturer$hwy) # 22.50943

