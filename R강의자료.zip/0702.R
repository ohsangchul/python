# Selenium 라이브러리를 로드한다.
library(RSelenium)
# Selenium 서버를 시작한다.
remDr <- remoteDriver(remoteServerAddr = 'localhost', port = 4445,
                      browserName = 'chrome')
# chrome을 실행한다.
remDr$open()
# yes24 명견만리 새로운 사회편 리뷰 페이지에 접속한다.
remDr$navigate('http://www.yes24.com/Product/Goods/40936880')

##################################################################################
# 스크롤 바를 아래로 이동 시켜야 아래쪽의 컨텐츠가 로딩되는 무한 스크롤 방식의 
# 페이지를 웹 스크레이핑 하려면 스크롤 바를 한번에 끝까지 내리면 안되고 조금씩
# 아래로 스크롤 시켜가면서 웹 페이지가 로딩되는 상황을 봐야한다.
# 스크롤 바를 이동시키려면 executeScript() 함수로 자바스크립트를 실행해야 한다.

# 웹 페이지의 body 태그 전체(브라우저에 컨텐츠가 표시되는 영역 전체)를 얻어온다.
webBody <- remDr$findElement('css selector', 'body')

# 스크롤 바를 끝까지 한꺼번에 내린다. - scrollTo
remDr$executeScript('scrollTo(0, document.body.scrollHeight - 200)', 
                    args = list(webBody))

# 스크롤 바를 조금씩 내린다. - scrollBy
remDr$executeScript('scrollBy(0, 2000)', args = list(webBody))
# 무한 스크롤 방식으로 처리되는 사이트는 스크롤 바가 아래로 이동할때 화면에 보이지
# 안던 컨텐츠가 로딩되므로 컨텐츠가 로딩될 시간을 줘야한다.
Sys.sleep(1)
##################################################################################

# 첫 번째 리뷰의 제목만 읽어온다.
doms <- remDr$findElements('css selector', '#infoset_reviewContentList > div:nth-child(3) > div.reviewInfoTop > span.review_tit > span')
review <- sapply(doms, function(x) { x$getElementText() })
review <- unlist(review)
review

# 첫 번째 리뷰의 내용만 읽어온다. - 전체 리뷰의 내용을 읽지 못한다.
doms <- remDr$findElements('css selector', '#infoset_reviewContentList > div:nth-child(3) > div.reviewInfoBot.crop > div')
review <- sapply(doms, function(x) { x$getElementText() })
review <- unlist(review)
review

# 첫 번째 리뷰의 내용만 읽어온다. - 전체 리뷰의 내용을 읽어온다.
# 펼쳐보기 클릭
reviewOpen <- remDr$findElements('css selector', '#infoset_reviewContentList > div:nth-child(3) > div.btn_halfMore > a > em.txt.txt_open')
sapply(reviewOpen, function(x) { x$clickElement() })
# 펼쳐보기가 클릭되면 표시되는 전체 리뷰 읽기
doms <- remDr$findElements('css selector', '#infoset_reviewContentList > div:nth-child(3) > div.reviewInfoBot.origin > div.review_cont')
review <- sapply(doms, function(x) { x$getElementText() })
review <- unlist(review)
review

##################################################################################

# yes24 명견만리 새로운 사회편 전체 리뷰를 읽는다.
library(RSelenium)
remDr <- remoteDriver(remoteServerAddr = 'localhost', port = 4445,
                      browserName = 'chrome')
remDr$open()
remDr$navigate('http://www.yes24.com/Product/Goods/40936880')
review <- NULL

# 1 페이지의 리뷰를 읽는다.
for(i in 3:7) {
    # 펼쳐보기 클릭
    openLink <- paste('#infoset_reviewContentList > div:nth-child(', i, ') > div.btn_halfMore > a > em.txt.txt_open', sep = '')
    # print(openLink)
    reviewOpen <- remDr$findElements('css selector', openLink)
    # 리뷰가 존재하지 않으면 펼쳐보기 링크도 존재하지 않기 때문에 반복을 종료한다.
    if(length(reviewOpen) == 0) {
        break
    }
    sapply(reviewOpen, function(x) { x$clickElement() })
    Sys.sleep(1) # 펼쳐보기가 클릭되면 전체 리뷰 내용이 표시될때 까지 기다린다.
    # 전체 리뷰 읽기
    viewLink <- paste('#infoset_reviewContentList > div:nth-child(', i, ') > div.reviewInfoBot.origin > div.review_cont')
    doms <- remDr$findElements('css selector', viewLink)
    result <- sapply(doms, function(x) { x$getElementText() })
    review <- c(review, unlist(result))
    Sys.sleep(1) # 전체 리뷰 내용를 읽었으면 잠시 기다린다.
}

# 무한 루프를 돌면서 나머지 리뷰를 읽는다.
repeat {
    # 첫 페이지의 리뷰를 읽었으므로 나머지 2페이지 부터 10페이지의 리뷰를 읽는다.
    for(i in 4:12) {
        # 다음 리뷰 페이지 링크를 클릭한다.
        nextLink <- paste('#infoset_reviewContentList > div.review_sort.sortBot > div.review_sortLft > div > a:nth-child(', i, ')')
        nextPage <- remDr$findElements('css selector', nextLink)
        # 다음 리뷰 페이지 링크가 존재하지 않으면 더이상 리뷰가 없으므로 반복을
        # 종료한다.
        if(length(nextPage) == 0) {
            break
        }
        sapply(nextPage, function(x) { x$clickElement() })
        Sys.sleep(1) # 다음 리뷰 페이지가 로딩될 동안 잠시 기다린다.
        
        # 한 페이지에 보이는 리뷰의 개수(5개) 만큼 반복하며 리뷰를 읽는다.
        for(j in 3:7) {
            openLink <- paste('#infoset_reviewContentList > div:nth-child(', j, ') > div.btn_halfMore > a > em.txt.txt_open', sep = '')
            reviewOpen <- remDr$findElements('css selector', openLink)
            if(length(reviewOpen) == 0) {
                break
            }
            sapply(reviewOpen, function(x) { x$clickElement() })
            Sys.sleep(1)
            viewLink <- paste('#infoset_reviewContentList > div:nth-child(', j, ') > div.reviewInfoBot.origin > div.review_cont')
            doms <- remDr$findElements('css selector', viewLink)
            result <- sapply(doms, function(x) { x$getElementText() })
            review <- c(review, unlist(result))
            Sys.sleep(1)
        }
    }
    
    # 다음 10페이지 링크를 클릭해 다음 10페이지로 넘겨준다.
    next10Page <- remDr$findElements('css selector', '#infoset_reviewContentList > div.review_sort.sortBot > div.review_sortLft > div > a.bgYUI.next')
    # 더 이상 읽을 다음 10페이지가 없으면 무한 반복을 종료한다.
    if(length(next10Page) == 0) {
        break
    }
    sapply(next10Page, function(x) { x$clickElement() })
    Sys.sleep(1)
    
    # 다음 10페이지로 넘어왔으므로 다시 첫 페이지를 읽는다.
    for(i in 3:7) {
        openLink <- paste('#infoset_reviewContentList > div:nth-child(', i, ') > div.btn_halfMore > a > em.txt.txt_open', sep = '')
        reviewOpen <- remDr$findElements('css selector', openLink)
        if(length(reviewOpen) == 0) {
            break
        }
        sapply(reviewOpen, function(x) { x$clickElement() })
        Sys.sleep(1)
        viewLink <- paste('#infoset_reviewContentList > div:nth-child(', i, ') > div.reviewInfoBot.origin > div.review_cont')
        doms <- remDr$findElements('css selector', viewLink)
        result <- sapply(doms, function(x) { x$getElementText() })
        review <- c(review, unlist(result))
        Sys.sleep(1)
    }
}

##################################################################################

# 트위터 검색하기
install.packages('twitteR')
library(twitteR)

# 트위터 검색을 하기 위한 API key를 설정한다.
api_key <- "gjUkHgO8bFmNobRk4g0Jas8xb"
api_secret <- "loF0mtnzLhtQDFjahdRHox6wcR1fiD6Fw95DP5QCSy3rLTTP1K"
access_token <- "607145164-8L5HtzopZzhjuBCgusUGKE3MHOa9P4RbmhUrM0E1"
access_token_secret <- "2wn2bsCA7JIH5DZ5Ss1deS5BNLabzaX2xSpM2ZLMIqwQf"

# 트위터에 연결한다.
setup_twitter_oauth(api_key, api_secret, access_token, access_token_secret)
# 트위터에 연결될 때 아래 메시지를 출력하고 응답을 기다린다. => 2를 입력한다.
# [1] "Using direct authentication"
# Use a local file ('.httr-oauth'), to cache OAuth access credentials between R 
# sessions?
#    
# 1: Yes
# 2: No
#
# 선택: 2를 입력하고 엔터키를 누른다.

# 트위터에서 검색할 검색어를 지정한다.
key <- '개발자'
# 검색어를 유니코드로 변환한다.
key <- enc2utf8(key)

# searchTwitter() 함수로 검색어가 포함된 트위터를 지정한 개수(n) 만큼 검색한다.
# searchTwitter('검색어', since = '검색 시작일', 
#               geocode = '위도, 경도, 거리km', n = 최대 검색 개수)
result <- searchTwitter(key, n = 10000)
# result <- searchTwitter(key, since = '2018-01-01', n = 10000)
# result <- searchTwitter(key, geocode = '37.498, 127.037, 100km', n = 10000)

# twListToDF() 함수를 사용해서 검색된 데이터를 데이터 프레임으로 변환한다.
df_twitter <- twListToDF(result)
str(df_twitter)

##################################################################################

library(dplyr)
library(rJava)
library(KoNLP)
library(RColorBrewer)
library(wordcloud)
useNIADic()

twitter_data <- gsub('[[:lower:][:upper:][:digit:][:punct:][:cntrl:]]', '',
                     df_twitter$text)
nouns <- extractNoun(twitter_data)
nouns <- unlist(nouns)
wordCount <- table(nouns)
df_wordCount <- as.data.frame(wordCount)
df_wordCount <- rename(df_wordCount, word = nouns, freq = Freq)

df_wordCount$word <- gsub('ㅋ', '', df_wordCount$word)
df_wordCount$word <- gsub('^', '', df_wordCount$word)
df_wordCount$word <- gsub('ㅠ', '', df_wordCount$word)
df_wordCount$word <- gsub('ㅜ', '', df_wordCount$word)

wordcloud_data <- df_wordCount %>% 
    filter(nchar(word) >= 2 & nchar(word) <= 6) %>% 
    filter(word != '^^^^^' & word != '^^^^' & word != '^^^' & word != '^근데'
           & word != '^ㅎ') %>% 
    arrange(desc(freq)) %>% 
    head(200)

set.seed(1)
pal <- brewer.pal(8, 'Dark2')
wordcloud(words = wordcloud_data$word, freq = wordcloud_data$freq,
          min.freq = 2, max.words = 200, random.order = F, rot.per = 0.1,
          scale = c(6, 0.3), colors = pal)










