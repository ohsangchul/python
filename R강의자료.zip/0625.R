# 필요한 라이브러리 로드한다.
library(ggplot2)
library(dplyr)
library(foreign)
# 분석할 데이터를 불러와서 사본을 만든다.
rew_welfare <- read.spss('Koweps_hpc10_2015_beta1.sav', to.data.frame = T)
welfare <- raw_welfare
# 변수명을 변경한다.
welfare <- rename(welfare, gender = h10_g3) # 성별
welfare <- rename(welfare, birth = h10_g4) # 출생년도
welfare <- rename(welfare, marriage = h10_g10) # 혼인상태
welfare <- rename(welfare, religion = h10_g11) # 종교
welfare <- rename(welfare, code_job = h10_eco9) # 직종코드
welfare <- rename(welfare, income = p1002_8aq1) # 급여
welfare <- rename(welfare, code_region = h10_reg7) # 지역코드
# 성별 전처리
welfare$gender <- ifelse(welfare$gender == 9, NA, welfare$gender)
welfare$gender <- ifelse(welfare$gender == 1, 'male', 'female')
# 급여 전처리
welfare$income <- ifelse(welfare$income < 1 | welfare$income > 9998, NA,
                         welfare$income)
# 출생년도 전처리
welfare$birth <- ifelse(welfare$birth == 9999, NA, welfare$birth)
welfare$birth <- ifelse(welfare$birth < 1900 | welfare$birth > 2014, NA,
                        welfare$birth)
# 나이 계산
welfare$age <- 2015 - welfare$birth
# 직업 전처리
# Koweps_Codebook.xlsx 파일의 2번째 시트의 데이터를 읽어온다.
library(readxl)
job_list <- read_excel('Koweps_Codebook.xlsx', sheet = 2)
# left_join() 함수로 welfare에 job_list를 결합시킨다.
welfare_job <- welfare # 사본 저장
welfare_job <- left_join(welfare_job, job_list, by = 'code_job')
# 종교 전처리
table(welfare$religion)
welfare$religion <- ifelse(welfare$religion == 9, NA, welfare$religion)
welfare$religion <- ifelse(welfare$religion == 1 | welfare$religion == 2, 
                           welfare$religion, NA)
welfare$religion <- ifelse(welfare$religion == 1, 'yes', 'no')

# 혼인상태 전처리
# 혼인상태 데이터는 다른 작업에 사용할 수 있으므로 원래 데이터는 그대로 유지
# 시키고 파생 변수를 만들어 혼인 상태를 저장한다.
table(welfare$marriage)
welfare$group_marriage <- ifelse(welfare$marriage == 1, 'marriage', 
                                 ifelse(welfare$marriage == 3, 'divorce', NA))

#############################################################################

# 지역 전처리
str(welfare)
table(welfare$code_region)
welfare_region <- welfare
welfare_region$code_region <- ifelse(welfare_region$code_region < 1 |
                                         welfare_region$code_region >7,
                                     NA, welfare_region$code_region)
table(welfare_region$code_region)
# 7개의 지역을 기억하는 데이터 프레임을 만든다.
list_region <- data.frame(code_region = c(1:7), 
               region = c('서울', '수도권(인천/경기)', '부산/경남/울산',
                          '대구/경북', '대전/충남', '강원/충북', 
                          '광주/전남/전북/제주도'))
# welfare_region와 list_region를 left_join() 함수로 code_region 변수를 기준
# 으로 결합시킨다.
welfare_region <- left_join(welfare_region, list_region, by = 'code_region')
welfare_region %>% select(code_region, region)
table(welfare_region$code_region)
table(welfare_region$region)

#############################################################################

# 어떤 지역에 어떤 연령대가 많이 사는가?

# 지역별, 연령대별 비율표를 만든다.
region_age_group <- welfare_region %>% 
    filter(!is.na(region)) %>% 
    group_by(region, age_group) %>% 
    summarise(n = n()) %>% 
    mutate(pct = round(n / sum(n) * 100, 1))

ggplot(data = region_age_group, aes(x = region, y = pct, fill = age_group)) +
    geom_col(position = 'dodge') + 
    coord_flip()
ggplot(region_age_group, aes(region, pct, fill = age_group)) +
    geom_col(position = 'dodge') + 
    coord_flip()

# 연령대가 middle이 많은 지역은 어디일까?
region_age_group_middle <- region_age_group %>% 
    filter(age_group == 'middle')
ggplot(region_age_group_middle, aes(reorder(region, -pct), pct)) +
    geom_col()
ggplot(region_age_group_middle, aes(reorder(region, pct), pct)) +
    geom_col() +
    coord_flip()

region_age_group_middle <- region_age_group %>% 
    filter(age_group == 'middle') %>% 
    arrange(desc(pct))
order_middle_list <- region_age_group_middle$region # x축 레이블 출력순서
ggplot(region_age_group_middle, aes(region, pct)) +
    geom_col() +
    scale_x_discrete(limit = order_middle_list) # x축 레이블 출력순서 지정

# 연령대가 young이 많은 지역은 어디일까?
region_age_group_young <- region_age_group %>% 
    filter(age_group == 'young')
ggplot(region_age_group_young, aes(reorder(region, -pct), pct)) +
    geom_col()
ggplot(region_age_group_young, aes(reorder(region, pct), pct)) +
    geom_col() +
    coord_flip()

region_age_group_young <- region_age_group %>% 
    filter(age_group == 'young') %>% 
    arrange(desc(pct))
order_young_list <- region_age_group_young$region
ggplot(region_age_group_young, aes(region, pct)) +
    geom_col() +
    scale_x_discrete(limit = order_young_list)

# 연령대가 old이 많은 지역은 어디일까?
region_age_group_old <- region_age_group %>% 
    filter(age_group == 'old')
ggplot(region_age_group_old, aes(reorder(region, -pct), pct)) +
    geom_col()
ggplot(region_age_group_old, aes(reorder(region, pct), pct)) +
    geom_col() +
    coord_flip()

region_age_group_old <- region_age_group %>% 
    filter(age_group == 'old') %>% 
    arrange(desc(pct))
order_old_list <- region_age_group_old$region
ggplot(region_age_group_old, aes(region, pct)) +
    geom_col() +
    scale_x_discrete(limit = order_old_list)

#############################################################################

order_young_list <- region_age_group_young$region
ggplot(data = region_age_group, aes(x = region, y = pct, fill = age_group)) +
    geom_col(position = 'dodge') + 
    scale_x_discrete(limit = order_young_list)

order_middle_list <- region_age_group_middle$region
ggplot(data = region_age_group, aes(x = region, y = pct, fill = age_group)) +
    geom_col(position = 'dodge') + 
    scale_x_discrete(limit = order_middle_list)

order_old_list <- region_age_group_old$region
ggplot(data = region_age_group, aes(x = region, y = pct, fill = age_group)) +
    geom_col(position = 'dodge') + 
    scale_x_discrete(limit = order_old_list)

#############################################################################

# 범례 순서 변경하기

class(region_age_group$age_group) # character
# factor 타입이 아니므로 NULL이 출력된다.
levels(region_age_group$age_group) # NULL
# factor() 함수를 이용해 age_group 변수 타입을 factor 타입으로 변환하고
# levels 속성으로 범례 순서를 변경할 수 있다.

region_age_group$age_group <- factor(region_age_group$age_group,
                                     levels = c('young', 'middle', 'old'))
class(region_age_group$age_group) # factor
levels(region_age_group$age_group) # "young"  "middle" "old" 

ggplot(data = region_age_group, aes(x = region, y = pct, fill = age_group)) +
    geom_col(position = 'dodge') + 
    scale_x_discrete(limit = order_young_list)

#############################################################################

# 텍스트 마이닝
# 문자로 된 데이터에서 가치있는 정보를 얻어내서 분석하는 기법을 말한다.
# 텍스트 마이닝을 할 때 가정 먼저 하는 작업은 분석하려는 텍스트가 저장된
# 웹 페이지의 텍스트를 얻어오는 것이다. => 크롤링, 스크레이핑
# 준비된 데이터의 문장을 구성하는 어절들이 어떤 품사로 되어있는지 파악하는
# 형태소 분석 작업을 한다.
# 형태소 분석이란 어절들의 품사를 파악한 후 명사, 형용사, 동사 등 의미를 가진
# 품사의 단어를 추출해 각 단어가 얼마나 많이 등장했는가 파악하는 것이다.

# 1. 자바가 먼저 설치되어 있어야 하고 아래의 패키지를 설치하고 로드한다.
install.packages('rJava')
install.packages('KoNLP')
library(rJava)
library(KoNLP)

# 2. 데이터 전처리에 사용할 패키지를 로드하고 사용할 형태소 사전을 설정한다.
library(dplyr)
useNIADic() # 983012 words dictionary was built.

# 3. 형태소 분석 작업을 실행할 데이터를 읽어들인다. => 크롤링, 스크레이핑
# readLines() 함수로 텍스트 마이닝을 실행할 텍스트 파일을 읽어들인다.
txt <- readLines('hiphop.txt')

# 정규식 => http://highcode.tistory.com/6 참조
# ^ : 문자열의 시작
# $ : 문자열의 종료
# . : 임의의 한 문자 (문자의 종류 가리지 않음) 단, \ 는 넣을 수 없음
# * : 앞 문자가 없을 수도 무한정 많을 수도 있음
# + : 앞 문자가 하나 이상
# ? : 앞 문자가 없거나 하나있음
# [] : 문자의 집합이나 범위를 나타내며 두 문자 사이는 - 기호로 범위를 나타낸다. #      []내에서 ^가 선행하여 존재하면 not 을 나타낸다.
# {} : 횟수 또는 범위를 나타낸다.
# () : 소괄호 안의 문자를 하나의 문자로 인식 
# | : 패턴 안에서 or 연산을 수행할 때 사용
# \s : 공백 문자
# \S : 공백 문자가 아닌 나머지 문자
# \w : 알파벳이나 숫자
# \W : 알파벳이나 숫자를 제외한 문자
# \d : 숫자 [0-9]와 동일
# \D : 숫자를 제외한 모든 문자
# \ : 정규표현식 역슬래시(\)는 확장 문자
#     역슬래시 다음에 일반 문자가 오면 특수문자로 취급하고 역슬래시 다음에
#     특수문자가 오면 그 문자 자체를 의미
# (?i) : 앞 부분에 (?i) 라는 옵션을 넣어주면 대소문자를 구분하지 않음

# 자주 쓰이는 패턴
# 숫자만 : ^[0-9]*$
# 영문자만 : ^[a-zA-Z]*$
# 한글만 : ^[가-힣]*$
# 영어 & 숫자만 : ^[a-zA-Z0-9]*$
# E-Mail : ^[a-zA-Z0-9]+@[a-zA-Z0-9]+$
# 휴대폰 : ^01(?:0|1|[6-9]) - (?:\d{3}|\d{4}) - \d{4}$
# 일반전화 : ^\d{2,3} - \d{3,4} - \d{4}$
# 주민등록번호 : \d{6} \- [1-4]\d{6}
# IP 주소 : ([0-9]{1,3}) \. ([0-9]{1,3}) \. ([0-9]{1,3}) \. ([0-9]{1,3})

# POSIX 표준 정규 표현식의 문자 클래스
# [:alnum:] : 알파벳과 숫자
# [:alpha:] : 알파벳 대소문자
# [:blank:] : 탭(\t)
# [:cntrl:] : 제어 문자
# [:digit:] : 숫자
# [:xdigit:] : 16진수(hex)형 숫자, 즉 [0-9a-fA-F]
# [:upper:] : 알파벳 대문자
# [:lower:] : 알파벳 소문자
# [:space:] : 탭(\t), CR(\r), LF(\n)
# [:print:] : 출력 가능한 문자
# [:graph:] : 공백을 제외한 문자
# [:punct:] : 출력 가능한 특수 문자
# 정규 표현식에서 POSIX를 사용할 경우 "["와 "]"로 묶어줘야 한다.

# 4. 텍스트 마이닝을 수행할 데이터에서 정규 표현식 또는 gsub() 함수를 사용해서
# 불필요한 문자를 제거한다. => 전처리
# R에서 정규 표현식을 사용하려면 stringr 패키지를 설치하고 로드한다.
install.packages('stringr')
library(stringr)

txt <- readLines('hiphop.txt')
# str_replace_all(변수, '찾을 문자열', '바꿀 문자열')
# '\'는 연속해서 2개를 써야 '\'로 인식된다.
# txt <- str_replace_all(txt, '\\W', ' ')
# gsub('찾을 문자열', '바꿀 문자열', 변수)
# txt <- gsub('\\W', '', txt)
# 아래와 같은 방식으로 처리해야 모든 특수문자가 제거되고 공백은 유지된다.
txt<- gsub('[[:punct:]]', '', txt)
# 아래와 같은 방식으로 처리하면 모든 특수문자, 숫자가 제거되고 공백은 유지된다.
txt<- gsub('[[:punct:][:digit:]', '', txt)

# 5. extractNoun() 함수를 사용해서 명사를 추출한다. => 결과는 list 타입이다.
extractNoun('대한민국의 영토는 한반도와 그 부속도서로 한다.')
noun <- extractNoun(txt)
# unlist() 함수로 추출된 명사 list를 charactor 벡터로 변환한다.
noun <- unlist(noun)
class(noun)
head(noun, 10)

# 6. table() 함수를 사용해 단어별 빈도표를 만든다.
wordCount <- table(noun)
class(wordCount) # table
head(wordCount, 10)

# table 타입으로 생성되는 단어별 빈도표를 as.data.frame() 함수를 사용해 데이터
# 프레임으로 변환한다.
df_wordCount <- as.data.frame(wordCount)
class(df_wordCount) # data.frame
head(df_wordCount, 10)

# 데이터 프레임의 변수 이름을 워드 클라우드 옵션에 맞게 변경한다. 안해도 됨!!
df_wordCount <- rename(df_wordCount, word = noun, freq = Freq)

# 7. 단어에서 모든 숫자를 제거한다.
# 단어에 포함된 모든 숫자를 제거한다.
# df_wordCount$word <- gsub('[[:digit:]]', '', df_wordCount$word)
# 단어가 숫자로만 구성된 경우에만 모든 숫자를 제거한다.
df_wordCount$word <- gsub('^[0-9]*$', '', df_wordCount$word)
# 공백이 연속해서 2개 나온 경우 제거한다.
df_wordCount$word <- gsub('  ', '', df_wordCount$word)

# 8. 단어를 구성하는 음절의 개수가 두 글자 이상으로 구성된 단어만 추출하고 출현
# 빈도수의 내림차순으로 정렬해서 필요만 개수의 단어를 추출한다.
# nchar() : 글자수를 세는 함수
df_wordCount <- df_wordCount %>% filter(nchar(word) >= 2)
# 워드 클라우드로 구성할 단어를 추출한다.
top200 <- df_wordCount %>% arrange(desc(freq)) %>% head(200)

#############################################################################

# 워드 클라우드
# 단어의 출현 빈도를 구름 모양으로 표현한 그래프로 단어의 출현 빈도에 따라 글자
# 의 크기와 색이 다르게 표현되기 때문에 어떤 단어가 얼마나 많이 사용되었는지
# 한 눈에 파악할 수 있다.

# 워드 클라우드 패키지를 설치하고 로드한다.
install.packages('wordcloud')
library(wordcloud)
# R에 내장된 패키지이므로 별도의 설치없이 로드만 하면 된다.
library(RColorBrewer)

# brewer.pal() 함수를 사용해 단어에 표시할 색 목록을 만든다.
# 팔레트에 대한 자세한 설명은 크롬에서 '팔레트 in r'로 검색하거나 다음 urldmf
# 참조한다.
# http://www.datamarket.kr/xe/index.php?mid=board_AGDR50&document_srl=203&listStyle=viewer
# brewer.pal(색상 개수, 팔레트 이름)
pal <- brewer.pal(10, 'Paired')

# 난수 고정하기
# 워드 클라우드는 함수가 실행될 때 마다 난수를 이용해 매번 다른 모양의 워드
# 클라우드를 만들기 때문에 항상 동일한 모양의 워드 클라우드가 생성되기를 원한
# 다면 wordcloud() 함수를 실행하기 전에 set.seed() 함수로 난수를 고정한다.
set.seed(1)

# 워드 클라우드를 만든다.
wordcloud(words = top200$word, # 워드 클라우드로 표시할 단어
          freq = top200$freq, # 워드 클라우드에 표시할 단어별 출현 빈도수
          min.freq = 2, # 워드 클라우드에 포시할 단어의 최소 개수
          max.words = 200, # 워드 클라우드에 표시할 단어의 최대 개수
          rot.per = 0.1, # 워드 클라우드에 표시되는 단어의 회전 비율
          random.order = F, # 출현 빈도가 높은 단어를 중앙에 배치한다.
          scale = c(5, 0.5), # 워드 클라우드에 표시되는 단어의 크기 범위
          colors = pal # 단어에 표시할 색상 목록이 저장된 팔레트트
          )

#############################################################################

# 국정원 트윗 데이터 분석하기

# twitter.csv 파일을 읽어온다.
twitter <- read.csv('twitter.csv', fileEncoding = 'UTF-8', header = T,
                    stringsAsFactor = F)
class(twitter) # data.frame
str(twitter)

# 데이터 프레임의 변수 이름을 변경한다.
library(dplyr)
twitter <- rename(twitter, no = 번호, id = 계정이름, date = 작성일, tw = 내용)
str(twitter)

# 특수문자와 제어문자를 없앤다.
library(stringr)
twitter$tw <- gsub('[[:punct:][:cntrl:]]', '', twitter$tw)

# 트윗 내용을 형태소 분석한다.
library(rJava)
library(KoNLP)
useNIADic()
nouns <- extractNoun(twitter$tw)
nouns <- unlist(nouns)

# 단어별 출현 빈도수를 계산하고 데이터 프레임으로 만든다.
wordCount <- table(nouns)
df_wordCount <- as.data.frame(wordCount)

# 데이터 프레임의 변수 이름을 수정하고 2글자 이상 6글자 이하인 단어만 뽑아낸다.
df_wordCount <- rename(df_wordCount, word = nouns, freq = Freq)
df_wordCount$word <- gsub('^[0-9]*$', '', df_wordCount$word)
df_wordCount <- df_wordCount %>% filter(nchar(word) >= 2 & nchar(word) <= 6)
top200 <- df_wordCount %>% arrange(desc(freq)) %>% head(200)

# 워드 클라우드를 만든다.
library(wordcloud)
library(RColorBrewer)
pal <- brewer.pal(10, 'Dark2')
set.seed(1)
wordcloud(words = top200$word,
          freq = top200$freq,
          min.freq = 2,
          max.words = 200,
          rot.per = 0.1,
          random.order = F,
          scale = c(7, 0.8),
          colors = pal
)

#############################################################################

library(ggplot2)
df_wordCount$word <- gsub('들이', '', df_wordCount$word)
df_wordCount <- df_wordCount %>% filter(nchar(word) >= 2 & nchar(word) <= 6)
top20 <- df_wordCount %>% arrange(desc(freq)) %>% head(20)

order_asc <- arrange(top20, freq)
ggplot(top20, aes(word, freq)) + 
    geom_col() + 
    coord_flip() +
    scale_x_discrete(limit = order_asc$word) +
    ylim(0, 2500) +
    geom_text(aes(label = freq), hjust = -0.5) # 차트의 고유값을 표시한다.

order_desc <- arrange(top20, desc(freq))
ggplot(top20, aes(word, freq)) + 
    geom_col() + 
    coord_flip() +
    scale_x_discrete(limit = order_desc$word) +
    ylim(0, 2500) +
    geom_text(aes(label = freq), hjust = -0.5)
















