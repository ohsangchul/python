# 데이터 전처리
library(dplyr)

load(file = 'excel_exam_rda.rda')
df_excel_exam

# select() 함수로 조건에 맞는 열(변수) 단위 데이터 추출하기
df_excel_exam %>% select(math2, english2, science2)
# select() 함수의 인수로 지정하는 변수 이름에 '-'를 붙여주면 '-'를 붙여준 변수
# 가 제외된 나머지 데이터를 추출한다.
df_excel_exam %>% select(-math2, -science2)

# class가 1인 데이터의 math만 출력한다.
df_excel_exam %>% filter(class2 == 1) %>% select(class2, math2)
df_excel_exam %>% select(class2, math2) %>% filter(class2 == 1)
# class가 1, 3, 5인 데이터의 science2만 출력한다.
df_excel_exam %>% 
    select(class2, science2) %>% 
    filter(class2 %in% c(1, 3, 5)) %>% 
    tail(3)

# arrange() 함수를 사용해서 데이터를 정렬해 출력할 수 있다.
df_excel_exam %>% arrange(math2) # 오름차순 정렬
# desc() 함수와 같이 사용하면 데이터를 내림차순으로 정렬할 수 있다.
df_excel_exam %>% arrange(desc(math2)) # 내림차순 정렬
# math2의 내림차순 정렬, math2가 같으면 english2로 오름차순 정렬
df_excel_exam %>% arrange(desc(math2), english2)
# math2의 내림차순 정렬, math2가 같으면 english2로 오름차순 정렬, english2도
# 같으면 science2의 오름차순 정렬
df_excel_exam %>% arrange(desc(math2), english2, science2)

# math2 상위 5건의 데이터를 얻어온다.
df_excel_exam %>% arrange(desc(math2)) %>% head(5)
# math2 하위 5건의 데이터를 얻어온다.
df_excel_exam %>% arrange(math2) %>% head(5)

library(ggplot2)
# mpg에서 audi에서 생산한 자동차 중에서 hwy가 1~5위에 해당되는 데이터를
# 추출한다.
mpg %>% 
    filter(manufacturer == 'audi') %>% 
    arrange(desc(hwy)) %>% 
    head(5)

# mutate() 함수로 파생 변수를 추가할 수 있다.
df_excel_exam %>% mutate(total = math2 + english2 + science2)
df_excel_exam %>% mutate(mean = (math2 + english2 + science2) / 3)
df_excel_exam %>% mutate(total = math2 + english2 + science2,
                         mean = (math2 + english2 + science2) / 3)
df_excel_exam %>% 
    mutate(
        total = rowSums(subset(df_excel_exam, select = math2:science2)),
        mean = rowMeans(subset(df_excel_exam, select = math2:science2))
    )

# mutate() 함수로 생성한 파생 변수를 바로 사용할 수 있다.
df_excel_exam %>% mutate(total = math2 + english2 + science2,
                         mean = total / 3)

# mpg에서 cty와 hwy를 더한 합산 연비 변수를 만들고 합산 연비 변수의 평균 연비
# 변수를 만든 다음 평균 연비 변수의 값이 가장 큰 자동차 3건을 추출한다.
mpg %>% 
    mutate(total = cty + hwy, mean = total / 2) %>% 
    select(manufacturer, model, mean) %>% 
    arrange(desc(mean)) %>% 
    head(3)

# summarise() 함수와 group_by() 함수를 사용해 그룹별로 요약하기
df_excel_exam %>% mutate(mean_math = mean(math2))
df_excel_exam %>% summarise(mean_math = mean(math2))
# 위의 두 식의 실행 결과를 살펴보면 mutate() 함수는 mean_math라는 파생 변수를
# 만들고 모든 math2 데이터의 평균을 계산해 mean_math에 넣어주지만 summarise()
# 함수는 모든 math2 데이터의 평균만 계산한다.
# group_by() 함수를 사용하지 않고 summarise() 함수만 사용하면 전체 데이터를
# 작업 대상으로 하기 때문에 그룹별로 작업하기 위해서 group_by() 함수를 사용
# 한다.
# 데이터를 그룹으로 묶어서 요약할 때 반드시 group_by() 함수로 먼저 그룹으로
# 묶어주고 summarise() 함수를 이용해서 요약해야 한다.
df_excel_exam %>% 
    group_by(class2) %>% 
    summarise(mean_math = mean(math2))

df_excel_exam %>% 
    group_by(class2) %>% 
    summarise(
        합계 = sum(math2),
        평균 = mean(math2),
        중위수 = median(math2),
        개수 = n(), # 개수는 인수를 지정하지 않는다.
        최대값 = max(math2),
        최소값 = min(math2),
        분산 = var(math2),
        표준편차 = sd(math2)
    )

# mpg에서 자동차 회사별로 그룹화, 같은 회사에서는 구동 방식(drv)별로 그룹화,
# 구동 방식도 같으면 차종(class)별로 그룹화 한 후 도시 주행 연비 평균을 계산
# 한다.
mpg %>% 
    group_by(manufacturer, drv, class) %>% 
    summarise(cty_mean = mean(cty))

# 자동차 회사별로 차종이 suv인 자동차의 도시 및 고속도로 연비의 평균을 계산
# 해서 내림차순으로 정렬하고 상위 5개를 출력한다.
mpg %>% 
    group_by(manufacturer) %>% 
    filter(class == 'suv') %>% 
    mutate(avg = (cty + hwy) / 2) %>% 
    summarise(avg_mean = mean(avg)) %>% 
    arrange(desc(avg_mean)) %>% 
    head(5)

# 차종별로 도시 연비의 평균을 계산해서 평균이 높은 순서로 출력한다.
mpg %>% 
    group_by(class) %>% 
    summarise(cty_mean = mean(cty)) %>% 
    arrange(desc(cty_mean))

# 고속도로 연비의 평균이 가장 높은 회사 3곳을 출력한다.
mpg %>% 
    group_by(manufacturer) %>% 
    summarise(hwy_mean = mean(hwy)) %>% 
    arrange(desc(hwy_mean)) %>% 
    head(3)

# 각 회사별 경차(compact)의 차종 수를 내림 차순으로 정렬해 출력한다.
mpg %>% 
    group_by(manufacturer) %>% 
    filter(class == 'compact') %>% 
    summarise(count = n()) %>% 
    arrange(desc(count))

# left_join() 함수로 가로로 데이터 합치기를 할 수 있다.
# left_join(데이터 프레임1, 데이터 프레임2, by = '기준 변수명')
# by 옵션에는 합칠 때 기준이되는 변수의 이름을 입력해야 하며 합쳐질 두 개의
# 데이터 프레임에 반드시 같은 이름의 변수가 있어야 한다.
# by 옵션을 지정하지 않으면 R이 알아서 같은 이름의 변수를 기준으로 합치기
# 를 실행한다.

test1 <- data.frame(id = c(1, 2, 3, 4, 5), middle = c(60, 80, 70, 90, 85))
test2 <- data.frame(id = c(1, 2, 3, 4, 5), final = c(70, 83, 65, 95, 80))
left_join(test1, test2, by = 'id')

df_excel_join <- df_excel_exam
df_teacher_name <- data.frame(class2 = c(1, 2, 3, 4, 5), 
           teacher = c('홍길동', '임꺽정', '장길산', '일지매', '루팡'))
# left_join() 함수로 합치기를 실행할 때 두개의 데이터 프레임에 행(데이터)의
# 개수가 반드시 같아야 할 필요는 없다.
left_join(df_excel_join, df_teacher_name, by = 'class2')

# bind_rows() 함수로 세로로 데이터 합치기를 할 수 있다.
# bind_rows(데이터 프레임1, 데이터 프레임2)

group1 <- data.frame(id = c(1, 2, 3, 4, 5), test = c(60, 80, 70, 90, 85))
group2 <- data.frame(id = c(6, 7, 8, 9, 10), test = c(70, 83, 65, 95, 80))
bind_rows(group1, group2)

###########################################################################

# 데이터 정제
# 데이터 정제 빠진 데이터 또는 이상한 데이터를 제거하는 작업이다.
# 빠진 데이터 => 측정이 안된 데이터 => 없는 데이터 => NA => 결측치
# NA는 따옴표로 묶으면 안된다. => 결측치가 아닌 문자열 데이터로 취급된다.
# 문자열 결측치는 <NA>로 표시되고 문자열을 제외한 나머지는 NA로 표시된다.
df_na <- data.frame(gender = c('M', 'F', NA, 'F', 'M'), 
                    score = c(5, 4, 3, 2, NA))

# is.na() 함수로 데이터에 결측치가 포함되어 있는가 확인할 수 있다.
# 결측치는 TRUE, 결측가가 아니면 FALSE로 표시된다.
is.na(df_na)

# is.na() 함수 table() 함수를 이용해 결측치의 빈도수를 파악할 수 있다.
table(is.na(df_na))
table(is.na(df_na$gender))
table(is.na(df_na$score))

# 결측치가 포함된 데이터를 함수에 적용시키면 정상적으로 연산되지 않고 NA가
# 출력된다. => 정상적인 연산을 하려면 결측치를 제외시켜야 한다.
sum(df_na$score)
mean(df_na$score)

# 결측치 처리방법

# 1. dplyr 패키지의 filter() 함수를 사용해서 결측치를 제외한 데이터만 추출
# 한다.
df_no_na <- df_na %>% filter(!is.na(gender)) # ! => 논리 부정, not
df_no_na <- df_no_na %>% filter(!is.na(score))
# gender가 NA가 아니고 score가 NA가 아닌 데이터만 추출한다.
df_no_na <- df_na %>% filter(!is.na(gender) & !is.na(score))
sum(df_no_na$score)
mean(df_no_na$score)

# 2. na.omit() 함수를 사용해서 결측치가 있는 모든 행을 한꺼번에 제거할 수
# 있다.
df_no_na <- na.omit(df_na)

# 3. 함수를 실행할 때 na.rm = T 속성을 지정하면 결측치를 제외하고 함수를
# 실행한다.
sum(df_na$score, na.rm = T)
mean(df_na$score, na.rm = T)
max(df_na$score, na.rm = T)
min(df_na$score, na.rm = T)
# 개수를 세는 함수에는 na.rm = T 속성을 사용할 수 없다.
# length(df_na$score, na.rm = T)

df_excel_exam_na <- df_excel_exam
df_excel_exam_na[c(3, 8, 15), 'math2'] <- NA
df_excel_exam_na[20, 'science2'] <- NA

# na.rm = T 속성은 dplyr 패키지의 summarise() 함수에서 사용하는 그룹 함수에
# 서도 사용이 가능하다.
# 그룹 함수 중 데이터의 개수를 세는 n() 함수에서는 na.rm = T 속성을 사용할 
# 수 없다.

df_excel_exam_na %>% 
    group_by(class2) %>% 
    summarise(
        math_sum = sum(math2, na.rm = T),
        math_mean = mean(math2, na.rm = T),
        math_median = median(math2, na.rm = T),
        math_n = n() # 개수에는 NA도 포함되서 계산된다.
    )

# summarise() 함수에서 n() 함수가 실행되지 않을 경우 length() 함수를 사용
# 한다.
df_excel_exam_na %>% 
    group_by(class2) %>% 
    summarise(
        math_sum = sum(math2, na.rm = T),
        math_mean = mean(math2, na.rm = T),
        math_median = median(math2, na.rm = T),
        math_n = length(math2) # 개수에는 NA도 포함되서 계산된다.
    )

# summarise() 함수를 사용하지 않고 개수만 계산을 해야 한다면 tally() 함수를
# 사용해도 된다. => n 이라는 변수가 자동으로 만들어진다.
df_excel_exam_na %>% 
    group_by(class2) %>%
    tally()

# 4. 결측치의 개수를 세지 않으려면 filter() 함수를 사용해서 결측치를 걸러내고
# 계산하면 된다.
df_excel_exam_na %>% 
    group_by(class2) %>% 
    filter(!is.na(math2)) %>% 
    summarise(
        math_sum = sum(math2),
        math_mean = mean(math2),
        math_median = median(math2),
        math_n = n()
    )

# 5. filter() 함수를 사용하지 않고 결측치를 걸러니려면 원본 데이터 프레임에
# na.omit() 함수를 적용시켜 파이프(%>%)로 넘겨주면 된다.
na.omit(df_excel_exam_na) %>% 
    group_by(class2) %>% 
    summarise(
        math_sum = sum(math2),
        math_mean = mean(math2),
        math_median = median(math2),
        math_n = n()
    )

# 6. ifelse() 함수를 사용해서 결측치를 결측치가 아닌 데이터의 평균으로 대체
# 한다.
mean(df_excel_exam_na$math2, na.rm = T) # 55.23529
mean(df_excel_exam_na$science2, na.rm = T) # 59.52632
# math2의 3, 8, 15 번째 데이터를 NA에 55.23529로 대체하고 science2의 20 번째
# 데이터를 59.52632으로 대체한다.
df_excel_exam_na$math2 <- 
    ifelse(
        is.na(df_excel_exam_na$math2), 
        mean(df_excel_exam_na$math2, na.rm = T),
        df_excel_exam_na$math2
    )
df_excel_exam_na$science2 <- 
    ifelse(
        is.na(df_excel_exam_na$science2), 
        mean(df_excel_exam_na$science2, na.rm = T),
        df_excel_exam_na$science2
    )









