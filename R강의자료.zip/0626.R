# 단계 구분도는 지역별 통계치를 색깔의 차이로 표현한 지도를 말한다.

# 단계 구분도를 만들려면 지역별 위도, 경도 정보가 저장된 지도 데이터가 필요하기
# 때문에 maps 패키지의 미국 주별 위도, 경도를 저장해놓은 state 데이터를 사용한다.
install.packages('maps')
library(maps)
# ggplot2 패키지의 map_data() 함수로 지도 데이터를 불러온다.
library(ggplot2)
states_map <- map_data('state')
head(states_map)

# 미국 주별 강력 범죄율(USArrests) 단계 구분도 만들기
# USArrests => 1973년 미국 주별 강력 범죄율 정보
# USArrests의 행 이름을 tibble 패키지의 rownames_to_column() 함수를 사용해 적당한
# 이름의 데이터 프레임을 만든다.
# tibble 패키지는 dplyr 패키지가 설치될 때 자동으로 설치되는 패키지이다.
library(tibble)

# rownames_to_column() 함수는 행 이름을 var 옵션에서 지정한 변수명으로 데이터화
# 하고 새로 1부터 시작하는 행 이름을 붙여준다.
# rownames_to_column(데이터 프레임, var = '변수명')
head(USArrests)
crime <- rownames_to_column(USArrests, var = 'state')
head(crime)

# 지도 데이터의 지역명은 모두 소문자로 되어있기 때문에 crime의 지역명을 tolower()
# 함수를 사용해서 모두 소문자로 변환한다.
# toupper() 함수는 모두 대문자로 변환한다.
crime$state <- tolower(crime$state)

# ggiraphExtra 패키지의 ggChoropleth() 함수를 사용해서 단계 구분도를 만든다.
install.packages('ggiraphExtra')
library(ggiraphExtra)
install.packages('mapproj')
library(mapproj)
ggChoropleth(data = crime, # 단계 구분도로 표시할 데이터
             aes(fill = Murder, # 데이터로 사용할 변수
                 map_id = state), # 지도 데이터의 지역이 저장된 변수
             map = states_map # 지도 데이터(위도, 경도 정보)
             ) 
ggChoropleth(data = crime, aes(fill = Assault, map_id = state), map = states_map)
ggChoropleth(data = crime, aes(fill = Rape, map_id = state), map = states_map)

#################################################################################

# 대한민국 시도별 인구, 결핵 환자 수 단계 구분도 만들기
# kormaps2014 패키지를 이용하면 대한민국의 지역 통계 데이터와 지도 데이터를 사용
# 할 수 있다.

# 어떤 패키지들은 CRAN에 등록되어 있지 않고 github를 통해 공유된다.
# github에 공유된 kormaps2014 패키지를 다운받아 사용하려면 devtools 패키지를 설치
# 한다.
install.packages('devtools')
library(devtools)
# devtools 패키지의 install_github() 함수를 사용해 kormaps2014 패키지를 설치한다.
install_github('cardiomoon/kormaps2014')
library(kormaps2014)
# 지도 데이터 => kormap1(시도별), kormap2(시구군별), kormap3(읍면동별)
# 인구 데이터 => korpop1(시도별), korpop2(시구군별), korpop3(읍면동별)
# 한글이 깨져 보이면 kormaps2014 패키지의 changeCode() 함수를 사용해 출력하면
# UTF-8로 인코딩된 한글을 CP949로 변환해서 깨지지 않게 출력한다.
changeCode(korpop1)
# kormaps2014 패키지로 단계 구분도 작성시 오류가 발생된다면 stringi 패키지가 설치
# 되지 않아서 그렇기 때문에 install.packages('stringi')를 실행해서 설치한다.

# 변수 이름이 한글일 경우 오동작을 일으킬 수 있으므로 지도 작성에 사용할 변수의
# 이름을 rename() 함수를 사용해서 영문으로 변환한다.
library(dplyr)
korpop1 <- rename(korpop1, pop = 총인구_명, name = 행정구역별_읍면동)

# kormap1와 korpop1를 이용해 단계 구분도를 만든다.
ggChoropleth(data = korpop1, aes(fill = pop, map_id = code), map = kormap1)
# 단계 구분도위에 마우스를 올리면 tooltip을 표시되게 하려면 tooltip 속성에 tooltip
# 으로 사용할 변수명을 적어주고 interactive = T 속성을 지정하면 된다.
ggChoropleth(data = korpop1, aes(fill = pop, map_id = code, tooltip = name), 
             map = kormap1, interactive = T)
# ggChoropleth() 함수로 만든 단계 구분도에서 한글이 깨지면 options() 함수를 사용해
# UTF-8로 인코딩 시킨다. => 원상 복귀는 CP949로 인코딩하면 된다.
# options() 함수를 사용한 설정은 R을 재시작하면 원상 복구된다.
# options(encoding = 'UTF-8')

# kormap2와 korpop2를 이용해 단계 구분도를 만든다.
korpop2 <- rename(korpop2, pop = 총인구_명, name = 행정구역별_읍면동)
ggChoropleth(data = korpop2, aes(fill = pop, map_id = code), map = kormap2)
ggChoropleth(data = korpop2, aes(fill = pop, map_id = code, tooltip = name), 
             map = kormap2, interactive = T)

# kormap3와 korpop3를 이용해 단계 구분도를 만든다.
korpop3 <- rename(korpop3, pop = 총인구_명, name = 행정구역별_읍면동)
ggChoropleth(data = korpop3, aes(fill = pop, map_id = code), map = kormap3)
ggChoropleth(data = korpop3, aes(fill = pop, map_id = code, tooltip = name), 
             map = kormap3, interactive = T)

# kormaps2014 패키지는 지역별 결핵 환자수 정보 데이터(tbc)를 제공한다.
changeCode(tbc)
# 결핵 환자수(NewPts)를 사용해서 단계 구분도를 작성할 수 있다.
ggChoropleth(data = tbc, aes(fill = NewPts, map_id = code, tooltip = name), 
             map = kormap1, interactive = T)

#################################################################################

# interactive 그래프
# 마우스 움직임에 반응해 실시간으로 형태가 변하는 그래프
# ggplot2 패키지를 이용해 만든 그래프에 plotly 패키지의 ggplotly() 함수를 적용
# 시키면 된다.
install.packages('plotly')
library(plotly)

ggplotly(ggplot(mpg, aes(displ, hwy, col = drv)) + geom_point())
# 차트도 변수에 저장시킬 수 있다.
g <- ggplot(mpg, aes(displ, hwy, col = drv)) + geom_point()
ggplotly(g)

g <- ggplot(diamonds, aes(cut, col = clarity)) + geom_bar(position = 'dodge')
ggplotly(g)

#################################################################################

# interactive 시계열 그래프
# dygraphs 패키지를 이용해 interactive 시계열 그래프를 만들려면 데이터가 시간 순서
# 속성을 가지고 있는 xts 데이터 타입으로 되어 있어야 하고 xts() 함수를 사용해
# 그래프로 표시하려는 데이터 타입을 변경해서 추출해야 한다.
install.packages('dygraphs')
library(dygraphs)
library(xts) # dygraphs 패키지가 설치될 때 같이 설치되므로 로드만 하면된다.

str(economics)
# xts(interactive 시계열 그래프로 표시할 데이터, order.by = 시계열 데이터)
eco <- xts(economics$unemploy, order.by = economics$date)
# dygraph() 함수에 xts 데이터 타입으로 변환된 데이터를 지정해서 그래프를 만든다.
dygraph(eco)
# '%>%'를 이용해서 dyRangeSelector() 함수를 실행하면 그래프 하단에 시계열 범위를
# 변경할 수 있는 기능이 추가된다.
dygraph(eco) %>% dyRangeSelector()

# interactive 시계열 그래프에 여러 값 표시하기
# 실업자수(unemploy)와 저축율(psavert)을 interactive 시계열 그래프로 표시하기 위해
# 각각의 값을 기억하는 변수를 xts() 함수를 이용해 만든다.
# 시계열 그래프로 표시할 데이터의 단위가 일치하지 않으면 맞춰줘야 한다.
eco_unemploy <- xts(economics$unemploy / 1000, order.by = economics$date)
eco_psavert <- xts(economics$psavert, order.by = economics$date)
head(eco_unemploy)
head(eco_psavert)

# 행렬 형태의 데이터를 가지는(열이름, 변수명이 없는) 데이터를 합친다.
# cbind() : dplyr 패키지의 left_join() 함수와 같은 기능이 실행된다.
# rbind() : dplyr 패키지의 bind_rows() 함수와 같은 기능이 실행된다.
# cbind() 함수를 사용해 eco_unemploy와 eco_psavert를 합친다.
eco2 <- cbind(eco_unemploy, eco_psavert)
head(eco2)
colnames(eco2) <- c('unemploy', 'psavert')
dygraph(eco2) %>% dyRangeSelector()

#################################################################################

# 정적 웹 스크레이핑(크롤링)
# 네이버 영화 사이트 데이터 중에서 영화 제목, 평점, 리뷰만 추출해서 csv 파일로
# 저장한다.

# 타겟 사이트 : https://movie.naver.com/movie/point/af/list.nhn?&page=1
# 영화 제목 => class='movie'
# 영화 평점 => class='point'
# 영화 리뷰 => class='title'

# 1. 웹 스크레이핑에 사용할 패키지를 설치하고 로드한다.
install.packages('rvest')
library(rvest)

# 2. 스크레이핑할 웹 사이트 주소를 저장한다.
url <- 'https://movie.naver.com/movie/point/af/list.nhn?&page=1'

# 3. read_html() 함수로 인수로 지정된 웹 사이트 전체 내용을 읽어온다. => 수집
# encoding = 'CP949' 옵션을 지정해서 한글이 깨지지 않도록 한다.
content <- read_html(url, encoding = 'CP949')

# 4. html_nodes() 함수로 읽어온 html 문서에서 필요한 데이터를 읽는다.
# class 속성을 읽어야 하므로 class 속성 앞에 반드시 '.'을 찍어야 한다.
nodes <- html_nodes(content, '.movie')

# 5. html_text() 함수로 trim = T 옵션을 지정해서 불필요한 빈 칸은 제거하고 필요한
# 텍스트만 얻어온다. 
movie <- html_text(nodes, trim = T)

# 평점과 리뷰도 위 4, 5 과정을 반복해서 읽어들인다.
nodes <- html_nodes(content, '.point')
point <- html_text(nodes, trim = T)
nodes <- html_nodes(content, '.title')
title <- html_text(nodes, trim = T)

# 6. 읽어들인 텍스트에서 불필요한 문자열을 제거한다. => 정제
library(stringr)
# title <- gsub('\t', '', title)
# title <- gsub('\n', '', title)
title <- gsub('[[:punct:][:cntrl:]]', '', title)
title <- gsub('신고', '', title)
title <- gsub('ㅋ', '', title)

# cbind() 함수를 사용해서 제목, 평점, 리뷰를 합친다.
page <- cbind(movie, point)
page <- cbind(page, title)

# 데이터 처리를 위해서 데이터 프레임 형태로 변환시킨다.
page <- as.data.frame(page)
class(page)

# 웹 스크레이핑 된 내용을 csv 파일로 저장시킨다.
write.csv(page, 'movie_review.csv')







